
/*
 * Copyright(c) by BRASILPREV
 *
 * All rights reserved.
 *
 * This software is confidential and proprietary information of
 * BRASILPREV ("Confidential Information").
 * You shall not disclose such Confidential Information and shall 
 * use it only in accordance with the terms of the license agreement
 * you entered with BRASILPREV.
*/

package br.com.brasilprev.bprpastaxatransbt.test;