/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants.step5;

/**
 * Enum QueryConstantsStep4.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum QueryConstantsStep5 {

    /** instance. */
    INSTANCE;

    /** Constante ACESSO04. */
    public static final String ACESSO04 = new StringBuilder("SELECT DISTINCT COUNT(REQUISICAO_FINANCEIRA.RQST_FNC_ID) OVER(PARTITION BY REQUISICAO_FINANCEIRA.RQST_FNC_ID) AS QTD_LINHA ,                                 ")
            .append("  MARCACAODINHERO.TRNS_MNY_ID                                                                                 AS WTRSN_MONEY,                                ")
            .append("  TRANSACAO.TRNS_HEAD_OUT_ID                                                                                  AS WTRANSACAO,                                 ")
            .append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID                                                                           AS IDRequisicaoFinanceira,                     ")
            .append("  CASE                                                                                                                                                       ")
            .append("    WHEN PARREGTAXATRANSACAODET.IC_ISE_TX IS NULL                                                                                                            ")
            .append("    THEN 'S'                                                                                                                                                 ")
            .append("    ELSE PARREGTAXATRANSACAODET.IC_ISE_TX                                                                                                                    ")
            .append("  END isentoSN,                                                                                                                                              ")
            .append("  RQST_TRANSACAO.PCL_ID                AS PROTOCOLO,                                                                                                         ")
            .append("  MARCACAODINHERO.CVG_ID               AS IDSUSEP,                                                                                                           ")
            .append("  MARCACAODINHERO.INV_ID               AS INVESTIMENTO,                                                                                                      ")
            .append("  MARCACAODINHERO.ACNT_RSV_ID          AS CONTA_RESERVA,                                                                                                     ")
            .append("  MARCACAODINHERO.COSTING_SPSR_ID      AS CUSTEIO,                                                                                                           ")
            .append("  MATRICULA_CONTRATO.CNTR_ID           AS idContrato,                                                                                                        ")
            .append("  MATRICULA.PRDCT_ID                   AS idProduto,                                                                                                         ")
            .append("  REQUISICAO_FINANCEIRA.TRNS_TP_ID     AS idTipoTransacao,                                                                                                   ")
            .append("  MATRICULA.PRPSL_DT                   AS dataAquisicaoPlano,                                                                                                ")
            .append("  MATRICULA_CONTRATO.RLTSHP_TP_ID      AS idRelacMatriculaContrato,                                                                                          ")
            .append("  MARCACAODINHERO.FACE_AMT             AS VL_NOMINAL,                                                                                                        ")
            .append("  REQUISICAO_FINANCEIRA.EFV_PRCS_DT    AS dataSolicitacao,                                                                                                   ")
            .append("  ParRegTaxaTransacaoDet.ID_TP_CRT     AS tipoCarregamento,                                                                                                  ")
            .append("  REQUISICAO_FINANCEIRA.PLN_ID         AS idMatricula,                                                                                                       ")
            .append("  REQ_FIN_INVESTIMENTO.RQST_FNC_INV_ID AS IDREQFIN_INVESTIMENTO                                                                                              ")
            .append("FROM PI.WPITRNS_HEAD_OUT TRANSACAO                                                                                                                           ")
            .append("INNER JOIN PI.WPITRNS_MNY MARCACAODINHERO                                                                                                                    ")
            .append("ON TRANSACAO.trns_head_out_id=MARCACAODINHERO.TRNS_HEAD_OUT_ID                                                                                               ")
            .append("INNER JOIN PI.PIRQST_FNC REQUISICAO_FINANCEIRA                                                                                                               ")
            .append("ON TRANSACAO.RQST_ID = REQUISICAO_FINANCEIRA.RQST_ID                                                                                                         ")
            .append("INNER JOIN PI.PIRQST_WITH_TRNS RQST_TRANSACAO                                                                                                                ")
            .append("ON REQUISICAO_FINANCEIRA.RQST_ID = RQST_TRANSACAO.RQST_ID                                                                                                    ")
            .append("INNER JOIN PI.PIRQST_FNC_INV REQ_FIN_INVESTIMENTO                                                                                                            ")
            .append("ON REQUISICAO_FINANCEIRA.RQST_FNC_ID = REQ_FIN_INVESTIMENTO.RQST_FNC_ID                                                                                      ")
            .append("AND MARCACAODINHERO.ACNT_RSV_ID      = REQ_FIN_INVESTIMENTO.ACNT_RSV_ID                                                                                      ")
            .append("AND MARCACAODINHERO.INV_ID           = REQ_FIN_INVESTIMENTO.INV_ID                                                                                           ")
            .append("AND MARCACAODINHERO.COSTING_SPSR_ID  = REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID                                                                                  ")
            .append("AND MARCACAODINHERO.CVG_ID           = REQ_FIN_INVESTIMENTO.CVG_ID                                                                                           ")
            .append("LEFT JOIN DCO.DCORREGTX_TRN ParRegTaxaTransacao                                                                                                              ")
            .append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID = ParRegTaxaTransacao.ID_TRN_TP                                                                                          ")
            .append("AND REQUISICAO_FINANCEIRA.EFV_PRCS_DT BETWEEN ParRegTaxaTransacao.DT_INI_VIG AND ParRegTaxaTransacao.DT_FIM_VIG                                              ")
            .append("LEFT JOIN DCO.DCORREGTX_TRN_DET ParRegTaxaTransacaoDet                                                                                                       ")
            .append("ON ParRegTaxaTransacaoDet.ID_TX_TRN = ParRegTaxaTransacao.ID_TX_TRN                                                                                          ")
            .append("INNER JOIN PI.PIPLN_TBL MATRICULA                                                                                                                            ")
            .append("ON REQUISICAO_FINANCEIRA.PLN_ID = MATRICULA.PLN_ID                                                                                                           ")
            .append("LEFT JOIN PI.PIPLN_CNTR MATRICULA_CONTRATO                                                                                                                   ")
            .append("ON REQUISICAO_FINANCEIRA.PLN_ID          = MATRICULA_CONTRATO.PLN_ID                                                                                         ")
            .append("AND MATRICULA_CONTRATO.PLN_CNTR_STAT_FLG = 'A'                                                                                                               ")
            .append("WHERE TRANSACAO.prcs_flg                 = 'N'                                                                                                               ")
            .append("AND (ParRegTaxaTransacaoDet.ID_TP_TX     = 3                                                                                                                 ")
            .append("OR ParRegTaxaTransacaoDet.ID_TP_TX      IS NULL)                                                                                                             ")
            .append("AND REQ_FIN_INVESTIMENTO.LOAD_FEE_FLG    = 'N'                                                                                                               ")
            .append("ORDER BY REQUISICAO_FINANCEIRA.RQST_FNC_ID                                                                                                                   ").toString();

    /** Constante ACESSO05. */
    public static final String ACESSO05 = "UPDATE PI.WPITRNS_MNY SET fee_amt = ? WHERE TRNS_MNY_ID = ?";

    /** Constante ACESSO06. */
    public static final String ACESSO06 = "SELECT PI.SQ01PITRNSLOADOUTCOSTINGWK.NEXTVAL AS idLancCarregamento FROM DUAL";

    /** Constante ACESSO07. */
    public static final String ACESSO07 = "INSERT INTO PI.WPITRNS_LOAD_OUT_COSTING "
            + "(TRNS_LOAD_OUT_COSTING_ID, TRNS_MNY_ID, COSTING_SPSR_ID, LOAD_FEE_PCT, LOAD_FEE_AMT , CRT_DT, USR_ID) "
            +" VALUES (?, ?, ?, ?, ?, SYSDATE, 42)";

    /** Constante ACESSO08. */
    public static final String ACESSO08 = "UPDATE PI.PIRQST_FNC_INV SET LOAD_FEE_FLG = 'S' WHERE RQST_FNC_ID = ?";

}
