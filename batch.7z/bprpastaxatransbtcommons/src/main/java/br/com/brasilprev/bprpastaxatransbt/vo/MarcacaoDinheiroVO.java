/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Class MarcacaoDinheiroVO.
 *
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class MarcacaoDinheiroVO {

    /** id marcacao dinheiro. */
    private Long idMarcacaoDinheiro;

    /** data dinheiro. */
    private Date dataDinheiro;

    /** valor nominal disponivel. */
    private BigDecimal valorNominalDisponivel = BigDecimal.ZERO;

    /** valor total. */
    private BigDecimal valorTotal = BigDecimal.ZERO;

    /** valor rendimento. */
    private BigDecimal valorRendimento = BigDecimal.ZERO;

    /** valor carregamento. */
    private BigDecimal valorCarregamento = BigDecimal.ZERO;

    /** percentual carregamento. */
    private BigDecimal percentualCarregamento = BigDecimal.ZERO;

    /** cota disponivel. */
    private BigDecimal cotaDisponivel = BigDecimal.ZERO;

    /** eh isento taxa. */
    private String ehIsentoTaxa;

    /** eh entidade fechada. */
    private String ehEntidadeFechada;

    /** cota utilizada. */
    private BigDecimal cotaUtilizada;

    /** valor solicitado. */
    private BigDecimal valorSolicitado;

    /** qtde cota solicitado. */
    private BigDecimal qtdeCotaSolicitado;

    /** id susep. */
    private Long idSusep;

    /** id investimento. */
    private Long idInvestimento;

    /** id conta reserva. */
    private Long idContaReserva;

    /** id custeio. */
    private Long idCusteio;

    /** valor cota. */
    private BigDecimal valorCota;

    /** flag usa dinheiro entidade fechada. */
    private String flagUsaDinheiroEntidadeFechada;

    /**
     * Retorna o id marcacao dinheiro.
     *
     * @return id marcacao dinheiro
     */
    public Long getIdMarcacaoDinheiro() {
        return idMarcacaoDinheiro;
    }

    /**
     * Atribui valor a id marcacao dinheiro.
     *
     * @param idMarcacaoDinheiro atribui novo valor a id marcacao dinheiro
     */
    public void setIdMarcacaoDinheiro(Long idMarcacaoDinheiro) {
        this.idMarcacaoDinheiro = idMarcacaoDinheiro;
    }

    /**
     * Retorna o valor nominal disponivel.
     * 
     * @return valor nominal disponivel
     */
    public BigDecimal getValorNominalDisponivel() {
        return valorNominalDisponivel;
    }

    /**
     * Atribui valor a valor nominal disponivel.
     * 
     * @param valorNominalDisponivel atribui novo valor a valor nominal disponivel
     */
    public void setValorNominalDisponivel(BigDecimal valorNominalDisponivel) {
        this.valorNominalDisponivel = valorNominalDisponivel;
    }

    /**
     * Retorna o valor rendimento.
     *
     * @return valor rendimento
     */
    public BigDecimal getValorRendimento() {
        return valorRendimento;
    }

    /**
     * Atribui valor a valor rendimento.
     *
     * @param valorRendimento atribui novo valor a valor rendimento
     */
    public void setValorRendimento(BigDecimal valorRendimento) {
        this.valorRendimento = valorRendimento;
    }

    /**
     * Retorna o valor carregamento.
     *
     * @return valor carregamento
     */
    public BigDecimal getValorCarregamento() {
        return valorCarregamento;
    }

    /**
     * Atribui valor a valor carregamento.
     *
     * @param valorCarregamento atribui novo valor a valor carregamento
     */
    public void setValorCarregamento(BigDecimal valorCarregamento) {
        this.valorCarregamento = valorCarregamento;
    }

    /**
     * Retorna o percentual carregamento.
     *
     * @return percentual carregamento
     */
    public BigDecimal getPercentualCarregamento() {
        return percentualCarregamento;
    }

    /**
     * Atribui valor a percentual carregamento.
     *
     * @param percentualCarregamento atribui novo valor a percentual carregamento
     */
    public void setPercentualCarregamento(BigDecimal percentualCarregamento) {
        this.percentualCarregamento = percentualCarregamento;
    }

    /**
     * Retorna o data dinheiro.
     *
     * @return data dinheiro
     */
    public Date getDataDinheiro() {
        return dataDinheiro;
    }

    /**
     * Atribui valor a data dinheiro.
     *
     * @param dataDinheiro atribui novo valor a data dinheiro
     */
    public void setDataDinheiro(Date dataDinheiro) {
        this.dataDinheiro = dataDinheiro;
    }

    /**
     * Retorna o valor total.
     *
     * @return valor total
     */
    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    /**
     * Atribui valor a valor total.
     *
     * @param valorTotal atribui novo valor a valor total
     */
    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    /**
     * Retorna o cota disponivel.
     *
     * @return cota disponivel
     */
    public BigDecimal getCotaDisponivel() {
        return cotaDisponivel;
    }

    /**
     * Atribui valor a cota disponivel.
     *
     * @param cotaDisponivel atribui novo valor a cota disponivel
     */
    public void setCotaDisponivel(BigDecimal cotaDisponivel) {
        this.cotaDisponivel = cotaDisponivel;
    }

    /**
     * Retorna o eh isento taxa.
     *
     * @return eh isento taxa
     */
    public String getEhIsentoTaxa() {
        return ehIsentoTaxa;
    }

    /**
     * Atribui valor a eh isento taxa.
     *
     * @param ehIsentoTaxa atribui novo valor a eh isento taxa
     */
    public void setEhIsentoTaxa(String ehIsentoTaxa) {
        this.ehIsentoTaxa = ehIsentoTaxa;
    }

    /**
     * Retorna o eh entidade fechada.
     *
     * @return eh entidade fechada
     */
    public String getEhEntidadeFechada() {
        return ehEntidadeFechada;
    }

    /**
     * Atribui valor a eh entidade fechada.
     *
     * @param ehEntidadeFechada atribui novo valor a eh entidade fechada
     */
    public void setEhEntidadeFechada(String ehEntidadeFechada) {
        this.ehEntidadeFechada = ehEntidadeFechada;
    }

    /**
     * Retorna o cota utilizada.
     *
     * @return cota utilizada
     */
    public BigDecimal getCotaUtilizada() {
        return cotaUtilizada;
    }

    /**
     * Atribui valor a cota utilizada.
     *
     * @param cotaUtilizada atribui novo valor a cota utilizada
     */
    public void setCotaUtilizada(BigDecimal cotaUtilizada) {
        this.cotaUtilizada = cotaUtilizada;
    }


    /**
     * Retorna o valor solicitado.
     *
     * @return valor solicitado
     */
    public BigDecimal getValorSolicitado() {
        return valorSolicitado;
    }

    /**
     * Atribui valor a valor solicitado.
     *
     * @param valorSolicitado atribui novo valor a valor solicitado
     */
    public void setValorSolicitado(BigDecimal valorSolicitado) {
        this.valorSolicitado = valorSolicitado;
    }

    /**
     * Retorna o qtde cota solicitado.
     *
     * @return qtde cota solicitado
     */
    public BigDecimal getQtdeCotaSolicitado() {
        return qtdeCotaSolicitado;
    }

    /**
     * Atribui valor a qtde cota solicitado.
     *
     * @param qtdeCotaSolicitado atribui novo valor a qtde cota solicitado
     */
    public void setQtdeCotaSolicitado(BigDecimal qtdeCotaSolicitado) {
        this.qtdeCotaSolicitado = qtdeCotaSolicitado;
    }

    /**
     * Retorna o id susep.
     * 
     * @return id susep
     */
    public Long getIdSusep() {
        return idSusep;
    }

    /**
     * Atribui valor a id susep.
     * 
     * @param idSusep atribui novo valor a id susep
     */
    public void setIdSusep(Long idSusep) {
        this.idSusep = idSusep;
    }

    /**
     * Retorna o id investimento.
     * 
     * @return id investimento
     */
    public Long getIdInvestimento() {
        return idInvestimento;
    }

    /**
     * Atribui valor a id investimento.
     * 
     * @param idInvestimento atribui novo valor a id investimento
     */
    public void setIdInvestimento(Long idInvestimento) {
        this.idInvestimento = idInvestimento;
    }

    /**
     * Retorna o id conta reserva.
     * 
     * @return id conta reserva
     */
    public Long getIdContaReserva() {
        return idContaReserva;
    }

    /**
     * Atribui valor a id conta reserva.
     * 
     * @param idContaReserva atribui novo valor a id conta reserva
     */
    public void setIdContaReserva(Long idContaReserva) {
        this.idContaReserva = idContaReserva;
    }

    /**
     * Retorna o id custeio.
     * 
     * @return id custeio
     */
    public Long getIdCusteio() {
        return idCusteio;
    }

    /**
     * Atribui valor a id custeio.
     * 
     * @param idCusteio atribui novo valor a id custeio
     */
    public void setIdCusteio(Long idCusteio) {
        this.idCusteio = idCusteio;
    }

    /**
     * Retorna o valor cota.
     * 
     * @return valor cota
     */
    public BigDecimal getValorCota() {
        return valorCota;
    }

    /**
     * Atribui valor a valor cota.
     * 
     * @param valorCota atribui novo valor a valor cota
     */
    public void setValorCota(BigDecimal valorCota) {
        this.valorCota = valorCota;
    }

    /**
     * Retorna o flag usa dinheiro entidade fechada.
     * 
     * @return flag usa dinheiro entidade fechada
     */
    public String getFlagUsaDinheiroEntidadeFechada() {
        return flagUsaDinheiroEntidadeFechada;
    }

    /**
     * Atribui valor a flag usa dinheiro entidade fechada.
     * 
     * @param flagUsaDinheiroEntidadeFechada atribui novo valor a flag usa dinheiro entidade fechada
     */
    public void setFlagUsaDinheiroEntidadeFechada(String flagUsaDinheiroEntidadeFechada) {
        this.flagUsaDinheiroEntidadeFechada = flagUsaDinheiroEntidadeFechada;
    }
    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "MarcacaoDinheiroVO [idMarcacaoDinheiro=" + idMarcacaoDinheiro + ", dataDinheiro=" + dataDinheiro + ", valorNominalDisponivel=" + valorNominalDisponivel + ", valorTotal=" + valorTotal + ", valorRendimento=" + valorRendimento
                + ", valorCarregamento=" + valorCarregamento + ", percentualCarregamento=" + percentualCarregamento + ", cotaDisponivel=" + cotaDisponivel + ", ehIsentoTaxa=" + ehIsentoTaxa + ", ehEntidadeFechada=" + ehEntidadeFechada
                + ", cotaUtilizada=" + cotaUtilizada + ", valorSolicitado=" + valorSolicitado + ", qtdeCotaSolicitado=" + qtdeCotaSolicitado + ", idSusep=" + idSusep + ", idInvestimento=" + idInvestimento + ", idContaReserva=" + idContaReserva
                + ", idCusteio=" + idCusteio + ", valorCota=" + valorCota + ", flagUsaDinheiroEntidadeFechada=" + flagUsaDinheiroEntidadeFechada + "]";
    }



}
