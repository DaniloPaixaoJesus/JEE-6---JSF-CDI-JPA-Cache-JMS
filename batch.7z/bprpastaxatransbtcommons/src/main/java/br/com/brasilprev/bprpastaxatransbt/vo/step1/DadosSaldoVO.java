/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* Todos os direitos reservados.
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ====================================================================
*/
package br.com.brasilprev.bprpastaxatransbt.vo.step1;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;

/**
* Class DadosSaldoVO.
* 
 * @author Diego Rodrigues do Nascimento (P51701802)
*/
public class DadosSaldoVO implements Serializable {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 6966345343727808208L;

    /** Constante TPOPERACAOPARCIAL. */
    private static final Long TPOPERACAOPARCIAL = 3L;

    /** Constante TPOPERACAOTOTAL. */
    private static final Long TPOPERACAOTOTAL = 2L;

    /** Constante UM. */
    private static final BigDecimal UM = new BigDecimal(1);

    /** data solicitada. */
    private Date dataSolicitada;

    /** id matricula. */
    private Long idMatricula;

    /** id requisicao. */
    private Long idRequisicao;

    /** id requisicao financeira. */
    private Long idRequisicaoFinanceira;

    /** data cota. */
    private Date dataCota;

    /** id protocolo. */
    private Long idProtocolo;

    /** tipo trasacao. */
    private Long tipoTrasacao;

    /** tem total solicitado. */
    private boolean temTotalSolicitado;


    /** id tipo operacao. */
    private Long idTipoOperacao;

    /** id atividade passo. */
    private Long idAtividadePasso;

    /** id lancamento. */
    private Long idLancamento;

    /** qtde itens restantes matricula. */
    private int qtdeItensRestantesMatricula;

    /** utiliza dinheiro entidade fechada. */
    private String utilizaDinheiroEntidadeFechada;

    /** marcacao dinheiro. */
    private MarcacaoDinheiroVO marcacaoDinheiro;

    /** lista marcacao dinheiro. */
    private List<MarcacaoDinheiroVO> listaMarcacaoDinheiro;

    /** qtde cota restante. */
    private BigDecimal qtdeCotaRestante;

    /** valor solicitado restante. */
    private BigDecimal valorSolicitadoRestante;

    /** valor cota. */
    private BigDecimal valorCota;

    /** id requisicao atividade. */
    private Long idRequisicaoAtividade;

    /** qtde linhas marcacao. */
    private int qtdeLinhasMarcacao;

    /** valor total solicitado. */
    private BigDecimal valorTotalSolicitado;

    /** total acumulado calculo arredondamento. */
    private BigDecimal restoValorNominalDisponivel = BigDecimal.ZERO;

    /**
     * 
     */
    private BigDecimal restoValorTotal = BigDecimal.ZERO;
    
    /**
     * 
     */
    private boolean possuiSaldo;
    
    /** logger. */
    public static Logger LOGGER = LoggerFactory.getLogger(DadosSaldoVO.class);

    /**
     * Retorna o data solicitada.
     * 
     * @return data solicitada
     */
    public Date getDataSolicitada() {
        return dataSolicitada;
    }

    /**
     * Atribui valor a data solicitada.
     * 
     * @param dataSolicitada atribui novo valor a data solicitada
     */
    public void setDataSolicitada(Date dataSolicitada) {
        this.dataSolicitada = dataSolicitada;
    }

    /**
     * Retorna o id matricula.
     * 
     * @return id matricula
     */
    public Long getIdMatricula() {
        return idMatricula;
    }

    /**
     * Atribui valor a id matricula.
     * 
     * @param idMatricula atribui novo valor a id matricula
     */
    public void setIdMatricula(Long idMatricula) {
        this.idMatricula = idMatricula;
    }

    /**
     * Retorna o id requisicao.
     * 
     * @return id requisicao
     */
    public Long getIdRequisicao() {
        return idRequisicao;
    }

    /**
     * Atribui valor a id requisicao.
     * 
     * @param idRequisicao atribui novo valor a id requisicao
     */
    public void setIdRequisicao(Long idRequisicao) {
        this.idRequisicao = idRequisicao;
    }

    /**
     * Retorna o id requisicao financeira.
     * 
     * @return id requisicao financeira
     */
    public Long getIdRequisicaoFinanceira() {
        return idRequisicaoFinanceira;
    }

    /**
     * Atribui valor a id requisicao financeira.
     * 
     * @param idRequisicaoFinanceira atribui novo valor a id requisicao financeira
     */
    public void setIdRequisicaoFinanceira(Long idRequisicaoFinanceira) {
        this.idRequisicaoFinanceira = idRequisicaoFinanceira;
    }

    /**
     * Retorna o data cota.
     * 
     * @return data cota
     */
    public Date getDataCota() {
        return dataCota;
    }

    /**
     * Atribui valor a data cota.
     * 
     * @param dataCota atribui novo valor a data cota
     */
    public void setDataCota(Date dataCota) {
        this.dataCota = dataCota;
    }

    /**
     * Retorna o id protocolo.
     * 
     * @return id protocolo
     */
    public Long getIdProtocolo() {
        return idProtocolo;
    }

    /**
     * Atribui valor a id protocolo.
     * 
     * @param idProtocolo atribui novo valor a id protocolo
     */
    public void setIdProtocolo(Long idProtocolo) {
        this.idProtocolo = idProtocolo;
    }

    /**
     * Retorna o tipo trasacao.
     * 
     * @return tipo trasacao
     */
    public Long getTipoTrasacao() {
        return tipoTrasacao;
    }

    /**
     * Atribui valor a tipo trasacao.
     * 
     * @param tipoTrasacao atribui novo valor a tipo trasacao
     */
    public void setTipoTrasacao(Long tipoTrasacao) {
        this.tipoTrasacao = tipoTrasacao;
    }

    /**
     * Retorna o id atividade passo.
     * 
     * @return id atividade passo
     */
    public Long getIdAtividadePasso() {
        return idAtividadePasso;
    }

    /**
     * Atribui valor a id atividade passo.
     * 
     * @param idAtividadePasso atribui novo valor a id atividade passo
     */
    public void setIdAtividadePasso(Long idAtividadePasso) {
        this.idAtividadePasso = idAtividadePasso;
    }

    /**
     * Retorna o id lancamento.
     * 
     * @return id lancamento
     */
    public Long getIdLancamento() {
        return idLancamento;
    }

    /**
     * Atribui valor a id lancamento.
     * 
     * @param idLancamento atribui novo valor a id lancamento
     */
    public void setIdLancamento(Long idLancamento) {
        this.idLancamento = idLancamento;
    }

    /**
     * Retorna o id tipo operacao.
     * 
     * @return id tipo operacao
     */
    public Long getIdTipoOperacao() {
        return idTipoOperacao;
    }

    /**
     * Atribui valor a id tipo operacao.
     * 
     * @param idTipoOperacao atribui novo valor a id tipo operacao
     */
    public void setIdTipoOperacao(Long idTipoOperacao) {
        this.idTipoOperacao = idTipoOperacao;
    }

    /**
     * Retorna o qtde itens restantes matricula.
     * 
     * @return qtde itens restantes matricula
     */
    public int getQtdeItensRestantesMatricula() {
        return qtdeItensRestantesMatricula;
    }

    /**
     * Atribui valor a qtde itens restantes matricula.
     * 
     * @param qtdeItensRestantesMatricula atribui novo valor a qtde itens restantes matricula
     */
    public void setQtdeItensRestantesMatricula(int qtdeItensRestantesMatricula) {
        this.qtdeItensRestantesMatricula = qtdeItensRestantesMatricula;
    }

    /**
     * Retorna o utiliza dinheiro entidade fechada.
     * 
     * @return utiliza dinheiro entidade fechada
     */
    public String getUtilizaDinheiroEntidadeFechada() {
        return utilizaDinheiroEntidadeFechada;
    }

    /**
     * Atribui valor a utiliza dinheiro entidade fechada.
     * 
     * @param utilizaDinheiroEntidadeFechada atribui novo valor a utiliza dinheiro entidade fechada
     */
    public void setUtilizaDinheiroEntidadeFechada(String utilizaDinheiroEntidadeFechada) {
        this.utilizaDinheiroEntidadeFechada = utilizaDinheiroEntidadeFechada;
    }

    /**
     * Retorna o marcacao dinheiro.
     * 
     * @return marcacao dinheiro
     */
    public MarcacaoDinheiroVO getMarcacaoDinheiro() {
        return marcacaoDinheiro;
    }

    /**
     * Atribui valor a marcacao dinheiro.
     * 
     * @param marcacaoDinheiro atribui novo valor a marcacao dinheiro
     */
    public void setMarcacaoDinheiro(MarcacaoDinheiroVO marcacaoDinheiro) {
        this.marcacaoDinheiro = marcacaoDinheiro;
    }

    /**
     * Retorna o lista marcacao dinheiro.
     * 
     * @return lista marcacao dinheiro
     */
    public List<MarcacaoDinheiroVO> getListaMarcacaoDinheiro() {
        return listaMarcacaoDinheiro;
    }

    /**
     * Atribui valor a lista marcacao dinheiro.
     * 
     * @param listaMarcacaoDinheiro atribui novo valor a lista marcacao dinheiro
     */
    public void setListaMarcacaoDinheiro(List<MarcacaoDinheiroVO> listaMarcacaoDinheiro) {
        this.listaMarcacaoDinheiro = listaMarcacaoDinheiro;
    }

    /**
     * Retorna o qtde cota restante.
     * 
     * @return qtde cota restante
     */
    public BigDecimal getQtdeCotaRestante() {
        return qtdeCotaRestante;
    }

    /**
     * Atribui valor a qtde cota restante.
     * 
     * @param qtdeCotaRestante atribui novo valor a qtde cota restante
     */
    public void setQtdeCotaRestante(BigDecimal qtdeCotaRestante) {
        this.qtdeCotaRestante = qtdeCotaRestante;
    }

    /**
     * Retorna o valor solicitado restante.
     * 
     * @return valor solicitado restante
     */
    public BigDecimal getValorSolicitadoRestante() {
        return valorSolicitadoRestante;
    }

    /**
     * Atribui valor a valor solicitado restante.
     * 
     * @param valorSolicitadoRestante atribui novo valor a valor solicitado restante
     */
    public void setValorSolicitadoRestante(BigDecimal valorSolicitadoRestante) {
        this.valorSolicitadoRestante = valorSolicitadoRestante;
    }

    /**
     * Retorna o valor cota.
     * 
     * @return valor cota
     */
    public BigDecimal getValorCota() {
        return valorCota;
    }

    /**
     * Atribui valor a valor cota.
     * 
     * @param valorCota atribui novo valor a valor cota
     */
    public void setValorCota(BigDecimal valorCota) {
        this.valorCota = valorCota;
    }


    /**
     * Retorna o qtde linhas marcacao.
     * 
     * @return qtde linhas marcacao
     */
    public int getQtdeLinhasMarcacao() {
        return qtdeLinhasMarcacao;
    }

    /**
     * Atribui valor a qtde linhas marcacao.
     * 
     * @param qtdeLinhasMarcacao atribui novo valor a qtde linhas marcacao
     */
    public void setQtdeLinhasMarcacao(int qtdeLinhasMarcacao) {
        this.qtdeLinhasMarcacao = qtdeLinhasMarcacao;
    }

    /**
     * Adds the marcacao dinheiro ao calculo.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
    public void addMarcacaoDinheiroAoCalculo(MarcacaoDinheiroVO marcacaoDinheiro) {
        if (this.getIdTipoOperacao().equals(TPOPERACAOTOTAL)){
            this.trataOperacaoTotal(marcacaoDinheiro);
        } else if (this.getIdTipoOperacao().equals(TPOPERACAOPARCIAL)) {
            this.trataOperacaoParcial(marcacaoDinheiro);
        }
    }

    /**
     * Trata operacao parcial.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
    private void trataOperacaoParcial(MarcacaoDinheiroVO marcacaoDinheiro) {
        if (this.getUtilizaDinheiroEntidadeFechada().equals("S") || (this.getUtilizaDinheiroEntidadeFechada().equals("N") && marcacaoDinheiro.getEhEntidadeFechada().equals("N")))
        {
            if (marcacaoDinheiro.getValorTotal().compareTo(this.getValorSolicitadoRestante()) >= 0)
            {
                this.calculaValorNominalRedimento(marcacaoDinheiro, this.getValorSolicitadoRestante());
                this.setValorSolicitadoRestante(BigDecimal.ZERO);
                this.setQtdeCotaRestante(BigDecimal.ZERO);
            } else
            {
                marcacaoDinheiro.setCotaUtilizada(marcacaoDinheiro.getCotaDisponivel());
                this.setValorSolicitadoRestante(this.getValorSolicitadoRestante().subtract(marcacaoDinheiro.getValorTotal()));
            }
            this.setValorTotalSolicitado(this.getValorTotalSolicitado().add(marcacaoDinheiro.getValorTotal()));
            this.getListaMarcacaoDinheiro().add(marcacaoDinheiro);
            if ((this.getValorSolicitadoRestante().compareTo(BigDecimal.ZERO) > 0) && (this.qtdeLinhasMarcacao == 0)) {
                this.setTemTotalSolicitado(false);
            }
        }
    }

    /**
     * Trata operacao total.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
     private void trataOperacaoTotal(MarcacaoDinheiroVO marcacaoDinheiro) {
        if (marcacaoDinheiro.getCotaDisponivel().compareTo(this.getQtdeCotaRestante()) >= 0)
        {
            marcacaoDinheiro.setCotaUtilizada(this.getQtdeCotaRestante());
            this.setQtdeCotaRestante(BigDecimal.ZERO);
            this.setValorSolicitadoRestante(BigDecimal.ZERO);
            this.calculaNominalRendimentoCotas(marcacaoDinheiro);
        } else
        {
            marcacaoDinheiro.setCotaUtilizada(marcacaoDinheiro.getCotaDisponivel());
            this.setQtdeCotaRestante(MathUtil.subtrair(this.getQtdeCotaRestante(), marcacaoDinheiro.getCotaDisponivel()));
        }
        this.setValorTotalSolicitado(this.getValorTotalSolicitado().add(marcacaoDinheiro.getValorTotal()));
        this.getListaMarcacaoDinheiro().add(marcacaoDinheiro);
        if ((this.getQtdeCotaRestante().compareTo(BigDecimal.ZERO) > 0) && (this.qtdeLinhasMarcacao == 0)) {
            this.setTemTotalSolicitado(false);
        }
    }

    /**
     * Calcula valor nominal redimento.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     * @param valorBaseCalulo do tipo BigDecimal
     */
    private void calculaValorNominalRedimento(MarcacaoDinheiroVO marcacaoDinheiro, BigDecimal valorBaseCalulo) {
        BigDecimal porcentagemNominal = BigDecimal.ZERO;
        BigDecimal porcentagemRendimento = BigDecimal.ZERO;

        if (marcacaoDinheiro.getValorNominalDisponivel().compareTo(marcacaoDinheiro.getValorTotal()) >= 0) {
            porcentagemNominal = BigDecimal.ONE;
            porcentagemRendimento = BigDecimal.ZERO;
        } else {
            if (marcacaoDinheiro.getValorNominalDisponivel().compareTo(BigDecimal.ZERO) > 0) {
                try{
                    //porcentagemNominal = MathUtil.dividir(marcacaoDinheiro.getValorNominalDisponivel(), marcacaoDinheiro.getValorTotal())
                    //LOGGER.debug("DadosSalvoVO -> PorcentagemNominal arredondando: " + porcentagemNominal)
                    porcentagemNominal = marcacaoDinheiro.getValorNominalDisponivel().divide(marcacaoDinheiro.getValorTotal(), MathContext.DECIMAL128);
                    //LOGGER.debug("DadosSalvoVO -> PorcentagemNominal sem arredondar: " + porcentagemNominal)
                }catch(Exception e){
                    porcentagemNominal = MathUtil.dividir(marcacaoDinheiro.getValorNominalDisponivel(), marcacaoDinheiro.getValorTotal());
                    LOGGER.debug("DadosSalvoVO -> PorcentagemNominal: Deu erro sem arredondar");
                    LOGGER.debug(e.getMessage());
                }
            }
            if (marcacaoDinheiro.getValorRendimento().compareTo(BigDecimal.ZERO) > 0) {
                try{
                    //porcentagemRendimento = MathUtil.dividir(marcacaoDinheiro.getValorRendimento(), marcacaoDinheiro.getValorTotal())
                    //LOGGER.debug("DadosSalvoVO -> PorcentagemRendimento arredondando: " + porcentagemRendimento)
                    porcentagemRendimento = marcacaoDinheiro.getValorRendimento().divide(marcacaoDinheiro.getValorTotal(), MathContext.DECIMAL128);
                    //LOGGER.debug("DadosSalvoVO -> PorcentagemRendimento sem arredondar: " + porcentagemRendimento)
                }catch(Exception e){
                    porcentagemRendimento = MathUtil.dividir(marcacaoDinheiro.getValorRendimento(), marcacaoDinheiro.getValorTotal());
                    LOGGER.debug("DadosSalvoVO -> PorcentagemRendimento: Deu erro sem arredondar");
                    LOGGER.debug(e.getMessage());
                }
            }
            if (porcentagemNominal.compareTo(UM) > 0) {
                porcentagemNominal = UM;
            }
            if (porcentagemRendimento.compareTo(UM) > 0) {
                porcentagemRendimento = UM;
            }
        }
        
        BigDecimal valorNominal = BigDecimal.ZERO;
        BigDecimal valorRendimento = BigDecimal.ZERO;
        try{
            valorNominal = porcentagemNominal.multiply(valorBaseCalulo);
            valorRendimento = porcentagemRendimento.multiply(valorBaseCalulo);
            LOGGER.debug("DadosSalvoVO -> valorNominal: " + valorNominal);
            LOGGER.debug("DadosSalvoVO -> valorRendimento: " + valorRendimento);
        }catch(Exception e){
            valorNominal = MathUtil.multiplicar(porcentagemNominal, valorBaseCalulo);
            valorRendimento = MathUtil.multiplicar(porcentagemRendimento, valorBaseCalulo);
            LOGGER.debug("DadosSalvoVO -> valorNominal: Deu erro sem arredondar");
            LOGGER.debug("DadosSalvoVO -> valorRendimento: Deu erro sem arredondar");
            LOGGER.debug(e.getMessage());
        }

        marcacaoDinheiro.setValorNominalDisponivel(valorNominal);
        marcacaoDinheiro.setValorRendimento(valorRendimento);

        marcacaoDinheiro.setValorTotal(valorNominal.add(valorRendimento).setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP));
        //BigDecimal valorCotaUtilizado = MathUtil.dividir(marcacaoDinheiro.getValorTotal(), this.getValorCota())
        LOGGER.debug("BPRPASTAXATRANSBT -> Step 1 -> Calcular Valor Nominal e Rendimento -> Valor Total encontrado: " + marcacaoDinheiro.getValorTotal());
        LOGGER.debug("BPRPASTAXATRANSBT -> Step 1 -> Calcular Valor Nominal e Rendimento -> Valor Cota encontrado: " + this.getValorCota());
        BigDecimal qtdeCotaUtilizado = marcacaoDinheiro.getValorTotal().divide(this.getValorCota(), MathContext.DECIMAL128).setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP);
        LOGGER.debug("BPRPASTAXATRANSBT -> Step 1 -> Calcular Valor Nominal e Rendimento -> Quantidade de Cota utilizado: " + qtdeCotaUtilizado);
        marcacaoDinheiro.setCotaUtilizada(qtdeCotaUtilizado);
    }

    /**
     * Calcula nominal rendimento cotas.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
    private void calculaNominalRendimentoCotas(MarcacaoDinheiroVO marcacaoDinheiro) {

        if (marcacaoDinheiro.getValorNominalDisponivel().compareTo(marcacaoDinheiro.getValorTotal()) >= 0) {
            marcacaoDinheiro.setValorRendimento(BigDecimal.ZERO);
            marcacaoDinheiro.setValorTotal(MathUtil.multiplicar(marcacaoDinheiro.getCotaUtilizada(), this.getValorCota()));

        } else {
            BigDecimal porcentagemNominal = BigDecimal.ZERO;
            BigDecimal porcentagemRendimento = BigDecimal.ZERO;

            if (marcacaoDinheiro.getValorNominalDisponivel().compareTo(BigDecimal.ZERO) > 0) {
                porcentagemNominal = MathUtil.dividir(marcacaoDinheiro.getValorNominalDisponivel(), marcacaoDinheiro.getValorTotal());
            }
            if (marcacaoDinheiro.getValorRendimento().compareTo(BigDecimal.ZERO) > 0) {
                porcentagemRendimento = MathUtil.dividir(marcacaoDinheiro.getValorRendimento(), marcacaoDinheiro.getValorTotal());
            }

            //BigDecimal valorSolicitadoCota = MathUtil.multiplicar(marcacaoDinheiro.getCotaUtilizada(), this.getValorCota())
            // BigDecimal valorSolicitadoCota =
            // MathUtil.multiplicar(marcacaoDinheiro.getCotaUtilizada(),
            // this.getValorCota())

             BigDecimal valorNominal = porcentagemNominal.multiply(marcacaoDinheiro.getValorTotal());// MathUtil.multiplicar(porcentagemNominal,
                                                                                                    // marcacaoDinheiro.getValorTotal())
            BigDecimal valorRendimento = porcentagemRendimento.multiply(marcacaoDinheiro.getValorTotal());// MathUtil.multiplicar(porcentagemRendimento,
                                                                                                            // marcacaoDinheiro.getValorTotal())

            marcacaoDinheiro.setValorNominalDisponivel(valorNominal);
            marcacaoDinheiro.setValorRendimento(valorRendimento);

            marcacaoDinheiro.setValorTotal(marcacaoDinheiro.getValorNominalDisponivel().add(marcacaoDinheiro.getValorRendimento()).setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP));
            
        }
    }

    /**
     * Retorna o id requisicao atividade.
     * 
     * @return id requisicao atividade
     */
    public Long getIdRequisicaoAtividade() {
        return idRequisicaoAtividade;
    }

    /**
     * Atribui valor a id requisicao atividade.
     * 
     * @param idRequisicaoAtividade atribui novo valor a id requisicao atividade
     */
    public void setIdRequisicaoAtividade(Long idRequisicaoAtividade) {
        this.idRequisicaoAtividade = idRequisicaoAtividade;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((idRequisicaoFinanceira == null) ? 0 : idRequisicaoFinanceira.hashCode());
        return result;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DadosSaldoVO other = (DadosSaldoVO) obj;
        if (idRequisicaoFinanceira == null) {
            if (other.idRequisicaoFinanceira != null)
                return false;
        } else if (!idRequisicaoFinanceira.equals(other.idRequisicaoFinanceira))
            return false;
        return true;
    }
    
    /**
     * @return
     */
    public boolean isPossuiSaldo()
    {
        return possuiSaldo;
    }

    /**
     * @param possuiSaldo
     */
    public void setPossuiSaldo(boolean possuiSaldo)
    {
        this.possuiSaldo = possuiSaldo;
    }
    /**
     * Valida se é tem total solicitado.
     * 
     * @return true, se é tem total solicitado
     */
    public boolean isTemTotalSolicitado() {
        return temTotalSolicitado;
    }

    /**
     * Atribui valor a tem total solicitado.
     * 
     * @param temTotalSolicitado atribui novo valor a tem total solicitado
     */
    public void setTemTotalSolicitado(boolean temTotalSolicitado) {
        this.temTotalSolicitado = temTotalSolicitado;
    }

    /**
     * Retorna o valor total solicitado.
     * 
     * @return valor total solicitado
     */
    public BigDecimal getValorTotalSolicitado() {
        return valorTotalSolicitado;
    }

    /**
     * Atribui valor a valor total solicitado.
     * 
     * @param valorTotalSolicitado atribui novo valor a valor total solicitado
     */
    public void setValorTotalSolicitado(BigDecimal valorTotalSolicitado) {
        this.valorTotalSolicitado = valorTotalSolicitado;
    }

    /**
     * @return Retorna restoValorNominalDisponivel
     */
    public BigDecimal getRestoValorNominalDisponivel() {
        return restoValorNominalDisponivel;
    }

    /**
     * @param restoValorNominalDisponivel Define restoValorNominalDisponivel
     */
    public void setRestoValorNominalDisponivel(BigDecimal restoValorNominalDisponivel) {
        this.restoValorNominalDisponivel = restoValorNominalDisponivel;
    }

    /**
     * @return Retorna restoValorTotal
     */
    public BigDecimal getRestoValorTotal() {
        return restoValorTotal;
    }

    /**
     * @param restoValorTotal Define restoValorTotal
     */
    public void setRestoValorTotal(BigDecimal restoValorTotal) {
        this.restoValorTotal = restoValorTotal;
    }
    
    

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "DadosSaldoVO [dataSolicitada=" + dataSolicitada + ", idMatricula=" + idMatricula + ", idRequisicao=" + idRequisicao + ", idRequisicaoFinanceira=" + idRequisicaoFinanceira + ", dataCota=" + dataCota + ", idProtocolo=" + idProtocolo
                + ", tipoTrasacao=" + tipoTrasacao + ", idTipoOperacao=" + idTipoOperacao + ", idAtividadePasso=" + idAtividadePasso + ", idLancamento=" + idLancamento + ", qtdeItensRestantesMatricula=" + qtdeItensRestantesMatricula
                + ", utilizaDinheiroEntidadeFechada=" + utilizaDinheiroEntidadeFechada + ", marcacaoDinheiro=" + marcacaoDinheiro + ", listaMarcacaoDinheiro=" + listaMarcacaoDinheiro + ", qtdeCotaRestante=" + qtdeCotaRestante
                + ", valorSolicitadoRestante=" + valorSolicitadoRestante + ", valorCota=" + valorCota + ", idRequisicaoAtividade=" + idRequisicaoAtividade + ", qtdeLinhasMarcacao=" + qtdeLinhasMarcacao + ", valorTotalSolicitado="
                + valorTotalSolicitado + ", restoValorNominalDisponivel=" + restoValorNominalDisponivel + ", restoValorTotal=" + restoValorTotal + "]";
    }


}