package br.com.brasilprev.bprpastaxatransbt.querybatch;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step1.QueryConstantsStep1;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * 
 * @author Danilo Paixao (P51701504)
 *
 */
public class Query6  implements QueryBatch{

private LogBatch logger;
    
    private Entry<QueryBatch, PreparedStatement> stmt;
    
    /** map sequence requisicao atividade. */
    private Map<DadosSaldoVO, Long> mapSequenceRequisicaoAtividade = new HashMap<DadosSaldoVO, Long>();
    
    public Query6(final Map<DadosSaldoVO, Long> mapSequenceRequisicaoAtividade) {
        this.mapSequenceRequisicaoAtividade = mapSequenceRequisicaoAtividade;
    }
    
    @Override
    public Integer addBatch(Entry<QueryBatch, PreparedStatement> paramSmtp,
            Object record) throws SQLException {
        this.stmt = paramSmtp; 
        DadosSaldoVO dadosSaldoVO = (DadosSaldoVO) record;
        Integer qtdAdicionadoBatch = 0;
        if (!mapSequenceRequisicaoAtividade.containsKey(dadosSaldoVO)) {
            logger.debug("Escreve -> WriteRecord -> Entrou Query 6");
            Long idRequisicaoAtividade = getSequenceRequisicaoAtividade(dadosSaldoVO);
            dadosSaldoVO.setIdRequisicaoAtividade(idRequisicaoAtividade);
            stmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdRequisicao());
            stmt.getValue().setLong(NumerosInteiros.DOIS, idRequisicaoAtividade);
            stmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoVO.getIdAtividadePasso());
            stmt.getValue().addBatch();
            qtdAdicionadoBatch = 1;
        }
        return qtdAdicionadoBatch;
    }

    @Override
    public String getQuery() {
        return QueryConstantsStep1.ACESSO06;
    }
    
    /**
     * Retorna o sequence requisicao atividade.
     * 
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param pstmt do tipo PreparedStatement
     * @return sequence requisicao atividade
     */
    public Long getSequenceRequisicaoAtividade(DadosSaldoVO dadosSaldoVO) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement =  stmt.getValue().getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep1.ACESSOSEQUENCE05);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_RQST_ACTY");
                mapSequenceRequisicaoAtividade.put(dadosSaldoVO, retorno);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }


}