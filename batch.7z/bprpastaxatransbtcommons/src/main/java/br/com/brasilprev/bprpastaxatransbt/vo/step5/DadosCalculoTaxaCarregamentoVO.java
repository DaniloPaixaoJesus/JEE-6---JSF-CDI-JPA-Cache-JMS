/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.vo.step5;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import br.com.brasilprev.bprcarregamentodm.commons.enums.TipoCarregamentoEnum;
import br.com.brasilprev.bprcarregamentodm.commons.vo.ConsultaDetalheCarregamentoVO;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;

// TODO: Auto-generated Javadoc
/**
 * Class DadosCalculoTaxaCarregamentoVO.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class DadosCalculoTaxaCarregamentoVO {

    /** qtde itens restantes matricula. */
    private int qtdeItensRestantesMatricula;

    /** id work. */
    private Long idWork;

    /** id lancamento. */
    private Long idLancamento;

    /** id contrato. */
    private Long idContrato;

    /** id matricula. */
    private Long idMatricula;

    /** id tipo transacao. */
    private Long idTipoTransacao;

    /**
     * Retorna o id requisicao financeira inv.
     * 
     * @return id requisicao financeira inv
     */
    public Long getIdRequisicaoFinanceiraInv() {
        return idRequisicaoFinanceiraInv;
    }

    /**
     * Atribui valor a id requisicao financeira inv.
     * 
     * @param idRequisicaoFinanceiraInv atribui novo valor a id requisicao financeira inv
     */
    public void setIdRequisicaoFinanceiraInv(Long idRequisicaoFinanceiraInv) {
        this.idRequisicaoFinanceiraInv = idRequisicaoFinanceiraInv;
    }

    /** id requisicao financeira inv. */
    private Long idRequisicaoFinanceiraInv;

    /** tipo carregamento. */
    private TipoCarregamentoEnum tipoCarregamento;

    /** conta reserva. */
    private Long contaReserva;

    /** data aquisicao plano. */
    private Date dataAquisicaoPlano;

    /** data solicitacao. */
    private Date dataSolicitacao;

    /** id custeio responsavel. */
    private Long idCusteioResponsavel;

    /** id relacionamento matricula contrato. */
    private Long idRelacionamentoMatriculaContrato;

    /** id susep. */
    private Long idSusep;

    /** id tipo cobertura. */
    private Long idTipoCobertura;

    /** id produto. */
    private Long idProduto;

    /** valor solicitado. */
    private BigDecimal valorSolicitado = BigDecimal.ZERO;

    /** consulta detalhe carregamento. */
    private ConsultaDetalheCarregamentoVO consultaDetalheCarregamento;

    /** id investimento. */
    private Long idInvestimento;

    /** lista marcacao. */
    private List<MarcacaoDinheiroVO> listaMarcacao;

    /** marcacao dinheiro. */
    MarcacaoDinheiroVO marcacaoDinheiro;

    /** taxa. */
    private BigDecimal taxa;

    /** id requisicao financeira. */
    private Long idRequisicaoFinanceira;

    /** id protocolo. */
    private Long idProtocolo;

    /**
     * Retorna o qtde itens restantes matricula.
     * 
     * @return qtde itens restantes matricula
     */
    public int getQtdeItensRestantesMatricula() {
        return qtdeItensRestantesMatricula;
    }

    /**
     * Atribui valor a qtde itens restantes matricula.
     * 
     * @param qtdeItensRestantesMatricula atribui novo valor a qtde itens restantes matricula
     */
    public void setQtdeItensRestantesMatricula(int qtdeItensRestantesMatricula) {
        this.qtdeItensRestantesMatricula = qtdeItensRestantesMatricula;
    }

    /**
     * Retorna o id work.
     * 
     * @return id work
     */
    public Long getIdWork() {
        return idWork;
    }

    /**
     * Atribui valor a id work.
     * 
     * @param idWork atribui novo valor a id work
     */
    public void setIdWork(Long idWork) {
        this.idWork = idWork;
    }

    /**
     * Retorna o id lancamento.
     * 
     * @return id lancamento
     */
    public Long getIdLancamento() {
        return idLancamento;
    }

    /**
     * Atribui valor a id lancamento.
     * 
     * @param idLancamento atribui novo valor a id lancamento
     */
    public void setIdLancamento(Long idLancamento) {
        this.idLancamento = idLancamento;
    }

    /**
     * Retorna o valor solicitado.
     * 
     * @return valor solicitado
     */
    public BigDecimal getValorSolicitado() {
        return valorSolicitado;
    }

    /**
     * Atribui valor a valor solicitado.
     * 
     * @param valorSolicitado atribui novo valor a valor solicitado
     */
    public void setValorSolicitado(BigDecimal valorSolicitado) {
        this.valorSolicitado = valorSolicitado;
    }

    /**
     * Retorna o lista marcacao.
     * 
     * @return lista marcacao
     */
    public List<MarcacaoDinheiroVO> getListaMarcacao() {
        return listaMarcacao;
    }

    /**
     * Atribui valor a lista marcacao.
     * 
     * @param listaMarcacao atribui novo valor a lista marcacao
     */
    public void setListaMarcacao(List<MarcacaoDinheiroVO> listaMarcacao) {
        this.listaMarcacao = listaMarcacao;
    }

    /**
     * Retorna o consulta detalhe carregamento.
     * 
     * @return consulta detalhe carregamento
     */
    public ConsultaDetalheCarregamentoVO getConsultaDetalheCarregamento() {
        return consultaDetalheCarregamento;
    }

    /**
     * Atribui valor a cosulta detalhe carregamento.
     * 
     * @param consultaDetalheCarregamento atribui novo valor a cosulta detalhe carregamento
     */
    public void setCosultaDetalheCarregamento(ConsultaDetalheCarregamentoVO consultaDetalheCarregamento) {
        this.consultaDetalheCarregamento = consultaDetalheCarregamento;
    }

    /**
     * Adds the marcacao dinheiro.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
    public void addMarcacaoDinheiro(MarcacaoDinheiroVO marcacaoDinheiro) {
        this.calculaTaxa(marcacaoDinheiro);
        this.getListaMarcacao().add(marcacaoDinheiro);

    }

    /**
     * Calcula taxa.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
    private void calculaTaxa(MarcacaoDinheiroVO marcacaoDinheiro) {
        if (this.getTaxa() == null) {
            this.setTaxa(BigDecimal.ZERO);
        }
        BigDecimal valorCarregamento = BigDecimal.ZERO;
        if (this.getTaxa().compareTo(BigDecimal.ZERO) > 0) {
            valorCarregamento = marcacaoDinheiro.getValorNominalDisponivel().multiply(this.getTaxa());
        }

        marcacaoDinheiro.setPercentualCarregamento(this.getTaxa());
        marcacaoDinheiro.setValorCarregamento(valorCarregamento);

    }

    /**
     * Retorna o id investimento.
     * 
     * @return id investimento
     */
    public Long getIdInvestimento() {
        return idInvestimento;
    }

    /**
     * Atribui valor a id investimento.
     * 
     * @param idInvestimento atribui novo valor a id investimento
     */
    public void setIdInvestimento(Long idInvestimento) {
        this.idInvestimento = idInvestimento;
    }

    /**
     * Retorna o id contrato.
     * 
     * @return id contrato
     */
    public Long getIdContrato() {
        return idContrato;
    }

    /**
     * Atribui valor a id contrato.
     * 
     * @param idContrato atribui novo valor a id contrato
     */
    public void setIdContrato(Long idContrato) {
        this.idContrato = idContrato;
    }

    /**
     * Retorna o id matricula.
     * 
     * @return id matricula
     */
    public Long getIdMatricula() {
        return idMatricula;
    }

    /**
     * Atribui valor a id matricula.
     * 
     * @param idMatricula atribui novo valor a id matricula
     */
    public void setIdMatricula(Long idMatricula) {
        this.idMatricula = idMatricula;
    }

    /**
     * Retorna o id tipo transacao.
     * 
     * @return id tipo transacao
     */
    public Long getIdTipoTransacao() {
        return idTipoTransacao;
    }

    /**
     * Atribui valor a id tipo transacao.
     * 
     * @param idTipoTransacao atribui novo valor a id tipo transacao
     */
    public void setIdTipoTransacao(Long idTipoTransacao) {
        this.idTipoTransacao = idTipoTransacao;
    }

    /**
     * Retorna o tipo carregamento.
     * 
     * @return tipo carregamento
     */
    public TipoCarregamentoEnum getTipoCarregamento() {
        return tipoCarregamento;
    }

    /**
     * Atribui valor a tipo carregamento.
     * 
     * @param tipoCarregamento atribui novo valor a tipo carregamento
     */
    public void setTipoCarregamento(TipoCarregamentoEnum tipoCarregamento) {
        this.tipoCarregamento = tipoCarregamento;
    }

    /**
     * Retorna o conta reserva.
     * 
     * @return conta reserva
     */
    public Long getContaReserva() {
        return contaReserva;
    }

    /**
     * Atribui valor a conta reserva.
     * 
     * @param contaReserva atribui novo valor a conta reserva
     */
    public void setContaReserva(Long contaReserva) {
        this.contaReserva = contaReserva;
    }

    /**
     * Retorna o data aquisicao plano.
     * 
     * @return data aquisicao plano
     */
    public Date getDataAquisicaoPlano() {
        return dataAquisicaoPlano;
    }

    /**
     * Atribui valor a data aquisicao plano.
     * 
     * @param dataAquisicaoPlano atribui novo valor a data aquisicao plano
     */
    public void setDataAquisicaoPlano(Date dataAquisicaoPlano) {
        this.dataAquisicaoPlano = dataAquisicaoPlano;
    }

    /**
     * Retorna o data solicitacao.
     * 
     * @return data solicitacao
     */
    public Date getDataSolicitacao() {
        return dataSolicitacao;
    }

    /**
     * Atribui valor a data solicitacao.
     * 
     * @param dataSolicitacao atribui novo valor a data solicitacao
     */
    public void setDataSolicitacao(Date dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }

    /**
     * Retorna o id custeio responsavel.
     * 
     * @return id custeio responsavel
     */
    public Long getIdCusteioResponsavel() {
        return idCusteioResponsavel;
    }

    /**
     * Atribui valor a id custeio responsavel.
     * 
     * @param idCusteioResponsavel atribui novo valor a id custeio responsavel
     */
    public void setIdCusteioResponsavel(Long idCusteioResponsavel) {
        this.idCusteioResponsavel = idCusteioResponsavel;
    }

    /**
     * Retorna o id relacionamento matricula contrato.
     * 
     * @return id relacionamento matricula contrato
     */
    public Long getIdRelacionamentoMatriculaContrato() {
        return idRelacionamentoMatriculaContrato;
    }

    /**
     * Atribui valor a id relacionamento matricula contrato.
     * 
     * @param idRelacionamentoMatriculaContrato atribui novo valor a id relacionamento matricula contrato
     */
    public void setIdRelacionamentoMatriculaContrato(Long idRelacionamentoMatriculaContrato) {
        this.idRelacionamentoMatriculaContrato = idRelacionamentoMatriculaContrato;
    }

    /**
     * Retorna o id susep.
     * 
     * @return id susep
     */
    public Long getIdSusep() {
        return idSusep;
    }

    /**
     * Atribui valor a id susep.
     * 
     * @param idSusep atribui novo valor a id susep
     */
    public void setIdSusep(Long idSusep) {
        this.idSusep = idSusep;
    }

    /**
     * Retorna o id tipo cobertura.
     * 
     * @return id tipo cobertura
     */
    public Long getIdTipoCobertura() {
        return idTipoCobertura;
    }

    /**
     * Atribui valor a id tipo cobertura.
     * 
     * @param idTipoCobertura atribui novo valor a id tipo cobertura
     */
    public void setIdTipoCobertura(Long idTipoCobertura) {
        this.idTipoCobertura = idTipoCobertura;
    }

    /**
     * Retorna o marcacao dinheiro.
     * 
     * @return marcacao dinheiro
     */
    public MarcacaoDinheiroVO getMarcacaoDinheiro() {
        return marcacaoDinheiro;
    }

    /**
     * Atribui valor a marcacao dinheiro.
     * 
     * @param marcacaoDinheiro atribui novo valor a marcacao dinheiro
     */
    public void setMarcacaoDinheiro(MarcacaoDinheiroVO marcacaoDinheiro) {
        this.marcacaoDinheiro = marcacaoDinheiro;
    }

    /**
     * Retorna o id produto.
     * 
     * @return id produto
     */
    public Long getIdProduto() {
        return idProduto;
    }

    /**
     * Atribui valor a id produto.
     * 
     * @param idProduto atribui novo valor a id produto
     */
    public void setIdProduto(Long idProduto) {
        this.idProduto = idProduto;
    }

    /**
     * Retorna o taxa.
     * 
     * @return taxa
     */
    public BigDecimal getTaxa() {
        return taxa;
    }

    /**
     * Atribui valor a taxa.
     * 
     * @param taxa atribui novo valor a taxa
     */
    public void setTaxa(BigDecimal taxa) {
        this.taxa = taxa;
    }

    /**
     * Retorna o id requisicao financeira.
     * 
     * @return id requisicao financeira
     */
    public Long getIdRequisicaoFinanceira() {
        return idRequisicaoFinanceira;
    }

    /**
     * Atribui valor a id requisicao financeira.
     * 
     * @param idRequisicaoFinanceira atribui novo valor a id requisicao financeira
     */
    public void setIdRequisicaoFinanceira(Long idRequisicaoFinanceira) {
        this.idRequisicaoFinanceira = idRequisicaoFinanceira;
    }

    /**
     * Retorna o id protocolo.
     * 
     * @return id protocolo
     */
    public Long getIdProtocolo() {
        return idProtocolo;
    }

    /**
     * Atribui valor a id protocolo.
     * 
     * @param idProtocolo atribui novo valor a id protocolo
     */
    public void setIdProtocolo(Long idProtocolo) {
        this.idProtocolo = idProtocolo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "DadosCalculoTaxaCarregamentoVO [qtdeItensRestantesMatricula=" + qtdeItensRestantesMatricula + ", idWork=" + idWork + ", idLancamento=" + idLancamento + ", idContrato=" + idContrato + ", idMatricula=" + idMatricula
                + ", idTipoTransacao=" + idTipoTransacao + ", tipoCarregamento=" + tipoCarregamento + ", contaReserva=" + contaReserva + ", dataAquisicaoPlano=" + dataAquisicaoPlano + ", dataSolicitacao=" + dataSolicitacao
                + ", idCusteioResponsavel=" + idCusteioResponsavel + ", idRelacionamentoMatriculaContrato=" + idRelacionamentoMatriculaContrato + ", idSusep=" + idSusep + ", idTipoCobertura=" + idTipoCobertura + ", idProduto=" + idProduto
                + ", valorSolicitado=" + valorSolicitado + ", consultaDetalheCarregamento=" + consultaDetalheCarregamento + ", idInvestimento=" + idInvestimento + ", listaMarcacao=" + listaMarcacao + ", marcacaoDinheiro=" + marcacaoDinheiro
                + ", taxa=" + taxa + ", idRequisicaoFinanceira" + idRequisicaoFinanceira + "]";
    }

}
