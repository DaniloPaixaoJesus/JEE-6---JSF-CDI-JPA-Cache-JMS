/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants.step7;


/**
 * Enum QueryConstantsStep1.
 *
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum QueryConstantsStep7 {

    /** instance. */
    INSTANCE;
    /** Constante ACESSO00. */
    public static final String ACESSO00 = new StringBuilder("SELECT                                                                          \n")
    .append("  REQUISICAO_FINANCEIRA.RQST_ID,                                                \n")
    .append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID AS IDREQUISICAOFINACEIRA,                   \n")
    .append("  PASSO.ID_ATD_PSO AS ATIVIDADE_PASSO                                           \n")
    .append("FROM PI.PIRQST_FNC REQUISICAO_FINANCEIRA                                        \n")
    .append("INNER JOIN GDR.GDRTRNTP_CAD DOMTP_TRNS                                          \n")
    .append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID=DOMTP_TRNS.ID_TRN_TP                        \n")
    .append("AND DOMTP_TRNS.IC_OPE_RSV          ='-'                                         \n")
    .append("INNER JOIN PI.PIRQST_WITH_TRNS RQST_TRANSACAO                                   \n")
    .append("ON REQUISICAO_FINANCEIRA.RQST_ID = RQST_TRANSACAO.RQST_ID                       \n")
    .append("INNER JOIN GOT.GOTMOVPTL_FNA MOV_PROTOCOLO                                      \n")
    .append("ON RQST_TRANSACAO.PCL_ID=MOV_PROTOCOLO.ID_PTL_FNA                               \n")
    .append("LEFT JOIN                                                                       \n")
    .append("  (SELECT AT_PASSO.ID_ATD_PSO,                                                  \n")
    .append("    PRO_SUBPROCESSO.ID_PRC                                                      \n")
    .append("  FROM DCO.DCOPCOSUBPC PRO_SUBPROCESSO                                          \n")
    .append("  INNER JOIN DCO.DCOATDSUBPC AT_SUBPROCESSO                                     \n")
    .append("  ON PRO_SUBPROCESSO.ID_PRC_SUBPC = AT_SUBPROCESSO.ID_PRC_SUBPC                 \n")
    .append("  AND AT_SUBPROCESSO.ID_ATD       = 4                                           \n")
    .append("  INNER JOIN DCO.DCOATDPSO AT_PASSO                                             \n")
    .append("  ON AT_SUBPROCESSO.ID_ATD_SUBPC  = AT_PASSO.ID_ATD_SUBPC                       \n")
    .append("  AND AT_PASSO.ID_PSO             = 52                                          \n")
    .append("  ) PASSO ON MOV_PROTOCOLO.ID_PRC = PASSO.ID_PRC                                \n")
    .append("INNER JOIN (SELECT AUX.PLN_ID, SUM(QTA_QT)                                      \n")
    .append("  FROM PI.PITRNS_PNS AUX                                                        \n")
    .append("  GROUP BY AUX.PLN_ID                                                           \n")
    .append("  HAVING SUM(QTA_QT)=0) SALDO                                                   \n")
    .append("ON SALDO.PLN_ID = REQUISICAO_FINANCEIRA.PLN_ID                                  \n")
    .append("WHERE TO_CHAR(REQUISICAO_FINANCEIRA.EFV_PRCS_DT,'YYYYMMDD') = '?'               \n")
    .append("AND TO_CHAR(REQUISICAO_FINANCEIRA.SEN_LBLT_DT ,'YYYYMMDD')  = '30001231'        \n")
    .append("AND REQUISICAO_FINANCEIRA.MOV_LBLT_FLG                      = 'S'               \n")
    .append("AND ((REQUISICAO_FINANCEIRA.MOV_AST_FLG                     = 'S'               \n")
    .append("AND TO_CHAR(REQUISICAO_FINANCEIRA.CNFM_AST_DT ,'YYYYMMDD') <> '30001231')       \n")
    .append("OR (REQUISICAO_FINANCEIRA.MOV_AST_FLG                       = 'N'))             \n")
    .append("AND REQUISICAO_FINANCEIRA.RFSL_LBLT_FLG                     = 'N'               \n")
    .append("AND REQUISICAO_FINANCEIRA.RFSL_AST_FLG                      = 'N'               \n")
    .append("ORDER BY REQUISICAO_FINANCEIRA.RQST_FNC_ID                                      \n")
    .toString();

    /** Constante ACESSOSEQUENCE05. */
    public static final String ACESSOSEQUENCE01 = "SELECT PI.SQ01PIRQSTACTY.NEXTVAL AS ID_RQST_ACTY FROM DUAL";

    /** Constante ACESSO06. */
    public static final String ACESSOATUALIZAACTIVITY = "INSERT INTO PI.PIRQST_ACTY (RQST_ID,STRT_DT, END_DT, USR_ID,RQST_ACTY_ID,ACTY_ST_ID,RQST_USR_ID, ACTY_DS)  VALUES (?,SYSDATE, SYSDATE, 42,?, ?,42, 'SALDO INSUFICIENTE PARA PROCESSAMENTO DO PASSIVO.')";

    /** Constante ACESSO07. */
    public static final String ACESSOINSEREACTIVITYFINANCE = "INSERT INTO PI.PIRQST_FNC_ACTY (RQST_FNC_ACTY_ID, RQST_FNC_ID, RQST_ACTY_NR, AST_FLG, LBLT_FLG, CRT_DT, USR_ID, LAST_CHG_DT, USR_LAST_CHG_ID) VALUES (PI.SQ01PIRQSTFNCACTY.NEXTVAL, ?, ?, 'N', 'S', SYSDATE, 42, SYSDATE, 42)";

    /** Constante ACESSO09. */
    public static final String ACESSORECUSAFINANCE = "UPDATE PI.PIRQST_FNC SET RFSL_LBLT_FLG ='S' WHERE RQST_FNC_ID = ?";

}
