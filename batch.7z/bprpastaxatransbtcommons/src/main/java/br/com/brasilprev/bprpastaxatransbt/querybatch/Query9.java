package br.com.brasilprev.bprpastaxatransbt.querybatch;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map.Entry;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step1.QueryConstantsStep1;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * 
 * @author Danilo Paixao (P51701504)
 *
 */
public class Query9  implements QueryBatch{

private LogBatch logger;
    
    private Entry<QueryBatch, PreparedStatement> stmt;
    
    @Override
    public Integer addBatch(Entry<QueryBatch, PreparedStatement> paramSmtp,
            Object record) throws SQLException {
        this.stmt = paramSmtp; 
        DadosSaldoVO dadosSaldoVO = (DadosSaldoVO) record;
        Integer qtdAdicionadoBatch = 0;
        if (!dadosSaldoVO.isPossuiSaldo()  && !dadosSaldoVO.isTemTotalSolicitado()) {
            logger.debug("Escreve -> WriteRecord -> Entrou Query 9");
            stmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdRequisicaoFinanceira());
            stmt.getValue().addBatch();
            qtdAdicionadoBatch = 1;
        }
        return qtdAdicionadoBatch;
    }

    @Override
    public String getQuery() {
        return QueryConstantsStep1.ACESSO09;
    }
    

}