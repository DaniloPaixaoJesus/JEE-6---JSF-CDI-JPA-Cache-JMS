/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants.step2;

/**
 * Enum QueryConstantsStep2.
 *
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum QueryConstantsStep2 {

    /** instance. */
    INSTANCE;

    /** Constante ACESSO00SELECT. */
    public static final String ACESSO00SELECT = new StringBuilder("SELECT REQUISICAO_FINANCEIRA.EFV_PRCS_DT                                                        AS DATASOLICITACAO,                        \n")
.append("  REQUISICAO_FINANCEIRA.PLN_ID                                                                  AS IDMATRICULA,                            \n")
.append("  REQ_FIN_INVESTIMENTO.CVG_ID                                                                   AS IDSUSEP,                                \n")
.append("  REQ_FIN_INVESTIMENTO.INV_ID                                                                   AS INVESTIMENTO,                           \n")
.append("  REQ_FIN_INVESTIMENTO.ACNT_RSV_ID                                                              AS CONTA_RESERVA,                          \n")
.append("  REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID                                                          AS CUSTEIO,                                \n")
.append("  REQUISICAO_FINANCEIRA.RQST_ID                                                                 AS IDREQUISICAO,                           \n")
.append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID                                                             AS IDREQUISICAOFINACEIRA,                  \n")
.append("  REQUISICAO_FINANCEIRA.QTA_DT                                                                  AS DATA_COTA,                              \n")
.append("  RQST_TRANSACAO.PCL_ID                                                                         AS PROTOCOLO,                              \n")
.append("  REQUISICAO_FINANCEIRA.OPE_TP_ID                                                               AS TP_OPERACAO,                            \n")
.append("  REQUISICAO_FINANCEIRA.TRNS_TP_ID                                                              AS TP_TRANSACAO,                           \n")
.append("  REQ_FIN_INVESTIMENTO.ORGN_MNY_DT                                                              AS DATADINHEIRO,                           \n")
.append("  REQ_FIN_INVESTIMENTO.FACE_AMT                                                                 AS NOMINALDISP,                            \n")
.append("  REQ_FIN_INVESTIMENTO.INCM_AMT                                                                 AS VALOR_RENDIMENTO,                       \n")
.append("  REQ_FIN_INVESTIMENTO.WDRL_AMT                                                                 AS VALOR_TOTAL ,                           \n")
.append("  ROUND((REQ_FIN_INVESTIMENTO.WDRL_AMT /COTA.VL_COT),16)                                        AS COTASDISP,                              \n")
.append("  'N'                                                                                           AS ISENTOTAXA ,                            \n")
.append("  REQ_FIN_INVESTIMENTO.CLS_ENT_FLG                                                              AS ENTIDADEFECHADA,                        \n")
.append("  PASSO.ID_ATD_PSO                                                                              AS ATIVIDADE_PASSO,                        \n")
.append("  COUNT(REQUISICAO_FINANCEIRA.RQST_FNC_ID) OVER(PARTITION BY REQUISICAO_FINANCEIRA.RQST_FNC_ID) AS QTD_LINHA ,                             \n")
.append("  IC_DIN_EDD_FCH                                                                                AS USADINHEIRO_ENTFECHADA,                 \n")
.append("  COTA.VL_COT                                                                                   AS VL_COTA                                 \n")
.append("FROM PI.PIRQST_FNC_INV REQ_FIN_INVESTIMENTO                                                                                                \n")
.append("INNER JOIN PI.PIRQST_FNC REQUISICAO_FINANCEIRA                                                                                             \n")
.append("ON REQ_FIN_INVESTIMENTO.RQST_FNC_ID = REQUISICAO_FINANCEIRA.RQST_FNC_ID                                                                    \n")
.append("INNER JOIN PI.PIRQST_WITH_TRNS RQST_TRANSACAO                                                                                              \n")
.append("ON REQUISICAO_FINANCEIRA.RQST_ID = RQST_TRANSACAO.RQST_ID                                                                                  \n")
.append("INNER JOIN PI.PIPLN_TBL MATRICULA                                                                                                          \n")
.append("ON REQUISICAO_FINANCEIRA.PLN_ID = MATRICULA.PLN_ID                                                                                         \n")
.append("INNER JOIN GDR.GDRTRNTP_CAD DOMTP_TRNS                                                                                                     \n")
.append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID=DOMTP_TRNS.ID_TRN_TP                                                                                   \n")
.append("INNER JOIN GOT.GOTCOTINV COTA                                                                                                              \n")
.append("ON REQ_FIN_INVESTIMENTO.INV_ID = COTA.ID_INV                                                                                               \n")
.append("AND COTA.DT_COT                = REQUISICAO_FINANCEIRA.QTA_DT                                                                              \n")
.append("INNER JOIN DCO.DCORREGTX_TRN TAXA                                                                                                          \n")
.append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID=TAXA.ID_TRN_TP                                                                                         \n")
.append("AND REQUISICAO_FINANCEIRA.EFV_PRCS_DT BETWEEN TAXA.DT_INI_VIG AND TAXA.DT_FIM_VIG                                                          \n")
.append("INNER JOIN GOT.GOTMOVPTL_FNA MOV_PROTOCOLO                                                                                                 \n")
.append("ON RQST_TRANSACAO.PCL_ID=MOV_PROTOCOLO.ID_PTL_FNA                                                                                          \n")
.append("LEFT JOIN                                                                                                                                  \n")
.append("  (SELECT AT_PASSO.ID_ATD_PSO,                                                                                                             \n")
.append("    PRO_SUBPROCESSO.ID_PRC                                                                                                                 \n")
.append("  FROM DCO.DCOPCOSUBPC PRO_SUBPROCESSO                                                                                                     \n")
.append("  INNER JOIN DCO.DCOATDSUBPC AT_SUBPROCESSO                                                                                                \n")
.append("  ON PRO_SUBPROCESSO.ID_PRC_SUBPC = AT_SUBPROCESSO.ID_PRC_SUBPC                                                                            \n")
.append("  AND AT_SUBPROCESSO.ID_ATD       = 4                                                                                                      \n")
.append("  INNER JOIN DCO.DCOATDPSO AT_PASSO                                                                                                        \n")
.append("  ON AT_SUBPROCESSO.ID_ATD_SUBPC                            = AT_PASSO.ID_ATD_SUBPC                                                        \n")
.append("  AND AT_PASSO.ID_PSO                                       = 52                                                                           \n")
.append("  ) PASSO ON MOV_PROTOCOLO.ID_PRC                           = PASSO.ID_PRC                                                                 \n")
.append("WHERE DOMTP_TRNS.IC_OPE_RSV                                 ='+'                                                                           \n")
.append("AND TO_CHAR(REQUISICAO_FINANCEIRA.EFV_PRCS_DT,'YYYYMMDD')   = '?'                                                                          \n")
.append("AND TO_CHAR(REQUISICAO_FINANCEIRA.SEN_LBLT_DT ,'YYYYMMDD')  = '30001231'                                                                   \n")
.append("AND REQUISICAO_FINANCEIRA.MOV_LBLT_FLG                      = 'S'                                                                          \n")
.append("AND ((REQUISICAO_FINANCEIRA.MOV_AST_FLG                     = 'S'                                                                          \n")
.append("AND TO_CHAR(REQUISICAO_FINANCEIRA.CNFM_AST_DT ,'YYYYMMDD') <> '30001231')                                                                  \n")
.append("OR (REQUISICAO_FINANCEIRA.MOV_AST_FLG                       = 'N'))                                                                        \n")
.append("AND REQUISICAO_FINANCEIRA.RFSL_LBLT_FLG                     ='N'                                                                           \n")
.append("AND REQUISICAO_FINANCEIRA.RFSL_AST_FLG                      ='N'                                                                           \n")
.append("AND NOT EXISTS                                                                                                                             \n")
.append("  (SELECT 1                                                                                                                                \n")
.append("  FROM PI.WPITRNS_HEAD_OUT A                                                                                                               \n")
.append("  WHERE A.RQST_ID  = REQUISICAO_FINANCEIRA.RQST_ID                                                                                         \n")
.append("  AND A.TRNS_TP_ID = REQUISICAO_FINANCEIRA.TRNS_TP_ID                                                                                      \n")
.append("  )                                                                                                                                        \n")
.append("GROUP BY REQUISICAO_FINANCEIRA.EFV_PRCS_DT,                                                                                                \n")
.append("  REQUISICAO_FINANCEIRA.PLN_ID ,                                                                                                           \n")
.append("  REQ_FIN_INVESTIMENTO.CVG_ID ,                                                                                                            \n")
.append("  REQ_FIN_INVESTIMENTO.INV_ID ,                                                                                                            \n")
.append("  REQ_FIN_INVESTIMENTO.ACNT_RSV_ID ,                                                                                                       \n")
.append("  REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID ,                                                                                                   \n")
.append("  REQUISICAO_FINANCEIRA.RQST_ID ,                                                                                                          \n")
.append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID ,                                                                                                      \n")
.append("  REQUISICAO_FINANCEIRA.QTA_DT ,                                                                                                           \n")
.append("  RQST_TRANSACAO.PCL_ID ,                                                                                                                  \n")
.append("  REQUISICAO_FINANCEIRA.OPE_TP_ID ,                                                                                                        \n")
.append("  REQUISICAO_FINANCEIRA.TRNS_TP_ID ,                                                                                                       \n")
.append("  REQ_FIN_INVESTIMENTO.ORGN_MNY_DT,                                                                                                        \n")
.append("  REQ_FIN_INVESTIMENTO.FACE_AMT,                                                                                                           \n")
.append("  REQ_FIN_INVESTIMENTO.INCM_AMT,                                                                                                           \n")
.append("  REQ_FIN_INVESTIMENTO.WDRL_AMT,                                                                                                           \n")
.append("  COTA.VL_COT,                                                                                                                             \n")
.append("  REQ_FIN_INVESTIMENTO.CLS_ENT_FLG,                                                                                                        \n")
.append("  PASSO.ID_ATD_PSO ,                                                                                                                       \n")
.append("  IC_DIN_EDD_FCH                                                                                                                           \n")
.append("ORDER BY REQUISICAO_FINANCEIRA.RQST_FNC_ID,                                                                                                \n")
.append("  REQUISICAO_FINANCEIRA.PLN_ID,                                                                                                            \n")
.append("  REQ_FIN_INVESTIMENTO.CVG_ID,                                                                                                             \n")
.append("  REQ_FIN_INVESTIMENTO.INV_ID ,                                                                                                            \n")
.append("  REQ_FIN_INVESTIMENTO.ACNT_RSV_ID,                                                                                                        \n")
.append("  REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID,                                                                                                    \n")
.append("  REQ_FIN_INVESTIMENTO.ORGN_MNY_DT                                                                                                         \n").toString();

    /** Constante ACESSOSEQUENCE01. */
    //ACESSO 01 – INCLUI CHAVE PARA INCLUSÃO WORK
    public static final String ACESSOSEQUENCE01 = "SELECT PI.SQ01PITRNSHEADOUTWK.NEXTVAL AS SEQUENCE FROM DUAL";

    /** Constante ACESSOSEQUENCE02. */
    public static final String ACESSOSEQUENCE02 = "SELECT PI.SQ01PIRQSTACTY.NEXTVAL AS SEQUENCE FROM DUAL";

    /** Constante ACESSO01. */
    //ACESSO 02 – INCLUI CABEÇALHO DOS DADOS PREPARADOS PARA PROCESSAMENTO PASSIVO
    public static final String ACESSO01 = "INSERT INTO PI.WPITRNS_HEAD_OUT (TRNS_HEAD_OUT_ID,QTA_DT,PCL_ID,RQST_ID,OPE_TP_ID,TRNS_TP_ID,PLN_ID,face_amt,incm_amt,qta_qt,USR_ID,GRS_AMT) VALUES (?, ?, ?, ?, ?, ?, ?,0,0,0,42,?)";

    /** Constante ACESSO02. */
    //ACESSO 04 – INCLUI MARCAÇÃO DE DINHEIRO QUE SERÁ USADA
    public static final String ACESSO02 = "INSERT INTO PI.WPITRNS_MNY (TRNS_MNY_ID,TRNS_HEAD_OUT_ID,PLN_ID,CVG_ID,INV_ID,ACNT_RSV_ID,COSTING_SPSR_ID, MNY_ORGN_DT,QTA_QT,FACE_AMT,RFR_INV_AMT,FEE_AMT,TAX_AMT,OTFW_TAX_AMT,CLS_ENT_FLG,EXM_FEE_FLG,CRT_DT,USR_ID) VALUES (PI.SQ01PITRNSMNYWK.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, SYSDATE, 42)";

    /** Constante ACESSO03. */
    public static final String ACESSO03 = "INSERT INTO PI.PIRQST_ACTY (RQST_ID,STRT_DT, USR_ID,RQST_ACTY_ID,ACTY_ST_ID,RQST_USR_ID)  VALUES (?,SYSDATE, 42,?, ?,42)";

    /** Constante ACESSO04. */
    public static final String ACESSO04 = "INSERT INTO PI.PIRQST_FNC_ACTY (RQST_FNC_ACTY_ID, RQST_FNC_ID, RQST_ACTY_NR, AST_FLG, LBLT_FLG, CRT_DT, USR_ID, LAST_CHG_DT, USR_LAST_CHG_ID) VALUES (PI.SQ01PIRQSTFNCACTY.NEXTVAL, ?, ?, 'N', 'S', SYSDATE, 42, SYSDATE, 42)";

    /** Constante ACESSO05. */
    public static final String ACESSO05 = "UPDATE PI.PIRQST_FNC SET RFSL_LBLT_FLG ='S' WHERE RQST_FNC_ID = ?";


}
