package br.com.brasilprev.bprpastaxatransbt.querybatch;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map.Entry;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step1.QueryConstantsStep1;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * 
 * @author Danilo Paixao (P51701504)
 *
 */
public class Query4  implements QueryBatch{

private LogBatch logger;
    
    private Entry<QueryBatch, PreparedStatement> stmt;
    
    @Override
    public Integer addBatch(Entry<QueryBatch, PreparedStatement> paramSmtp,
            Object record) throws SQLException {
        this.stmt = paramSmtp; 
        DadosSaldoVO dadosSaldoVO = (DadosSaldoVO) record;
        Integer qtdAdicionadoBatch = 0;
        if (dadosSaldoVO.isTemTotalSolicitado() && dadosSaldoVO.isPossuiSaldo()) {
            logger.debug("Escreve -> WriteRecord -> Entrou Query 4");
            int qtde = dadosSaldoVO.getListaMarcacaoDinheiro().size();
            dadosSaldoVO.setValorTotalSolicitado(BigDecimal.ZERO);
            for (MarcacaoDinheiroVO marcacaoDinheiroVO : dadosSaldoVO.getListaMarcacaoDinheiro()) {
                Long idLancamentoMoney = this.getSequenceLancamentoMoney(stmt.getValue());
                qtde -= 1;
                MathUtil.calcularResto(dadosSaldoVO, marcacaoDinheiroVO, qtde);
                qtdAdicionadoBatch += insereMarcacaoDinheiro(dadosSaldoVO, marcacaoDinheiroVO, idLancamentoMoney);
            }
        }
        return qtdAdicionadoBatch;
    }

    @Override
    public String getQuery() {
        return QueryConstantsStep1.ACESSO04;
    }
    
    /**
     * Insere marcacao dinheiro.
     * 
     * @param stmt do tipo Entry<Integer,PreparedStatement>
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param marcacaoDinheiroVO do tipo MarcacaoDinheiroVO
     * @param idLancamentoMoney do tipo Long
     * @return Integer
     * @throws SQLException o SQL exception
     */
    private Integer insereMarcacaoDinheiro(DadosSaldoVO dadosSaldoVO, MarcacaoDinheiroVO marcacaoDinheiroVO, Long idLancamentoMoney) throws SQLException {
        stmt.getValue().setLong(NumerosInteiros.UM, idLancamentoMoney);
        stmt.getValue().setLong(NumerosInteiros.DOIS, dadosSaldoVO.getIdLancamento());
        stmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoVO.getIdMatricula());
        stmt.getValue().setLong(NumerosInteiros.QUATRO, marcacaoDinheiroVO.getIdSusep());
        stmt.getValue().setLong(NumerosInteiros.CINCO, marcacaoDinheiroVO.getIdInvestimento());
        stmt.getValue().setLong(NumerosInteiros.SEIS, marcacaoDinheiroVO.getIdContaReserva());
        stmt.getValue().setLong(NumerosInteiros.SETE, marcacaoDinheiroVO.getIdCusteio());
        stmt.getValue().setDate(NumerosInteiros.OITO, (Date) marcacaoDinheiroVO.getDataDinheiro());
        stmt.getValue().setBigDecimal(NumerosInteiros.NOVE, marcacaoDinheiroVO.getCotaUtilizada());
        stmt.getValue().setBigDecimal(NumerosInteiros.DEZ, marcacaoDinheiroVO.getValorNominalDisponivel().setScale(NumerosInteiros.DOIS, RoundingMode.DOWN));
        stmt.getValue().setBigDecimal(NumerosInteiros.ONZE, marcacaoDinheiroVO.getValorTotal());
        stmt.getValue().setString(NumerosInteiros.DOZE, marcacaoDinheiroVO.getEhEntidadeFechada());
        stmt.getValue().setString(NumerosInteiros.TREZE, marcacaoDinheiroVO.getEhIsentoTaxa());
        stmt.getValue().setLong(NumerosInteiros.QUATORZE, marcacaoDinheiroVO.getIdMarcacaoDinheiro());
        stmt.getValue().setLong(NumerosInteiros.QUINZE, StringBatchConstants.IDUSUARIOAPLICACAO);
        stmt.getValue().addBatch();
        return NumerosInteiros.UM;
    }
    
    /**
     * Retorna o sequence lancamento money.
     * 
     * @param pstmt do tipo PreparedStatement
     * @return sequence lancamento money
     */
    private Long getSequenceLancamentoMoney(PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep1.ACESSOSEQUENCE03);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_LANC_MONEY");
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }

}