/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants.step4;

// TODO: Auto-generated Javadoc
/**
 * Enum QueryConstantsStep4.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum QueryConstantsStep4 {

    /** instance. */
    INSTANCE;

    /** Constante ACESSO00SELECT. */
    public static final String ACESSO00SELECT = new StringBuilder("SELECT DISTINCT TRANSACAO.TRNS_HEAD_OUT_ID AS WTRANSACAO,                                                                           ")
            .append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID        AS IDREQUISICAOFINANCEIRA,                                                               ")
            .append("  CASE WHEN PARREGTAXATRANSACAODET.IC_ISE_TX IS NULL THEN 'S' ELSE                                                                  ")
            .append("  PARREGTAXATRANSACAODET.IC_ISE_TX END ISENTOSN,                                                                                    ")
            .append("  RQST_TRANSACAO.PCL_ID                    AS PROTOCOLO,                                                                            ")
            .append("  MARCACAODINHERO.CVG_ID                   AS IDSUSEP,                                                                              ")
            .append("  MARCACAODINHERO.RFR_INV_AMT              AS VL_BRUTO,                                                                             ")
            .append("  REQUISICAO_FINANCEIRA.EFV_PRCS_DT        AS DATASOLICITACAO,                                                                      ")
            .append("  REQ_FIN_INVESTIMENTO.RQST_FNC_INV_ID     AS IDREQFIN_INVESTIMENTO                                                                 ")
            .append("FROM PI.WPITRNS_HEAD_OUT TRANSACAO                                                                                                  ")
            .append("INNER JOIN PI.WPITRNS_MNY MARCACAODINHERO                                                                                           ")
            .append("ON TRANSACAO.TRNS_HEAD_OUT_ID=MARCACAODINHERO.TRNS_HEAD_OUT_ID                                                                      ")
            .append("INNER JOIN PI.PIRQST_FNC REQUISICAO_FINANCEIRA                                                                                      ")
            .append("ON TRANSACAO.RQST_ID = REQUISICAO_FINANCEIRA.RQST_ID                                                                                ")
            .append("INNER JOIN PI.PIRQST_WITH_TRNS RQST_TRANSACAO                                                                                       ")
            .append("ON REQUISICAO_FINANCEIRA.RQST_ID = RQST_TRANSACAO.RQST_ID                                                                           ")
            .append("INNER JOIN PI.PIRQST_FNC_INV REQ_FIN_INVESTIMENTO                                                                                   ")
            .append("ON REQUISICAO_FINANCEIRA.RQST_FNC_ID = REQ_FIN_INVESTIMENTO.RQST_FNC_ID                                                             ")
            .append("AND MARCACAODINHERO.ACNT_RSV_ID      = REQ_FIN_INVESTIMENTO.ACNT_RSV_ID                                                             ")
            .append("AND MARCACAODINHERO.INV_ID           = REQ_FIN_INVESTIMENTO.INV_ID                                                                  ")
            .append("AND MARCACAODINHERO.COSTING_SPSR_ID  = REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID                                                         ")
            .append("AND MARCACAODINHERO.CVG_ID           = REQ_FIN_INVESTIMENTO.CVG_ID                                                                  ")
            .append("LEFT JOIN DCO.DCORREGTX_TRN PARREGTAXATRANSACAO                                                                                     ")
            .append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID = PARREGTAXATRANSACAO.ID_TRN_TP                                                                 ")
            .append("AND REQUISICAO_FINANCEIRA.EFV_PRCS_DT BETWEEN PARREGTAXATRANSACAO.DT_INI_VIG AND PARREGTAXATRANSACAO.DT_FIM_VIG                     ")
            .append("LEFT JOIN DCO.DCORREGTX_TRN_DET PARREGTAXATRANSACAODET                                                                              ")
            .append("ON PARREGTAXATRANSACAODET.ID_TX_TRN   = PARREGTAXATRANSACAO.ID_TX_TRN                                                               ")
            .append("WHERE (PARREGTAXATRANSACAODET.ID_TP_TX   = 1 OR  PARREGTAXATRANSACAODET.ID_TP_TX IS NULL)                                           ")
            .append("AND TRANSACAO.PRCS_FLG              = 'N'  AND AND REQ_FIN_INVESTIMENTO.TAX_EXIT_FLG    = 'N' ")
            .append("ORDER BY REQUISICAO_FINANCEIRA.RQST_FNC_ID                                                                                          ").toString();

    /** Constante ACESSO01UPDATE. */
    public static final String ACESSO01UPDATE = "UPDATE PI.WPITRNS_MNY SET OTFW_TAX_AMT = ? WHERE TRNS_HEAD_OUT_ID = ?";
    
    /** Constante ACESSO02UPDATE. */
    public static final String ACESSO02UPDATE = "UPDATE PI.PIRQST_FNC_INV SET TAX_EXIT_FLG = 'S' WHERE RQST_FNC_ID = ?";

    
}
