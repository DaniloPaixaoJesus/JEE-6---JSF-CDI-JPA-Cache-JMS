package br.com.brasilprev.bprpastaxatransbt.exceptions;

import java.util.Properties;

import br.com.brasilprev.bprejblib.utils.exception.ServiceLocatorException;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;

/**
 * Class TrataExcecoes.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class TrataExcecoes {

    /** Constante LOGGER. */
    private static final LogBatch LOGGER = new LogBatch(new Properties());

    /**
     * Servico.
     * 
     * @param cause do tipo Throwable
     * @param classe do tipo Class<?>
     */
    public static void servico(Throwable cause, Class<?> classe) {
        LOGGER.error(classe.getName() + " - " + cause.getMessage() + "\n" + cause.getCause());
        cause.printStackTrace();
        if (cause instanceof ServiceLocatorException) {
            throw new BatchException(cause);
        }
    }

    /**
     * Batch.
     * 
     * @param cause do tipo Throwable
     * @param classe do tipo Class<?>
     */
    public static void batch(Throwable cause, Class<?> classe) {
        LOGGER.error(classe.getName() + " - " + cause.getMessage() + "\n" + cause.getCause());
        cause.printStackTrace();
        if (!(cause instanceof NullPointerException) && !(cause instanceof ClassCastException)) {
            throw new BatchException(cause);
        }
    }

}
