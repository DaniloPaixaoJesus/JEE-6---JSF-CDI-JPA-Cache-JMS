/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.utils;

import java.util.Properties;

import javax.naming.NamingException;

import br.com.brasilprev.bprejblib.utils.ContextBrasilprev;
import br.com.brasilprev.bprejblib.utils.ContextBrasilprevDefault;
import br.com.brasilprev.bprejblib.utils.ContextBrasilprevDev;
import br.com.brasilprev.bprejblib.utils.exception.ServiceLocatorException;

/**
 * Class ServiceLocatorDev.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ServiceLocatorDev {

    /** instance dev. */
    private static ServiceLocatorDev INSTANCE_DEV;

    /** context brasilprev. */
    private ContextBrasilprev contextBrasilprev = null;

    /**
     * Cria uma nova instância de service locator dev.
     */
    private ServiceLocatorDev() {
        try {
            Properties properties = new Properties();
            properties.setProperty("server.name", "BPRSPWAS11D");
            properties.setProperty("domain", "brasilprev.corp");
            properties.setProperty("port", "2809");
            this.contextBrasilprev = new ContextBrasilprevDev(properties);
        } catch (Exception e) {
            this.contextBrasilprev = new ContextBrasilprevDefault();
        }
    }

    /**
     * Lookup.
     * 
     * @param clazz do tipo Class<?>
     * @param jndiName do tipo String
     * @return Object
     * @throws NamingException o naming exception
     */
    private Object lookup(Class<?> clazz, String jndiName) throws NamingException {
        Object object = null;
        if (this.contextBrasilprev != null) {
            object = this.contextBrasilprev.lookup(clazz, jndiName);
        }
        return object;
    }

    /**
     * Cria uma instância de ServiceLocatorDev.
     * 
     * @return a instância de ServiceLocatorDev
     */
    public static ServiceLocatorDev getInstance() {

        if (INSTANCE_DEV == null) {
            INSTANCE_DEV = new ServiceLocatorDev();
        }
        return INSTANCE_DEV;
    }

    /**
     * Retorna o EJB reference.
     * 
     * @param clazz do tipo Class<?>
     * @param service do tipo String
     * @return EJB reference
     * @throws ServiceLocatorException o service locator exception
     */
    public Object getEJBReference(Class<?> clazz, String service) throws ServiceLocatorException {
        Object ref = null;
        try {
            ref = lookup(clazz, service);
        } catch (Exception e) {
            throw new ServiceLocatorException(e.getMessage(), e);
        }
        return ref;
    }

    /**
     * Retorna o EJB reference.
     * 
     * @param service do tipo String
     * @return EJB reference
     * @throws ServiceLocatorException o service locator exception
     * @deprecated (when, substitute)
     */
    @Deprecated
    public Object getEJBReference(String service) throws ServiceLocatorException {
        return getEJBReference(null, service);
    }
}
