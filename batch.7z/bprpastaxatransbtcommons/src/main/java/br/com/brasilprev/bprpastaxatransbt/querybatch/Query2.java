package br.com.brasilprev.bprpastaxatransbt.querybatch;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Map.Entry;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step1.QueryConstantsStep1;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * 
 * @author Danilo Paixao (P51701504)
 *
 */
public class Query2 implements QueryBatch {

    private LogBatch logger;

    private Entry<QueryBatch, PreparedStatement> stmt;

    private Map<DadosSaldoVO, Long> mapSequenceLancamento;

    public Query2(final Map<DadosSaldoVO, Long> mapSequenceLancamento) {
        this.mapSequenceLancamento = mapSequenceLancamento;
    }

    @Override
    public Integer addBatch(Entry<QueryBatch, PreparedStatement> paramStmt,
            Object record) throws SQLException {
        this.stmt = paramStmt;
        Integer qtdAdicionadoBatch = 0;
        DadosSaldoVO dadosSaldoVO = (DadosSaldoVO) record;
        if (dadosSaldoVO.isTemTotalSolicitado() && dadosSaldoVO.isPossuiSaldo() && !mapSequenceLancamento.containsKey(dadosSaldoVO)) {
            logger.debug("Escreve -> WriteRecord -> Entrou Query 2");
            Long idLancamento = getSequenceLancamento(dadosSaldoVO, stmt.getValue());
            dadosSaldoVO.setValorTotalSolicitado(MathUtil.formatarDinheiro(dadosSaldoVO.getValorTotalSolicitado()));
            dadosSaldoVO.setIdLancamento(idLancamento);
            stmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdLancamento());
            stmt.getValue().setDate(NumerosInteiros.DOIS, (Date) dadosSaldoVO.getDataCota());
            stmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoVO.getIdProtocolo());
            stmt.getValue().setLong(NumerosInteiros.QUATRO, dadosSaldoVO.getIdRequisicao());
            stmt.getValue().setLong(NumerosInteiros.CINCO, dadosSaldoVO.getIdTipoOperacao());
            stmt.getValue().setLong(NumerosInteiros.SEIS, dadosSaldoVO.getTipoTrasacao());
            stmt.getValue().setLong(NumerosInteiros.SETE, dadosSaldoVO.getIdMatricula());
            stmt.getValue().setBigDecimal(NumerosInteiros.OITO, dadosSaldoVO.getValorTotalSolicitado());
            stmt.getValue().addBatch();
            qtdAdicionadoBatch = 1;
        }
        return qtdAdicionadoBatch;
    }

    @Override
    public String getQuery() {
        return QueryConstantsStep1.ACESSO02;
    }

    /**
     * Retorna o sequence lancamento.
     * 
     * @param dadosSaldoVO
     *            do tipo DadosSaldoVO
     * @param pstmt
     *            do tipo PreparedStatement
     * @return sequence lancamento
     */
    private Long getSequenceLancamento(DadosSaldoVO dadosSaldoVO,
            PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection()
                .createStatement()) {
            resultado = createStatement
                    .executeQuery(QueryConstantsStep1.ACESSOSEQUENCE01);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_LANCAMENTO");
                mapSequenceLancamento.put(dadosSaldoVO, retorno);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return retorno;
    }

}
