/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants;

/**
 * Enum NumerosInteiros.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum NumerosInteiros {

    /** instance. */
    INSTANCE;

    /** Constante UM. */
    public static final int UM = 1;

    /** Constante DOIS. */
    public static final int DOIS = 2;

    /** Constante TRES. */
    public static final int TRES = 3;

    /** Constante QUATRO. */
    public static final int QUATRO = 4;

    /** Constante CINCO. */
    public static final int CINCO = 5;

    /** Constante SEIS. */
    public static final int SEIS = 6;

    /** Constante SETE. */
    public static final int SETE = 7;

    /** Constante OITO. */
    public static final int OITO = 8;

    /** Constante NOVE. */
    public static final int NOVE = 9;

    /** Constante DEZ. */
    public static final int DEZ = 10;

    /** Constante ONZE. */
    public static final int ONZE = 11;

    /** Constante DOZE. */
    public static final int DOZE = 12;

    /** Constante TREZE. */
    public static final int TREZE = 13;

    /** Constante QUATORZE. */
    public static final int QUATORZE = 14;

    /** Constante QUINZE. */
    public static final int QUINZE = 15;

    /** Constante DEZESSEIS. */
    public static final int DEZESSEIS = 16;

}
