/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants.step6;

/**
 * Enum QueryConstantsStep1.
 *
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum QueryConstantsStep6 {

    /** instance. */
    INSTANCE;
    /** Constante ACESSO00. */
    public static final String ACESSO00 = new StringBuilder("SELECT REQUISICAO_FINANCEIRA.EFV_PRCS_DT AS DATASOLICITACAO,                                                                                             \n")
    .append("  REQUISICAO_FINANCEIRA.PLN_ID           AS IDMATRICULA,                                                                                                 \n")
    .append("  REQ_FIN_INVESTIMENTO.CVG_ID            AS IDSUSEP,                                                                                                     \n")
    .append("  REQ_FIN_INVESTIMENTO.INV_ID            AS INVESTIMENTO,                                                                                                \n")
    .append("  REQ_FIN_INVESTIMENTO.ACNT_RSV_ID       AS CONTA_RESERVA,                                                                                               \n")
    .append("  REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID   AS CUSTEIO,                                                                                                     \n")
    .append("  REQUISICAO_FINANCEIRA.RQST_ID          AS IDREQUISICAO,                                                                                                \n")
    .append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID      AS IDREQUISICAOFINACEIRA,                                                                                       \n")
    .append("  REQUISICAO_FINANCEIRA.QTA_DT           AS DATA_COTA,                                                                                                   \n")
    .append("  RQST_TRANSACAO.PCL_ID                  AS PROTOCOLO,                                                                                                   \n")
    .append("  REQUISICAO_FINANCEIRA.OPE_TP_ID        AS TP_OPERACAO,                                                                                                 \n")
    .append("  REQUISICAO_FINANCEIRA.TRNS_TP_ID       AS TP_TRANSACAO,                                                                                                \n")
    .append("  CASE                                                                                                                                                   \n")
    .append("    WHEN REQUISICAO_FINANCEIRA.OPE_TP_ID = 3                                                                                                             \n")
    .append("    THEN ROUND((REQ_FIN_INVESTIMENTO.WDRL_AMT / COTA.VL_COT),16)                                                                                         \n")
    .append("    ELSE REQ_FIN_INVESTIMENTO.QTA_QT                                                                                                                     \n")
    .append("  END QTDCOTA,                                                                                                                                           \n")
    .append("  CASE                                                                                                                                                   \n")
    .append("    WHEN REQUISICAO_FINANCEIRA.OPE_TP_ID = 3                                                                                                             \n")
    .append("    THEN REQ_FIN_INVESTIMENTO.WDRL_AMT                                                                                                                   \n")
    .append("    ELSE (REQ_FIN_INVESTIMENTO.QTA_QT * COTA.VL_COT)                                                                                                     \n")
    .append("  END VALORSOLICITADO,                                                                                                                                   \n")
    .append("  MARCACAO.DATAREFERENCIA AS DATADINHEIRO,                                                                                                               \n")
    .append("  MARCACAO.NOMINALDISP ,                                                                                                                                 \n")
    .append("  ROUND((MARCACAO.COTASDISP * COTA.VL_COT),2)                        AS VALOR_TOTAL,                                                                     \n")
    .append("  ROUND((MARCACAO.COTASDISP * COTA.VL_COT) - MARCACAO.NOMINALDISP,2) AS VALOR_RENDIMENTO,                                                                \n")
    .append("  MARCACAO.COTASDISP ,                                                                                                                                   \n")
    .append("  MARCACAO.ISENTOTAXA ,                                                                                                                                  \n")
    .append("  MARCACAO.ENTIDADEFECHADA ,                                                                                                                             \n")
    .append("  MARCACAO.IDMARCACAO                                                                                           AS IDTRANSACAO,                          \n")
    .append("  PASSO.ID_ATD_PSO                                                                                              AS ATIVIDADE_PASSO,                      \n")
    .append("  COUNT(REQUISICAO_FINANCEIRA.RQST_FNC_ID) OVER(PARTITION BY REQUISICAO_FINANCEIRA.RQST_FNC_ID)                 AS QTD_LINHA ,                           \n")
    .append("  COUNT(MARCACAO.NUMEROMATRICULA) OVER(PARTITION BY MARCACAO.NUMEROMATRICULA, MARCACAO.IDSUSEP,                                                          \n")
    .append("    MARCACAO.IDINVESTIMENTO,MARCACAO.IDCONTA_RESERVA, MARCACAO.IDCUSTEIO)                                         AS QTD_LINHA_MARCACAO,                    \n")
    .append("  IC_DIN_EDD_FCH                                                                                                AS USADINHEIRO_ENTFECHADA,               \n")
    .append("  COTA.VL_COT                                                                                                   AS VL_COTA,                               \n")
    .append("  CASE WHEN SUM(REQ_FIN_INVESTIMENTO.QTA_QT) >(SELECT SUM(QTA_QT)                                                                                        \n")
    .append("            FROM PI.PITRNS_PNS SALDO                                                                                                                        \n")
    .append("  WHERE REQUISICAO_FINANCEIRA.PLN_ID       = SALDO.PLN_ID                                                                                                \n")
    .append("  AND REQ_FIN_INVESTIMENTO.CVG_ID          = SALDO.CVG_PNS_ID                                                                                            \n")
    .append("  AND REQ_FIN_INVESTIMENTO.INV_ID          = SALDO.INV_ID                                                                                                \n")
    .append("  AND REQ_FIN_INVESTIMENTO.ACNT_RSV_ID     = SALDO.ACNT_RSV_ID                                                                                            \n")
    .append("  AND REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID = SALDO.COSTING_SPSR_ID                                                                                        \n")
    .append("  ) THEN 'N' ELSE 'S' END TEMSALDO                                                                                                                        \n")
    .append("FROM PI.PIRQST_FNC_INV REQ_FIN_INVESTIMENTO                                                                                                              \n")
    .append("INNER JOIN PI.PIRQST_FNC REQUISICAO_FINANCEIRA                                                                                                           \n")
    .append("ON REQ_FIN_INVESTIMENTO.RQST_FNC_ID = REQUISICAO_FINANCEIRA.RQST_FNC_ID                                                                                  \n")
    .append("INNER JOIN GDR.GDRTRNTP_CAD DOMTP_TRNS                                                                                                                   \n")
    .append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID=DOMTP_TRNS.ID_TRN_TP                                                                                                 \n")
    .append("INNER JOIN PI.PIRQST_WITH_TRNS RQST_TRANSACAO                                                                                                            \n")
    .append("ON REQUISICAO_FINANCEIRA.RQST_ID = RQST_TRANSACAO.RQST_ID                                                                                                \n")
    .append("INNER JOIN PI.PIPLN_TBL MATRICULA                                                                                                                        \n")
    .append("ON REQUISICAO_FINANCEIRA.PLN_ID = MATRICULA.PLN_ID                                                                                                       \n")
    .append("INNER JOIN GOT.GOTCOTINV COTA                                                                                                                            \n")
    .append("ON REQ_FIN_INVESTIMENTO.INV_ID = COTA.ID_INV                                                                                                             \n")
    .append("AND COTA.DT_COT                = REQUISICAO_FINANCEIRA.QTA_DT                                                                                            \n")
    .append("INNER JOIN PI.VW_MARCACAO_DISPONIVEL MARCACAO                                                                                                            \n")
    .append("ON REQUISICAO_FINANCEIRA.RQST_FNC_ID     =REQ_FIN_INVESTIMENTO.RQST_FNC_ID                                                                               \n")
    .append("AND REQ_FIN_INVESTIMENTO.PLN_ID          = MARCACAO.NUMEROMATRICULA                                                                                      \n")
    .append("AND REQ_FIN_INVESTIMENTO.CVG_ID          = MARCACAO.IDSUSEP                                                                                              \n")
    .append("AND REQ_FIN_INVESTIMENTO.INV_ID          = MARCACAO.IDINVESTIMENTO                                                                                       \n")
    .append("AND REQ_FIN_INVESTIMENTO.ACNT_RSV_ID     = MARCACAO.IDCONTA_RESERVA                                                                                      \n")
    .append("AND REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID = MARCACAO.IDCUSTEIO                                                                                            \n")
    .append("INNER JOIN GOT.GOTMOVPTL_FNA MOV_PROTOCOLO                                                                                                               \n")
    .append("ON RQST_TRANSACAO.PCL_ID=MOV_PROTOCOLO.ID_PTL_FNA                                                                                                        \n")
    .append("LEFT JOIN                                                                                                                                                \n")
    .append("  (SELECT AT_PASSO.ID_ATD_PSO,                                                                                                                           \n")
    .append("    PRO_SUBPROCESSO.ID_PRC                                                                                                                               \n")
    .append("  FROM DCO.DCOPCOSUBPC PRO_SUBPROCESSO                                                                                                                   \n")
    .append("  INNER JOIN DCO.DCOATDSUBPC AT_SUBPROCESSO                                                                                                              \n")
    .append("  ON PRO_SUBPROCESSO.ID_PRC_SUBPC = AT_SUBPROCESSO.ID_PRC_SUBPC                                                                                          \n")
    .append("  AND AT_SUBPROCESSO.ID_ATD       = 4                                                                                                                    \n")
    .append("  INNER JOIN DCO.DCOATDPSO AT_PASSO                                                                                                                      \n")
    .append("  ON AT_SUBPROCESSO.ID_ATD_SUBPC = AT_PASSO.ID_ATD_SUBPC                                                                                                 \n")
    .append("  AND AT_PASSO.ID_PSO            = 52                                                                                                                    \n")
    .append("  ) PASSO                                                                                                                                                \n")
    .append("  ON MOV_PROTOCOLO.ID_PRC = PASSO.ID_PRC                                                                                                                 \n")
    .append("LEFT JOIN DCO.DCORREGTX_TRN TAXA                                                                                                                         \n")
    .append("ON REQUISICAO_FINANCEIRA.TRNS_TP_ID                         =TAXA.ID_TRN_TP                                                                              \n")
    .append("INNER JOIN (SELECT AUX.PLN_ID, SUM(QTA_QT)  \n")
    .append("          FROM PI.PITRNS_PNS AUX  \n")
    .append("           GROUP BY AUX.PLN_ID  \n")
    .append("          HAVING SUM(QTA_QT)>0) SALDO  \n")
    .append("        ON SALDO.PLN_ID = REQUISICAO_FINANCEIRA.PLN_ID  \n")
    .append("WHERE DOMTP_TRNS.IC_OPE_RSV                                 ='-'                                                                                         \n")
    .append("AND REQUISICAO_FINANCEIRA.TRNS_TP_ID                   IN (63,59)                                                                                    \n")
    .append("AND TO_CHAR(REQUISICAO_FINANCEIRA.EFV_PRCS_DT,'YYYYMMDD')   = '?'                                                                                        \n")
    .append("AND TO_CHAR(REQUISICAO_FINANCEIRA.SEN_LBLT_DT ,'YYYYMMDD')  = '30001231'                                                                                 \n")
    .append("AND REQUISICAO_FINANCEIRA.MOV_LBLT_FLG                      = 'S'                                                                                        \n")
    .append("AND ((REQUISICAO_FINANCEIRA.MOV_AST_FLG                     = 'S'                                                                                        \n")
    .append("AND TO_CHAR(REQUISICAO_FINANCEIRA.CNFM_AST_DT ,'YYYYMMDD') <> '30001231')                                                                                \n")
    .append("OR (REQUISICAO_FINANCEIRA.MOV_AST_FLG                       = 'N'))                                                                                      \n")
    .append("AND REQUISICAO_FINANCEIRA.RFSL_LBLT_FLG                     ='N'                                                                                         \n")
    .append("AND REQUISICAO_FINANCEIRA.RFSL_AST_FLG                      ='N'                                                                                         \n")
    .append("AND NOT EXISTS                                                                                                                                           \n")
    .append("  (SELECT 1                                                                                                                                              \n")
    .append("  FROM PI.WPITRNS_HEAD_OUT A                                                                                                                             \n")
    .append("  WHERE A.RQST_ID  = REQUISICAO_FINANCEIRA.RQST_ID                                                                                                       \n")
    .append("  AND A.TRNS_TP_ID = REQUISICAO_FINANCEIRA.TRNS_TP_ID                                                                                                    \n")
    .append("  )                                                                                                                                                      \n")
    .append("AND ((REQ_FIN_INVESTIMENTO.WDRL_AMT >0                                                                                                                   \n")
    .append("AND REQUISICAO_FINANCEIRA.OPE_TP_ID = 3)                                                                                                                 \n")
    .append("OR (REQ_FIN_INVESTIMENTO.QTA_QT     >0                                                                                                                   \n")
    .append("AND REQUISICAO_FINANCEIRA.OPE_TP_ID = 2))                                                                                                                \n")
    .append("AND MARCACAO.COTASDISP>0                                                                                                                                    \n")
    .append("GROUP BY REQUISICAO_FINANCEIRA.EFV_PRCS_DT,                                                                                                              \n")
    .append("  REQUISICAO_FINANCEIRA.PLN_ID,                                                                                                                          \n")
    .append("  REQ_FIN_INVESTIMENTO.CVG_ID,                                                                                                                           \n")
    .append("  REQ_FIN_INVESTIMENTO.INV_ID,                                                                                                                           \n")
    .append("  REQ_FIN_INVESTIMENTO.ACNT_RSV_ID,                                                                                                                      \n")
    .append("  REQ_FIN_INVESTIMENTO.COSTING_SPSR_ID,                                                                                                                  \n")
    .append("  REQ_FIN_INVESTIMENTO.QTA_QT,                                                                                                                           \n")
    .append("  REQ_FIN_INVESTIMENTO.WDRL_AMT,                                                                                                                         \n")
    .append("  REQUISICAO_FINANCEIRA.RQST_ID,                                                                                                                         \n")
    .append("  REQUISICAO_FINANCEIRA.RQST_FNC_ID,                                                                                                                     \n")
    .append("  REQUISICAO_FINANCEIRA.QTA_DT,                                                                                                                          \n")
    .append("  RQST_TRANSACAO.PCL_ID,                                                                                                                                 \n")
    .append("  REQUISICAO_FINANCEIRA.OPE_TP_ID,                                                                                                                       \n")
    .append("  REQUISICAO_FINANCEIRA.TRNS_TP_ID,                                                                                                                      \n")
    .append("  COTA.VL_COT,                                                                                                                                           \n")
    .append("  MARCACAO.NUMEROMATRICULA,                                                                                                                              \n")
    .append("  MARCACAO.IDSUSEP,                                                                                                                                      \n")
    .append("  MARCACAO.IDINVESTIMENTO,                                                                                                                               \n")
    .append("  MARCACAO.IDCONTA_RESERVA,                                                                                                                              \n")
    .append("  MARCACAO.IDCUSTEIO,                                                                                                                                    \n")
    .append("  MARCACAO.DATAREFERENCIA,                                                                                                                               \n")
    .append("  MARCACAO.NOMINALDISP,                                                                                                                                  \n")
    .append("  MARCACAO.COTASDISP,                                                                                                                                    \n")
    .append("  MARCACAO.ISENTOTAXA,                                                                                                                                   \n")
    .append("  MARCACAO.ENTIDADEFECHADA,                                                                                                                              \n")
    .append("  MARCACAO.IDMARCACAO,                                                                                                                                   \n")
    .append("  PASSO.ID_ATD_PSO,                                                                                                                                      \n")
    .append("  IC_DIN_EDD_FCH                                                                                                                                         \n")
    .append("ORDER BY REQUISICAO_FINANCEIRA.RQST_FNC_ID,                                                                                                              \n")
    .append("  MARCACAO.NUMEROMATRICULA,                                                                                                                              \n")
    .append("  MARCACAO.IDSUSEP,                                                                                                                                      \n")
    .append("  MARCACAO.IDINVESTIMENTO,                                                                                                                               \n")
    .append("  MARCACAO.IDCONTA_RESERVA,                                                                                                                              \n")
    .append("  MARCACAO.IDCUSTEIO,                                                                                                                                    \n")
    .append("  MARCACAO.DATAREFERENCIA ASC                                                                                                                            \n").toString();

    /** Constante ACESSOSEQUENCE01. */
    // ACESSO 01 – INCLUI CHAVE PARA INCLUSÃO WORK
    public static final String ACESSOSEQUENCE01 = "SELECT PI.SQ01PITRNSHEADOUTWK.NEXTVAL AS ID_LANCAMENTO FROM DUAL";

    /** Constante ACESSO02. */
    // ACESSO 02 – INCLUI CABEÇALHO DOS DADOS PREPARADOS PARA PROCESSAMENTO
    // PASSIVO
    public static final String ACESSO02 = "INSERT INTO PI.WPITRNS_HEAD_OUT (TRNS_HEAD_OUT_ID,QTA_DT,PCL_ID,RQST_ID,OPE_TP_ID,TRNS_TP_ID,PLN_ID,face_amt,incm_amt,qta_qt,USR_ID,GRS_AMT) VALUES (?, ?, ?, ?, ?, ?, ?,0,0,0,42,?)";

    /** Constante ACESSOSEQUENCE03. */
    // ACESSO 03 – INCLUI CHAVE PARA INCLUSÃO WORK
    public static final String ACESSOSEQUENCE03 = "SELECT PI.SQ01PITRNSMNYWK.NEXTVAL AS ID_LANC_MONEY FROM DUAL";

    /** Constante ACESSO04. */
    // ACESSO 04 – INCLUI MARCAÇÃO DE DINHEIRO QUE SERÁ USADA
    public static final String ACESSO04 = "INSERT INTO PI.WPITRNS_MNY (TRNS_MNY_ID,TRNS_HEAD_OUT_ID,PLN_ID,CVG_ID,INV_ID,ACNT_RSV_ID,COSTING_SPSR_ID, MNY_ORGN_DT,QTA_QT,FACE_AMT,RFR_INV_AMT,FEE_AMT,TAX_AMT,OTFW_TAX_AMT,CLS_ENT_FLG,EXM_FEE_FLG,TRNS_PNS_RFR_ID,CRT_DT,USR_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?, SYSDATE, ?)";

    /** Constante ACESSOSEQUENCE05. */
    public static final String ACESSOSEQUENCE05 = "SELECT PI.SQ01PIRQSTACTY.NEXTVAL AS ID_RQST_ACTY FROM DUAL";

    /** Constante ACESSO06. */
    public static final String ACESSO06 = "INSERT INTO PI.PIRQST_ACTY (RQST_ID,STRT_DT, USR_ID,RQST_ACTY_ID,ACTY_ST_ID,RQST_USR_ID)  VALUES (?,SYSDATE, 42,?, ?,42)";

    /** Constante ACESSO07. */
    public static final String ACESSO07 = "INSERT INTO PI.PIRQST_FNC_ACTY (RQST_FNC_ACTY_ID, RQST_FNC_ID, RQST_ACTY_NR, AST_FLG, LBLT_FLG, CRT_DT, USR_ID, LAST_CHG_DT, USR_LAST_CHG_ID) VALUES (PI.SQ01PIRQSTFNCACTY.NEXTVAL, ?, ?, 'N', 'S', SYSDATE, 42, SYSDATE, 42)";

    /** Constante ACESSO08. */
    public static final String ACESSO08 = "UPDATE PI.PIRQST_ACTY SET END_DT=SYSDATE, ACTY_DS='SALDO INSUFICIENTE PARA PROCESSAMENTO DO PASSIVO.' WHERE RQST_ACTY_ID = ?";

    /** Constante ACESSO09. */
    public static final String ACESSO09 = "UPDATE PI.PIRQST_FNC SET RFSL_LBLT_FLG ='S' WHERE RQST_FNC_ID = ?";

    /** Constante ACESSO10. */
    public static final String ACESSO10 = "UPDATE PI.WPITRNS_HEAD_OUT SET GRS_AMT=? WHERE TRNS_HEAD_OUT_ID=?";

}
