/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.vo;

/**
 * Class Sequences.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class Sequences {

    /** sequence request act. */
    private Long sequenceRequestAct;

    /** sequence request financial. */
    private Long sequenceRequestFinancial;

    /** gravou request. */
    private boolean gravouRequest;

    /**
     * Valida se é gravou request.
     * 
     * @return true, se é gravou request
     */
    public boolean isGravouRequest() {
        return gravouRequest;
    }

    /**
     * Atribui valor a gravou request.
     * 
     * @param gravouRequest atribui novo valor a gravou request
     */
    public void setGravouRequest(boolean gravouRequest) {
        this.gravouRequest = gravouRequest;
    }

    /**
     * Retorna o sequence request act.
     * 
     * @return sequence request act
     */
    public Long getSequenceRequestAct() {
        return sequenceRequestAct;
    }

    /**
     * Atribui valor a sequence request act.
     * 
     * @param sequenceRequestAct atribui novo valor a sequence request act
     */
    public void setSequenceRequestAct(Long sequenceRequestAct) {
        this.sequenceRequestAct = sequenceRequestAct;
    }

    /**
     * Retorna o sequence request financial.
     * 
     * @return sequence request financial
     */
    public Long getSequenceRequestFinancial() {
        return sequenceRequestFinancial;
    }

    /**
     * Atribui valor a sequence request financial.
     * 
     * @param sequenceRequestFinancial atribui novo valor a sequence request financial
     */
    public void setSequenceRequestFinancial(Long sequenceRequestFinancial) {
        this.sequenceRequestFinancial = sequenceRequestFinancial;
    }

}
