/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.utils;

import java.sql.BatchUpdateException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.exceptions.BatchException;

import com.ibm.websphere.batch.BatchContainerDataStreamException;
import com.ibm.websphere.batch.context.JobStepContextMgr;
import com.ibm.websphere.batch.devframework.configuration.BDSFWLogger;
import com.ibm.websphere.batch.devframework.configuration.BDSFrameworkConstants;
import com.ibm.websphere.batch.devframework.configuration.PerformanceAnalyzer;
import com.ibm.websphere.batch.devframework.datastreams.bdsadapter.AbstractBatchDataOutputStreamRecordMetrics;
import com.ibm.websphere.batch.devframework.datastreams.patternadapter.BDSJDBCWriter;
import com.ibm.websphere.batch.devframework.datastreams.patternadapter.IJDBCConnection;
import com.ibm.websphere.batch.devframework.datastreams.patternadapter.JDBCConnection;
import com.ibm.ws.gridcontainer.util.GridContainerConstants;

/**
 * Class JDBCWriterPreConceder.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class JDBCWriterPreConceder extends AbstractBatchDataOutputStreamRecordMetrics {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = -7823192873033928043L;

    /** Constante CLASSNAME. */
    public static final String CLASSNAME = BDSJDBCWriter.class.getName();

    /** jdbc writer impl. */
    protected JDBCWriterPatternPreConceder jdbcWriterImpl;

    /** logger. */
    protected BDSFWLogger logger;

    /** perf analyzer. */
    protected PerformanceAnalyzer perfAnalyzer = null;

    /** is performance measurement enabled. */
    protected boolean isPerformanceMeasurementEnabled = false;

    /** jdbc conn. */
    protected IJDBCConnection jdbcConn = null;

    /** Constante BATCHERINTERVALDEFAULT. */
    private static final int BATCHERINTERVALDEFAULT = 20;

    /** batch incrementor. */
    protected int batchIncrementor = 0;

    /** batcher interval. */
    protected int batcherInterval = 0;

    /** mapa pstmt. */
    protected LinkedHashMap<Integer, PreparedStatement> mapaPstmt = null;

    /** data written. */
    protected boolean dataWritten = false;

    /** force connection recycle. */
    protected boolean forceConnectionRecycle = false;

    /** mapa queries. */
    private LinkedHashMap<Integer, String> mapaQueries = null;

    /** batched records. */
    private List<Object> batchedRecords = null;

    /** disable batch update exception parsing. */
    protected final String DISABLE_BATCH_UPDATE_EXCEPTION_PARSING = "com.ibm.websphere.batch.devframework.datastreams.patternadapter.BDSJDBCWriter.disable.BatchUpdateException.parsing";

    /** always pass batch update exception to skip listener. */
    protected boolean alwaysPassBatchUpdateExceptionToSkipListener = false;

    /**
     * {@inheritDoc}
     */
    @Override
    public void open() throws BatchContainerDataStreamException {
        if (!forceConnectionRecycle)
            jdbcConn.open();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void close() throws BatchContainerDataStreamException {
        if (!forceConnectionRecycle)
            jdbcConn.close();
        if (isPerformanceMeasurementEnabled)
            perfAnalyzer.displayPerformanceStatisticsForEntity();
    }

    /**
     * Retorna o batcher interval.
     * 
     * @param props do tipo Properties
     * @return batcher interval
     */
    private Integer getBatcherInterval(Properties props) {
        String prop = props.getProperty(BDSFrameworkConstants.BATCH_INTERVAL_KEY);
        if (prop != null) {
            try {
                return Integer.valueOf(prop).intValue();
            } catch (Exception e) {
                logger.error("Invalid JDBC Batching interval specified. Defaulting to: " + batcherInterval);
                return BATCHERINTERVALDEFAULT;
            }
        } else {
            return BATCHERINTERVALDEFAULT;
        }
    }

    /**
     * Retorna o batch update exception.
     * 
     * @param props do tipo Properties
     * @return batch update exception
     */
    private Boolean getBatchUpdateException(Properties props) {
        String bueProp = props.getProperty(DISABLE_BATCH_UPDATE_EXCEPTION_PARSING);
        if (bueProp != null) {
            try {
                return Boolean.parseBoolean(bueProp);
            } catch (Exception e) {
                logger.error("Invalid BatchUpdateException-related property.  Defaulting to: false");
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new BDSFWLogger(props);
        perfAnalyzer = new PerformanceAnalyzer(CLASSNAME, props);
        isPerformanceMeasurementEnabled = perfAnalyzer.isEnabled();
        try {
            if (jdbcConn == null) {
                jdbcConn = new JDBCConnection();
                jdbcConn.initialize(props);
            }

            batcherInterval = getBatcherInterval(props);

            alwaysPassBatchUpdateExceptionToSkipListener = getBatchUpdateException(props);

            // Initialize record array
            batchedRecords = new ArrayList<Object>(batcherInterval);

            String jdbcWriterImplClass = props.getProperty(BDSFrameworkConstants.IMPLCLASS_KEY);
            // For backward compatibility
            if (jdbcWriterImplClass == null)
                jdbcWriterImplClass = getRequiredProperty(props, "IMPLCLASS");

            jdbcWriterImpl = (JDBCWriterPatternPreConceder) loadClass(jdbcWriterImplClass);
            if (logger.isDebugEnabled())
                logger.info("Loaded JDBCWriterPattern:" + jdbcWriterImplClass);
            jdbcWriterImpl.initialize(props);
            String forceConnRecycle = props.getProperty(BDSFrameworkConstants.FORCE_CONNECTION_RECYCLE, "false");

            if (forceConnRecycle.equalsIgnoreCase("true")) {
                forceConnectionRecycle = true;
            }

            if (logger.isDebugEnabled())
                logger.info("BDSJDBCWriter.initialize: setting forcing_connection_recycle to " + forceConnectionRecycle);
        } catch (Exception t) {
            throw new BatchException(t);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void flush() throws Exception {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void _write(Object record) throws Exception {
        String methodName = "write";
        if (isPerformanceMeasurementEnabled)
            perfAnalyzer.startMeasurement(methodName);

        String method = "write";
        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":" + method);

        dataWritten = true;

        for (Entry<Integer, PreparedStatement> pstmt : mapaPstmt.entrySet()) {
            int qtdeItensAdicionados = jdbcWriterImpl.writeRecord(pstmt, record);
            if ((pstmt != null) && (qtdeItensAdicionados > 0)) {
                batchIncrementor += qtdeItensAdicionados;
                mapaPstmt.put(pstmt.getKey(), pstmt.getValue());
            }
        }

        // Add new record to the list of batched records
        batchedRecords.add(record);

        if (batchIncrementor >= batcherInterval) {
            try {
                for (Entry<Integer, PreparedStatement> pstmt : mapaPstmt.entrySet()) {
                    pstmt.getValue().executeBatch();
                }
            } catch (SQLException sqle) {
                for (SQLException nextSqle = sqle; nextSqle != null; nextSqle = nextSqle.getNextException()) {
                    logger.error("batchExecute() exception: " + nextSqle.getLocalizedMessage());
                }
                logger.error(sqle.getMessage());
                BatchUpdateException bue = null;
                try {
                    bue = (BatchUpdateException) sqle;
                    doSkipHandlingForBatch(bue);
                } catch (ClassCastException e) {
                    throw sqle;
                }
            } finally {
                batchIncrementor = 0;
                batchedRecords.clear();
            }
        }

        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":" + method);
        if (isPerformanceMeasurementEnabled)
            perfAnalyzer.endMeasurementAndSave(methodName);
    }

    /**
     * Executa batch check point externo.
     * 
     * @throws Exception o exception
     */
    private void executaBatchCheckPointExterno() throws Exception {
        try {
            for (Entry<Integer, PreparedStatement> pstmt : mapaPstmt.entrySet()) {
                pstmt.getValue().executeBatch();
            }
        } catch (BatchUpdateException bue) {
            StringBuilder allMsg = new StringBuilder();
            for (SQLException nextSqle = bue; nextSqle != null; nextSqle = nextSqle.getNextException()) {
                logger.error("batchExecute() exception: " + nextSqle.getLocalizedMessage());
                allMsg.append(nextSqle.getLocalizedMessage() + "\n");
            }
            logger.error(bue.getMessage());
            doSkipHandlingForBatch(bue);
            for (Entry<Integer, PreparedStatement> pstmt : mapaPstmt.entrySet()) {
                pstmt.getValue().close();
                pstmt.setValue(null);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
        } finally {
            batchIncrementor = 0;
            batchedRecords.clear();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String _externalizeCheckpointInformation() {
        String method = "externalizeCheckpointInformation";

        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":" + method);
        try {
            if (dataWritten && (mapaPstmt.size() > 0)) {
                this.executaBatchCheckPointExterno();
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new BatchException(e);
        }

        if (this.forceConnectionRecycle) {
            try {
                if (logger.isDebugEnabled())
                    logger.info("BDSJDBCWriter.externalizeCheckpoint: forcing connection recycle, closing JDBC Connection");

                jdbcConn.close();
            } catch (BatchContainerDataStreamException e) {
                logger.error(e.getMessage());
                throw new BatchException(e);
            }
        }

        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":externalizeCheckpointInformation");
        return "NOTSET";
    }

    /**
     * Do skip handling for batch.
     * 
     * @param bue do tipo BatchUpdateException
     * @throws Exception o exception
     */
    protected void doSkipHandlingForBatch(BatchUpdateException bue) throws Exception {

        String method = "doSkipHandlingForBatch";

        int[] updateCounts = bue.getUpdateCounts();

        if (updateCounts.length < batchedRecords.size()) {
            disableSkipRollbackOnly();
            throw new BatchException("Batch update failed without executing all statements.  Throwing RuntimeException.", bue);
        }

        List<Object> skipCandidateList = new ArrayList<Object>();

        for (int i = 0; i < batchedRecords.size(); i++) {
            if (updateCounts[i] == Statement.EXECUTE_FAILED) {
                skipCandidateList.add(batchedRecords.get(i));
            }
        }

        List<SQLException> chainedNextSQLExceptionList = new ArrayList<SQLException>();
        SQLException e = bue;
        while (e.getNextException() != null) {
            chainedNextSQLExceptionList.add(e.getNextException());
            e = e.getNextException();
        }

        int numBadRecords = skipCandidateList.size();
        int numChainedExcs = chainedNextSQLExceptionList.size();

        if (numBadRecords == 0) {
            disableSkipRollbackOnly();
            throw new BatchException("caught a BatchUpdateException without any corresponding STATEMENT_FAILED records in getUpdateCounts().");
        } else if (numBadRecords == 1) {
            if (alwaysPassBatchUpdateExceptionToSkipListener) {
                handleException(bue, skipCandidateList.get(0));
            } else {
                handleException(chainedNextSQLExceptionList.get(0), skipCandidateList.get(0));
            }
        } else if (numBadRecords == numChainedExcs) {
            for (int i = 0; i < numChainedExcs; i++) {
                if (alwaysPassBatchUpdateExceptionToSkipListener) {
                    handleException(bue, skipCandidateList.get(i));
                } else {
                    handleException(chainedNextSQLExceptionList.get(i), skipCandidateList.get(i));
                }
            }
        } else {
            if (getSkipHandler().getSkipListener() != null) {
                for (Object record : skipCandidateList) {
                    handleException(bue, record);
                }
            } else {
                disableSkipRollbackOnly();
                throw new BatchException("Could not match chained exceptions with batched records.  Since there is no skip listener defined" + " to sort through the individual failures, we want to force a rollback.");
            }
        }

        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":" + method);
    }

    /**
     * Handle exception.
     * 
     * @param e do tipo Exception
     * @param record do tipo Object
     * @throws Exception o exception
     */
    protected void handleException(Exception e, Object record) throws Exception {
        try {
            getSkipHandler().handleException(e, record);
            setSkipMetric();
        } catch (Exception e1) {
            disableSkipRollbackOnly();
            throw e1;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void intermediateCheckpoint() {
        String methodName = "intermediateCheckpoint";
        logger.debug("intermediateCheckpoint### - CHAMOU");
        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":" + methodName);
        if (this.forceConnectionRecycle) {
            try {
                jdbcConn.open();
            } catch (BatchContainerDataStreamException e) {
                throw new BatchException(e);
            } catch (Exception e) {
                throw new BatchException(e);
            }

        }

        mapaQueries = jdbcWriterImpl.getStringsQueries();
        mapaPstmt = new LinkedHashMap<Integer, PreparedStatement>();
        try {
            for (Entry<Integer, String> querie : mapaQueries.entrySet()) {
                mapaPstmt.put(querie.getKey(), jdbcConn.getJDBCConnection().prepareStatement(querie.getValue()));
                logger.debug("ID: " + querie.getKey() + " VALOR: " + querie.getValue());
            }
        } catch (SQLException e) {
            throw new BatchException(e);
        }

        if (logger.isDebugEnabled())
            logger.debug(CLASSNAME + ":" + methodName);

    }

    /**
     * Disable skip rollback only.
     */
    private void disableSkipRollbackOnly() {
        Properties props = JobStepContextMgr.getContext().getProperties();
        if (props == null) {
            props = new Properties();
            JobStepContextMgr.getContext().setProperties(props);
        }
        props.setProperty(GridContainerConstants.DISABLE_SKIP_ROLLBACK_ONLY, "true");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void _internalizeCheckpointInformation(String arg0) {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void _positionAtCurrentCheckpoint() throws BatchContainerDataStreamException {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void writeHeader(Object arg0) throws Exception {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void positionAtInitialCheckpoint() throws BatchContainerDataStreamException {
        // TODO Auto-generated method stub

    }

}
