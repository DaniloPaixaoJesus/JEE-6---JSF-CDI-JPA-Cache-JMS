/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* Todos os direitos reservados.
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ====================================================================
*/
package br.com.brasilprev.bprpastaxatransbt.vo.step7;

import java.io.Serializable;

/**
* Class DadosSaldoVO.
* 
 * @author Diego Rodrigues do Nascimento (P51701802)
*/
public class MatriculaSemSaldoVO implements Serializable {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 6966345343727808208L;

    /** id requisicao. */
    private Long idRequisicao;

    /** id requisicao financeira. */
    private Long idRequisicaoFinanceira;
    
    /**  */
    private Long atividadePasso;
    
    /** */
    private boolean possuiSaldo;
    
    /**
     * @return the idRequisicao
     */
    public Long getIdRequisicao()
    {
        return idRequisicao;
    }

    /**
     * @param idRequisicao the idRequisicao to set
     */
    public void setIdRequisicao(Long idRequisicao)
    {
        this.idRequisicao = idRequisicao;
    }

    /**
     * @return the idRequisicaoFinanceira
     */
    public Long getIdRequisicaoFinanceira()
    {
        return idRequisicaoFinanceira;
    }

    /**
     * @param idRequisicaoFinanceira the idRequisicaoFinanceira to set
     */
    public void setIdRequisicaoFinanceira(Long idRequisicaoFinanceira)
    {
        this.idRequisicaoFinanceira = idRequisicaoFinanceira;
    }

    /**
     * @return the atividadePasso
     */
    public Long getAtividadePasso()
    {
        return atividadePasso;
    }


    /**
     * @param atividadePasso the atividadePasso to set
     */
    public void setAtividadePasso(Long atividadePasso)
    {
        this.atividadePasso = atividadePasso;
    }

    /**
     * @return the possuiSaldo
     */
    public boolean isPossuiSaldo()
    {
        return possuiSaldo;
    }

    /**
     * @param possuiSaldo the possuiSaldo to set
     */
    public void setPossuiSaldo(boolean possuiSaldo)
    {
        this.possuiSaldo = possuiSaldo;
    }

    @Override
    public String toString()
    {
        return "MatriculaSemSaldoVO [idRequisicao=" + idRequisicao + ", idRequisicaoFinanceira=" + idRequisicaoFinanceira + ", possuiSaldo=" + possuiSaldo + "]";
    }
    
}