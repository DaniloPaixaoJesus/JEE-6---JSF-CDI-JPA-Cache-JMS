/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.utils;

import java.util.Properties;

import com.ibm.websphere.batch.devframework.configuration.BDSFWLogger;

/**
 * Class LogBatch.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class LogBatch extends BDSFWLogger {

    /**
     * Cria uma nova instância de log batch.
     * 
     * @param props do tipo Properties
     */
    public LogBatch(Properties props) {
        super(props);
    }

    /**
     * {@inheritDoc}
     */
    public void debug(String message) {
        if (super.isDebugEnabled) {
            super.debug(message);
        }
    }

}
