/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprpastaxatransbt.exceptions;

/**
 * Class BatchException.
 *
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class BatchException extends RuntimeException {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 5922137075844849177L;
    
    /**
     * Cria uma nova instância de batch exception.
     */
    public BatchException() {
        super();
    }


    /**
     * Cria uma nova instância de batch exception.
     *
     * @param message do tipo String
     */
    public BatchException(String message)
    {
       super(message);
    }
    
    
    /**
     * Cria uma nova instância de batch exception.
     *
     * @param cause do tipo Throwable
     */
    public BatchException(Throwable cause) {
        super(cause);
    }
    
    
    /**
     * Cria uma nova instância de batch exception.
     *
     * @param message do tipo String
     * @param cause do tipo Throwable
     */
    public BatchException(String message, Throwable cause) {
        super(message, cause);
    }

}