/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.constants;

/**
 * Enum StringBatchConstants.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public enum StringBatchConstants {
     /** instance. */
    INSTANCE;

    /** Constante IDUSUARIOAPLICACAO. */
    public static final Long IDUSUARIOAPLICACAO = 42L;

    /** Constante EJB_CICLO_PROCESSAMENTO_SERVICE_DEV. */
    public static final String EJB_CICLO_PROCESSAMENTO_SERVICE_DEV = "ejb/bprcicloaplicacaodm/CicloProcessamentoRemote";

    /** Constante EJB_CICLO_PROCESSAMENTO_SERVICE. */
    public static final String EJB_CICLO_PROCESSAMENTO_SERVICE = "java:global/bprcicloaplicacaodm/bprcicloaplicacaodmejb/CicloProcessamentoServiceBean!br.com.brasilprev.bprcicloaplicacaodm.ejb.service.CicloProcessamentoRemote";

    /** Constante DATAPROCESSAMENTO. */
    public static final String DATAPROCESSAMENTO = "dataProcessamento";

    /** Constante EJB_PRODUTOS_DEV. */
    public static final String EJB_PRODUTOS_DEV = "ejb/bprprodutosdm/ProcessoSusepRemote";

    /** Constante EJB_PRODUTOS. */
    public static final String EJB_PRODUTOS = "java:global/bprprodutosdm/bprprodutosdmejb/ProcessoSusepServiceBean!br.com.brasilprev.bprprodutosdm.ejb.service.ProcessoSusepRemote";

    /** Constante EJB_CARREGAMENTO_DEV. */
    public static final String EJB_CARREGAMENTO_DEV = "ejb/bprcarregamentodm/CarregamentoServiceRemote";

    /** Constante EJB_CARREGAMENTO. */
    public static final String EJB_CARREGAMENTO = "java:global/bprcarregamentodm/bprcarregamentodmejb/CarregamentoServiceBean!br.com.brasilprev.bprcarregamentodm.ejb.service.CarregamentoServiceRemote";

    /** Constante EJB_SALDO_DISPONIVEL_MATRICULA_DEV. */
    public static final String EJB_SALDO_DISPONIVEL_MATRICULA_DEV = "ejb/bprsaldodm/SaldoDisponivelMatriculaServiceRemote";

    /** Constante EJB_SALDO_DISPONIVEL_MATRICULA. */
    public static final String EJB_SALDO_DISPONIVEL_MATRICULA = "java:global/bprsaldodm/bprsaldodmejb/SaldoDisponivelMatriculaServiceBean!br.com.brasilprev.bprsaldodm.ejb.service.SaldoDisponivelMatriculaServiceRemote";

    /** Constante ID_IDIOMA. */
    public static final Long ID_IDIOMA = 1L;
}
