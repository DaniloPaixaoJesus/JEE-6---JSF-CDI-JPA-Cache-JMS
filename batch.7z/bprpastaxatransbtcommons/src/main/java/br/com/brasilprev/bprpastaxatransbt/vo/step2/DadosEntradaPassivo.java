/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.vo.step2;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;

/**
 * Class DadosEntradaPassivo.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class DadosEntradaPassivo implements Serializable {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 4072680014412303788L;

    /** data solicitacao. */
    private Date dataSolicitacao;

    /** id matricula. */
    private Long idMatricula;

    /** id requisicao. */
    private Long idRequisicao;

    /** id requisicao financeira. */
    private Long idRequisicaoFinanceira;

    /** protocolo. */
    private Long protocolo;

    /** tipo operacao. */
    private Long tipoOperacao;

    /** tipo transacao. */
    private Long tipoTransacao;

    /** id atividade passo. */
    private Long idAtividadePasso;

    /** qtde linha. */
    private int qtdeLinha;

    /** qtde linha restante. */
    private int qtdeLinhaRestante;

    /** marcacao dinheiro. */
    private MarcacaoDinheiroVO marcacaoDinheiro;

    /** lista marcacao dinheiro. */
    private List<MarcacaoDinheiroVO> listaMarcacaoDinheiro;

    /** id lancamento. */
    private Long idLancamento;

    private Date dataCota;

    private Long idRequisicaoAtividade;

    private BigDecimal valorTotalCota;

    /**
     * Retorna o data solicitacao.
     * 
     * @return data solicitacao
     */
    public Date getDataSolicitacao() {
        return dataSolicitacao;
    }

    /**
     * Atribui valor a data solicitacao.
     * 
     * @param dataSolicitacao atribui novo valor a data solicitacao
     */
    public void setDataSolicitacao(Date dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }

    /**
     * Retorna o id matricula.
     * 
     * @return id matricula
     */
    public Long getIdMatricula() {
        return idMatricula;
    }

    /**
     * Atribui valor a id matricula.
     * 
     * @param idMatricula atribui novo valor a id matricula
     */
    public void setIdMatricula(Long idMatricula) {
        this.idMatricula = idMatricula;
    }

    /**
     * Retorna o id requisicao.
     * 
     * @return id requisicao
     */
    public Long getIdRequisicao() {
        return idRequisicao;
    }

    /**
     * Atribui valor a id requisicao.
     * 
     * @param idRequisicao atribui novo valor a id requisicao
     */
    public void setIdRequisicao(Long idRequisicao) {
        this.idRequisicao = idRequisicao;
    }

    /**
     * Retorna o id requisicao financeira.
     * 
     * @return id requisicao financeira
     */
    public Long getIdRequisicaoFinanceira() {
        return idRequisicaoFinanceira;
    }

    /**
     * Atribui valor a id requisicao financeira.
     * 
     * @param idRequisicaoFinanceira atribui novo valor a id requisicao financeira
     */
    public void setIdRequisicaoFinanceira(Long idRequisicaoFinanceira) {
        this.idRequisicaoFinanceira = idRequisicaoFinanceira;
    }

    /**
     * Retorna o protocolo.
     * 
     * @return protocolo
     */
    public Long getProtocolo() {
        return protocolo;
    }

    /**
     * Atribui valor a protocolo.
     * 
     * @param protocolo atribui novo valor a protocolo
     */
    public void setProtocolo(Long protocolo) {
        this.protocolo = protocolo;
    }

    /**
     * Retorna o tipo operacao.
     * 
     * @return tipo operacao
     */
    public Long getTipoOperacao() {
        return tipoOperacao;
    }

    /**
     * Atribui valor a tipo operacao.
     * 
     * @param tipoOperacao atribui novo valor a tipo operacao
     */
    public void setTipoOperacao(Long tipoOperacao) {
        this.tipoOperacao = tipoOperacao;
    }

    /**
     * Retorna o tipo transacao.
     * 
     * @return tipo transacao
     */
    public Long getTipoTransacao() {
        return tipoTransacao;
    }

    /**
     * Atribui valor a tipo transacao.
     * 
     * @param tipoTransacao atribui novo valor a tipo transacao
     */
    public void setTipoTransacao(Long tipoTransacao) {
        this.tipoTransacao = tipoTransacao;
    }

    /**
     * Retorna o id atividade passo.
     * 
     * @return id atividade passo
     */
    public Long getIdAtividadePasso() {
        return idAtividadePasso;
    }

    /**
     * Atribui valor a id atividade passo.
     * 
     * @param idAtividadePasso atribui novo valor a id atividade passo
     */
    public void setIdAtividadePasso(Long idAtividadePasso) {
        this.idAtividadePasso = idAtividadePasso;
    }

    /**
     * Retorna o qtde linha.
     * 
     * @return qtde linha
     */
    public int getQtdeLinha() {
        return qtdeLinha;
    }

    /**
     * Atribui valor a qtde linha.
     * 
     * @param qtdeLinha atribui novo valor a qtde linha
     */
    public void setQtdeLinha(int qtdeLinha) {
        this.qtdeLinha = qtdeLinha;
    }

    /**
     * Retorna o qtde linha restante.
     * 
     * @return qtde linha restante
     */
    public int getQtdeLinhaRestante() {
        return qtdeLinhaRestante;
    }

    /**
     * Atribui valor a qtde linha restante.
     * 
     * @param qtdeLinhaRestante atribui novo valor a qtde linha restante
     */
    public void setQtdeLinhaRestante(int qtdeLinhaRestante) {
        this.qtdeLinhaRestante = qtdeLinhaRestante;
    }

    /**
     * Retorna o marcacao dinheiro.
     * 
     * @return marcacao dinheiro
     */
    public MarcacaoDinheiroVO getMarcacaoDinheiro() {
        return marcacaoDinheiro;
    }

    /**
     * Atribui valor a marcacao dinheiro.
     * 
     * @param marcacaoDinheiro atribui novo valor a marcacao dinheiro
     */
    public void setMarcacaoDinheiro(MarcacaoDinheiroVO marcacaoDinheiro) {
        this.marcacaoDinheiro = marcacaoDinheiro;
    }

    /**
     * Retorna o lista marcacao dinheiro.
     * 
     * @return lista marcacao dinheiro
     */
    public List<MarcacaoDinheiroVO> getListaMarcacaoDinheiro() {
        return listaMarcacaoDinheiro;
    }

    /**
     * Atribui valor a lista marcacao dinheiro.
     * 
     * @param listaMarcacaoDinheiro atribui novo valor a lista marcacao dinheiro
     */
    public void setListaMarcacaoDinheiro(List<MarcacaoDinheiroVO> listaMarcacaoDinheiro) {
        this.listaMarcacaoDinheiro = listaMarcacaoDinheiro;
    }

    /**
     * Adds the lista marcacao dinheiro.
     * 
     * @param marcacaoDinheiroVO do tipo MarcacaoDinheiroVO
     */
    public void addListaMarcacaoDinheiro(MarcacaoDinheiroVO marcacaoDinheiroVO) {
        this.setValorTotalCota(this.getValorTotalCota().add(marcacaoDinheiroVO.getValorTotal()));
        this.listaMarcacaoDinheiro.add(marcacaoDinheiroVO);
    }

    /**
     * @return Retorna idLancamento
     */
    public Long getIdLancamento() {
        return idLancamento;
    }

    /**
     * @param idLancamento Define idLancamento
     */
    public void setIdLancamento(Long idLancamento) {
        this.idLancamento = idLancamento;
    }

    /**
     * @return Retorna dataCota
     */
    public Date getDataCota() {
        return dataCota;
    }

    /**
     * @param dataCota Define dataCota
     */
    public void setDataCota(Date dataCota) {
        this.dataCota = dataCota;
    }

    /**
     * @return Retorna idRequisicaoAtividade
     */
    public Long getIdRequisicaoAtividade() {
        return idRequisicaoAtividade;
    }

    /**
     * @param idRequisicaoAtividade Define idRequisicaoAtividade
     */
    public void setIdRequisicaoAtividade(Long idRequisicaoAtividade) {
        this.idRequisicaoAtividade = idRequisicaoAtividade;
    }

    /**
     * @return Retorna valorTotalCota
     */
    public BigDecimal getValorTotalCota() {
        return valorTotalCota;
    }

    /**
     * @param valorTotalCota Define valorTotalCota
     */
    public void setValorTotalCota(BigDecimal valorTotalCota) {
        this.valorTotalCota = valorTotalCota;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "DadosEntradaPassivo [dataSolicitacao=" + dataSolicitacao + ", idMatricula=" + idMatricula + ", idRequisicao=" + idRequisicao + ", idRequisicaoFinanceira=" + idRequisicaoFinanceira + ", protocolo=" + protocolo + ", tipoOperacao="
                + tipoOperacao + ", tipoTransacao=" + tipoTransacao + ", idAtividadePasso=" + idAtividadePasso + ", qtdeLinha=" + qtdeLinha + ", qtdeLinhaRestante=" + qtdeLinhaRestante + ", marcacaoDinheiro=" + marcacaoDinheiro
                + ", listaMarcacaoDinheiro=" + listaMarcacaoDinheiro + "]";
    }


}