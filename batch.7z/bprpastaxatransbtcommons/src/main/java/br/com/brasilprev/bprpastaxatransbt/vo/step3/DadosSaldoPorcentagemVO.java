/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.vo.step3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;

/**
 * Class DadosSaldoPorcentagemVO.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class DadosSaldoPorcentagemVO implements Serializable {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 6966345343727808208L;

    /** data solicitada. */
    private Date dataSolicitada;

    /** id matricula. */
    private Long idMatricula;

    /** id requisicao. */
    private Long idRequisicao;

    /** id requisicao financeira. */
    private Long idRequisicaoFinanceira;

    /** id protocolo. */
    private Long idProtocolo;

    /** tipo trasacao. */
    private Long tipoTrasacao;

    /** id atividade passo. */
    private Long idAtividadePasso;

    /** id lancamento. */
    private Long idLancamento;

    /** qtde itens restantes matricula. */
    private int qtdeItensRestantesMatricula;

    /** utiliza dinheiro entidade fechada. */
    private String utilizaDinheiroEntidadeFechada;

    /** marcacao dinheiro. */
    private MarcacaoDinheiroVO marcacaoDinheiro;

    /** lista marcacao dinheiro. */
    private List<MarcacaoDinheiroVO> listaMarcacaoDinheiro;

    /** id requisicao atividade. */
    private Long idRequisicaoAtividade;

    /** qtde linhas marcacao. */
    private int qtdeLinhasMarcacao;

    /** porcentagem. */
    private BigDecimal porcentagem = BigDecimal.ZERO;

    /** valor cota. */
    private BigDecimal valorCota = BigDecimal.ZERO;

    /** valor total solicitado. */
    private BigDecimal valorTotalSolicitado;

    /** data cota. */
    private Date dataCota;

    private Long tipoOperacao;

    /** total acumulado calculo arredondamento. */
    private BigDecimal restoValorNominalDisponivel = BigDecimal.ZERO;

    private BigDecimal restoValorTotal = BigDecimal.ZERO;

    /**
     * Retorna o data solicitada.
     * 
     * @return data solicitada
     */
    public Date getDataSolicitada() {
        return dataSolicitada;
    }

    /**
     * Atribui valor a data solicitada.
     * 
     * @param dataSolicitada atribui novo valor a data solicitada
     */
    public void setDataSolicitada(Date dataSolicitada) {
        this.dataSolicitada = dataSolicitada;
    }

    /**
     * Retorna o id matricula.
     * 
     * @return id matricula
     */
    public Long getIdMatricula() {
        return idMatricula;
    }

    /**
     * Atribui valor a id matricula.
     * 
     * @param idMatricula atribui novo valor a id matricula
     */
    public void setIdMatricula(Long idMatricula) {
        this.idMatricula = idMatricula;
    }

    /**
     * Retorna o id requisicao.
     * 
     * @return id requisicao
     */
    public Long getIdRequisicao() {
        return idRequisicao;
    }

    /**
     * Atribui valor a id requisicao.
     * 
     * @param idRequisicao atribui novo valor a id requisicao
     */
    public void setIdRequisicao(Long idRequisicao) {
        this.idRequisicao = idRequisicao;
    }

    /**
     * Retorna o id requisicao financeira.
     * 
     * @return id requisicao financeira
     */
    public Long getIdRequisicaoFinanceira() {
        return idRequisicaoFinanceira;
    }

    /**
     * Atribui valor a id requisicao financeira.
     * 
     * @param idRequisicaoFinanceira atribui novo valor a id requisicao financeira
     */
    public void setIdRequisicaoFinanceira(Long idRequisicaoFinanceira) {
        this.idRequisicaoFinanceira = idRequisicaoFinanceira;
    }



    /**
     * Retorna o id protocolo.
     * 
     * @return id protocolo
     */
    public Long getIdProtocolo() {
        return idProtocolo;
    }

    /**
     * Atribui valor a id protocolo.
     * 
     * @param idProtocolo atribui novo valor a id protocolo
     */
    public void setIdProtocolo(Long idProtocolo) {
        this.idProtocolo = idProtocolo;
    }

    /**
     * Retorna o tipo trasacao.
     * 
     * @return tipo trasacao
     */
    public Long getTipoTrasacao() {
        return tipoTrasacao;
    }

    /**
     * Atribui valor a tipo trasacao.
     * 
     * @param tipoTrasacao atribui novo valor a tipo trasacao
     */
    public void setTipoTrasacao(Long tipoTrasacao) {
        this.tipoTrasacao = tipoTrasacao;
    }

    /**
     * Retorna o id atividade passo.
     * 
     * @return id atividade passo
     */
    public Long getIdAtividadePasso() {
        return idAtividadePasso;
    }

    /**
     * Atribui valor a id atividade passo.
     * 
     * @param idAtividadePasso atribui novo valor a id atividade passo
     */
    public void setIdAtividadePasso(Long idAtividadePasso) {
        this.idAtividadePasso = idAtividadePasso;
    }

    /**
     * Retorna o id lancamento.
     * 
     * @return id lancamento
     */
    public Long getIdLancamento() {
        return idLancamento;
    }

    /**
     * Atribui valor a id lancamento.
     * 
     * @param idLancamento atribui novo valor a id lancamento
     */
    public void setIdLancamento(Long idLancamento) {
        this.idLancamento = idLancamento;
    }

    /**
     * Retorna o qtde itens restantes matricula.
     * 
     * @return qtde itens restantes matricula
     */
    public int getQtdeItensRestantesMatricula() {
        return qtdeItensRestantesMatricula;
    }

    /**
     * Atribui valor a qtde itens restantes matricula.
     * 
     * @param qtdeItensRestantesMatricula atribui novo valor a qtde itens restantes matricula
     */
    public void setQtdeItensRestantesMatricula(int qtdeItensRestantesMatricula) {
        this.qtdeItensRestantesMatricula = qtdeItensRestantesMatricula;
    }

    /**
     * Retorna o utiliza dinheiro entidade fechada.
     * 
     * @return utiliza dinheiro entidade fechada
     */
    public String getUtilizaDinheiroEntidadeFechada() {
        return utilizaDinheiroEntidadeFechada;
    }

    /**
     * Atribui valor a utiliza dinheiro entidade fechada.
     * 
     * @param utilizaDinheiroEntidadeFechada atribui novo valor a utiliza dinheiro entidade fechada
     */
    public void setUtilizaDinheiroEntidadeFechada(String utilizaDinheiroEntidadeFechada) {
        this.utilizaDinheiroEntidadeFechada = utilizaDinheiroEntidadeFechada;
    }

    /**
     * Retorna o marcacao dinheiro.
     * 
     * @return marcacao dinheiro
     */
    public MarcacaoDinheiroVO getMarcacaoDinheiro() {
        return marcacaoDinheiro;
    }

    /**
     * Atribui valor a marcacao dinheiro.
     * 
     * @param marcacaoDinheiro atribui novo valor a marcacao dinheiro
     */
    public void setMarcacaoDinheiro(MarcacaoDinheiroVO marcacaoDinheiro) {
        this.marcacaoDinheiro = marcacaoDinheiro;
    }

    /**
     * Retorna o lista marcacao dinheiro.
     * 
     * @return lista marcacao dinheiro
     */
    public List<MarcacaoDinheiroVO> getListaMarcacaoDinheiro() {
        return listaMarcacaoDinheiro;
    }

    /**
     * Atribui valor a lista marcacao dinheiro.
     * 
     * @param listaMarcacaoDinheiro atribui novo valor a lista marcacao dinheiro
     */
    public void setListaMarcacaoDinheiro(List<MarcacaoDinheiroVO> listaMarcacaoDinheiro) {
        this.listaMarcacaoDinheiro = listaMarcacaoDinheiro;
    }


    /**
     * Retorna o qtde linhas marcacao.
     * 
     * @return qtde linhas marcacao
     */
    public int getQtdeLinhasMarcacao() {
        return qtdeLinhasMarcacao;
    }

    /**
     * Atribui valor a qtde linhas marcacao.
     * 
     * @param qtdeLinhasMarcacao atribui novo valor a qtde linhas marcacao
     */
    public void setQtdeLinhasMarcacao(int qtdeLinhasMarcacao) {
        this.qtdeLinhasMarcacao = qtdeLinhasMarcacao;
    }

    /**
     * Adds the marcacao dinheiro ao calculo.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     */
    public void addMarcacaoDinheiroAoCalculo(MarcacaoDinheiroVO marcacaoDinheiro) {
        if (this.getUtilizaDinheiroEntidadeFechada().equals("S") || (this.getUtilizaDinheiroEntidadeFechada().equals("N") && marcacaoDinheiro.getEhEntidadeFechada().equals("N"))) {
            this.calculaValorNominalRedimento(marcacaoDinheiro, this.getPorcentagem());
            this.setValorTotalSolicitado(this.getValorTotalSolicitado().add(marcacaoDinheiro.getValorTotal()));
            this.getListaMarcacaoDinheiro().add(marcacaoDinheiro);
        }
    }


    /**
     * Calcula valor nominal redimento.
     * 
     * @param marcacaoDinheiro do tipo MarcacaoDinheiroVO
     * @param porcentagem do tipo BigDecimal
     */
    private void calculaValorNominalRedimento(MarcacaoDinheiroVO marcacaoDinheiro, BigDecimal porcentagem) {
        BigDecimal valorNominal = BigDecimal.ZERO;
        BigDecimal valorRendimento = BigDecimal.ZERO;

        if (marcacaoDinheiro.getValorNominalDisponivel().compareTo(BigDecimal.ZERO) > 0) {
            valorNominal = MathUtil.multiplicar(marcacaoDinheiro.getValorNominalDisponivel(), porcentagem);
        }

        if (marcacaoDinheiro.getValorRendimento().compareTo(BigDecimal.ZERO) > 0) {
            valorRendimento = MathUtil.multiplicar(marcacaoDinheiro.getValorRendimento(), porcentagem);
        }

        marcacaoDinheiro.setValorNominalDisponivel(valorNominal);
        marcacaoDinheiro.setValorRendimento(valorRendimento);

        marcacaoDinheiro.setValorTotal(MathUtil.somar(valorNominal, valorRendimento));
        BigDecimal valorCotaUtilizado = MathUtil.dividir(marcacaoDinheiro.getValorTotal(), this.getValorCota());
        marcacaoDinheiro.setCotaUtilizada(valorCotaUtilizado);

    }


    /**
     * Retorna o id requisicao atividade.
     * 
     * @return id requisicao atividade
     */
    public Long getIdRequisicaoAtividade() {
        return idRequisicaoAtividade;
    }

    /**
     * Atribui valor a id requisicao atividade.
     * 
     * @param idRequisicaoAtividade atribui novo valor a id requisicao atividade
     */
    public void setIdRequisicaoAtividade(Long idRequisicaoAtividade) {
        this.idRequisicaoAtividade = idRequisicaoAtividade;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((idRequisicaoFinanceira == null) ? 0 : idRequisicaoFinanceira.hashCode());
        return result;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DadosSaldoPorcentagemVO other = (DadosSaldoPorcentagemVO) obj;
        if (idRequisicaoFinanceira == null) {
            if (other.idRequisicaoFinanceira != null)
                return false;
        } else if (!idRequisicaoFinanceira.equals(other.idRequisicaoFinanceira))
            return false;
        return true;
    }


    /**
     * Retorna o porcentagem.
     * 
     * @return porcentagem
     */
    public BigDecimal getPorcentagem() {
        return porcentagem;
    }

    /**
     * Atribui valor a porcentagem.
     * 
     * @param porcentagem atribui novo valor a porcentagem
     */
    public void setPorcentagem(BigDecimal porcentagem) {
        this.porcentagem = porcentagem;
    }

    /**
     * Retorna o data cota.
     * 
     * @return data cota
     */
    public Date getDataCota() {
        return dataCota;
    }

    /**
     * Atribui valor a data cota.
     * 
     * @param dataCota atribui novo valor a data cota
     */
    public void setDataCota(Date dataCota) {
        this.dataCota = dataCota;
    }

    /**
     * Retorna o valor cota.
     * 
     * @return valor cota
     */
    public BigDecimal getValorCota() {
        return valorCota;
    }

    /**
     * Atribui valor a valor cota.
     * 
     * @param valorCota atribui novo valor a valor cota
     */
    public void setValorCota(BigDecimal valorCota) {
        this.valorCota = valorCota;
    }

    /**
     * Retorna o valor total solicitado.
     * 
     * @return valor total solicitado
     */
    public BigDecimal getValorTotalSolicitado() {
        return valorTotalSolicitado;
    }

    /**
     * Atribui valor a valor total solicitado.
     * 
     * @param valorTotalSolicitado atribui novo valor a valor total solicitado
     */
    public void setValorTotalSolicitado(BigDecimal valorTotalSolicitado) {
        this.valorTotalSolicitado = valorTotalSolicitado;
    }

    /**
     * @return Retorna tipoOperacao
     */
    public Long getTipoOperacao() {
        return tipoOperacao;
    }

    /**
     * @param tipoOperacao Define tipoOperacao
     */
    public void setTipoOperacao(Long tipoOperacao) {
        this.tipoOperacao = tipoOperacao;
    }

    /**
     * @return Retorna restoValorNominalDisponivel
     */
    public BigDecimal getRestoValorNominalDisponivel() {
        return restoValorNominalDisponivel;
    }

    /**
     * @param restoValorNominalDisponivel Define restoValorNominalDisponivel
     */
    public void setRestoValorNominalDisponivel(BigDecimal restoValorNominalDisponivel) {
        this.restoValorNominalDisponivel = restoValorNominalDisponivel;
    }

    /**
     * @return Retorna restoValorTotal
     */
    public BigDecimal getRestoValorTotal() {
        return restoValorTotal;
    }

    /**
     * @param restoValorTotal Define restoValorTotal
     */
    public void setRestoValorTotal(BigDecimal restoValorTotal) {
        this.restoValorTotal = restoValorTotal;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "DadosSaldoPorcentagemVO [dataSolicitada=" + dataSolicitada + ", idMatricula=" + idMatricula + ", idRequisicao=" + idRequisicao + ", idRequisicaoFinanceira=" + idRequisicaoFinanceira + ", idProtocolo=" + idProtocolo
                + ", tipoTrasacao=" + tipoTrasacao + ", idAtividadePasso=" + idAtividadePasso + ", idLancamento=" + idLancamento + ", qtdeItensRestantesMatricula=" + qtdeItensRestantesMatricula + ", utilizaDinheiroEntidadeFechada="
                + utilizaDinheiroEntidadeFechada + ", marcacaoDinheiro=" + marcacaoDinheiro + ", listaMarcacaoDinheiro=" + listaMarcacaoDinheiro + ", idRequisicaoAtividade=" + idRequisicaoAtividade + ", qtdeLinhasMarcacao=" + qtdeLinhasMarcacao
                + ", porcentagem=" + porcentagem + ", valorCota=" + valorCota + "]";
    }



}
