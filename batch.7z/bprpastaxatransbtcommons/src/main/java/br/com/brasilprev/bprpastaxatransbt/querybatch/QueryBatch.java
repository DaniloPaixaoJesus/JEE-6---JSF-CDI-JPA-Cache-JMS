package br.com.brasilprev.bprpastaxatransbt.querybatch;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map.Entry;

/**
 * 
 * @author Danilo Paixao (P51701504)
 *
 */
public interface QueryBatch {
    public Integer addBatch(Entry<QueryBatch, PreparedStatement> pstmt, Object record) throws SQLException;
    public String getQuery();
}
