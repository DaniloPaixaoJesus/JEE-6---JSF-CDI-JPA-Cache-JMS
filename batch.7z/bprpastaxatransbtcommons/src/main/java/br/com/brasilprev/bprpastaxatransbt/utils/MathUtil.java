package br.com.brasilprev.bprpastaxatransbt.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step3.DadosSaldoPorcentagemVO;

/**
 * Class MathUtil.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class MathUtil {

    private static final BigDecimal UMCENTAVO = new BigDecimal("0.01");

    /**
     * Multiplicar.
     * 
     * @param primeiroValor do tipo BigDecimal
     * @param segundoValor do tipo BigDecimal
     * @return BigDecimal
     */
    public static BigDecimal multiplicar(BigDecimal primeiroValor, BigDecimal segundoValor) {
        return primeiroValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP).multiply(segundoValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP)).setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP);
    }

    /**
     * Dividir.
     * 
     * @param primeiroValor do tipo BigDecimal
     * @param segundoValor do tipo BigDecimal
     * @return BigDecimal
     */
    public static BigDecimal dividir(BigDecimal primeiroValor, BigDecimal segundoValor) {
        return primeiroValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP).divide(segundoValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP), NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP);
    }

    /**
     * Somar.
     * 
     * @param primeiroValor do tipo BigDecimal
     * @param segundoValor do tipo BigDecimal
     * @return BigDecimal
     */
    public static BigDecimal somar(BigDecimal primeiroValor, BigDecimal segundoValor) {
        return primeiroValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP).add(segundoValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP)).setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP);
    }

    /**
     * Subtrair.
     * 
     * @param primeiroValor do tipo BigDecimal
     * @param segundoValor do tipo BigDecimal
     * @return BigDecimal
     */
    public static BigDecimal subtrair(BigDecimal primeiroValor, BigDecimal segundoValor) {
        return primeiroValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP).subtract(segundoValor.setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP)).setScale(NumerosInteiros.DEZESSEIS, RoundingMode.HALF_UP);
    }

    /**
     * Formatar dinheiro.
     * 
     * @param valor do tipo BigDecimal
     * @return BigDecimal
     */
    public static BigDecimal formatarDinheiro(BigDecimal valor) {
        return valor.setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP);
    }

    /**
     * Calcular resto.
     * 
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param marcacaoDinheiroVO do tipo MarcacaoDinheiroVO
     * @param qtde do tipo int
     */
    public static void calcularResto(DadosSaldoVO dadosSaldoVO, MarcacaoDinheiroVO marcacaoDinheiroVO, int qtde) {
        BigDecimal valoTotal = marcacaoDinheiroVO.getValorTotal();
        if ((qtde == 0) || (dadosSaldoVO.getRestoValorTotal().compareTo(UMCENTAVO) >= 0)) {
            valoTotal = valoTotal.add(dadosSaldoVO.getRestoValorTotal());
            valoTotal = valoTotal.setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP);
            dadosSaldoVO.setRestoValorNominalDisponivel(BigDecimal.ZERO);
            dadosSaldoVO.setRestoValorTotal(BigDecimal.ZERO);
        } else {
            BigDecimal tempValorTotal = valoTotal;
            valoTotal = valoTotal.setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP);
            tempValorTotal = tempValorTotal.subtract(valoTotal);
            dadosSaldoVO.setRestoValorTotal(dadosSaldoVO.getRestoValorTotal().add(tempValorTotal));
        }
        marcacaoDinheiroVO.setValorTotal(valoTotal);
        dadosSaldoVO.setValorTotalSolicitado(dadosSaldoVO.getValorTotalSolicitado().add(valoTotal));
    }

    /**
     * Calcular resto.
     * 
     * @param dadosSaldoPorcentagemVO do tipo DadosSaldoPorcentagemVO
     * @param marcacaoDinheiroVO do tipo MarcacaoDinheiroVO
     * @param qtde do tipo int
     */
    public static void calcularResto(DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO, MarcacaoDinheiroVO marcacaoDinheiroVO, int qtde) {
        BigDecimal valoTotal = marcacaoDinheiroVO.getValorTotal();
        if ((qtde == 0) || (dadosSaldoPorcentagemVO.getRestoValorTotal().compareTo(UMCENTAVO) >= 0)) {
            valoTotal = valoTotal.add(dadosSaldoPorcentagemVO.getRestoValorTotal());
            valoTotal = valoTotal.setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP);
            dadosSaldoPorcentagemVO.setRestoValorNominalDisponivel(BigDecimal.ZERO);
            dadosSaldoPorcentagemVO.setRestoValorTotal(BigDecimal.ZERO);
        } else {
            BigDecimal tempValorTotal = valoTotal;
            valoTotal = valoTotal.setScale(NumerosInteiros.DOIS, RoundingMode.HALF_UP);
            tempValorTotal = tempValorTotal.subtract(valoTotal);
            dadosSaldoPorcentagemVO.setRestoValorTotal(dadosSaldoPorcentagemVO.getRestoValorTotal().add(tempValorTotal));
        }
        marcacaoDinheiroVO.setValorTotal(valoTotal);
    }
}
