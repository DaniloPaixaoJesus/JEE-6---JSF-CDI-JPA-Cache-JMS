/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * 
 * Todos os direitos reservados.
 * 
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ==================================================================== 
 */
package br.com.brasilprev.bprpastaxatransbt.vo;

/**
 * Class ProtocoloSusepVO.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProtocoloSusepVO {

    /** id susep. */
    private Long idSusep;

    /** id protocolo. */
    private Long idProtocolo;

    /**
     * Retorna o id susep.
     * 
     * @return id susep
     */
    public Long getIdSusep() {
        return idSusep;
    }

    /**
     * Atribui valor a id susep.
     * 
     * @param idSusep atribui novo valor a id susep
     */
    public void setIdSusep(Long idSusep) {
        this.idSusep = idSusep;
    }

    /**
     * Retorna o id protocolo.
     * 
     * @return id protocolo
     */
    public Long getIdProtocolo() {
        return idProtocolo;
    }

    /**
     * Atribui valor a id protocolo.
     * 
     * @param idProtocolo atribui novo valor a id protocolo
     */
    public void setIdProtocolo(Long idProtocolo) {
        this.idProtocolo = idProtocolo;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ProtocoloSusepVO [idSusep=" + idSusep + ", idProtocolo=" + idProtocolo + "]";
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((idProtocolo == null) ? 0 : idProtocolo.hashCode());
        result = (prime * result) + ((idSusep == null) ? 0 : idSusep.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProtocoloSusepVO other = (ProtocoloSusepVO) obj;
        if (idProtocolo == null) {
            if (other.idProtocolo != null)
                return false;
        } else if (!idProtocolo.equals(other.idProtocolo))
            return false;
        if (idSusep == null) {
            if (other.idSusep != null)
                return false;
        } else if (!idSusep.equals(other.idSusep))
            return false;
        return true;
    }

}
