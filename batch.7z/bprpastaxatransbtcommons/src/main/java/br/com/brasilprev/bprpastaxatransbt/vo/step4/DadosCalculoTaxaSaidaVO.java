/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.vo.step4;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Class DadosCalculoTaxaSaidaVO.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class DadosCalculoTaxaSaidaVO implements Serializable {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 4072680014412303788L;

    /** work transacao. */
    private Long workTransacao;

    /** id requisicao financeira. */
    private Long idRequisicaoFinanceira;

    /** id requisicao financeira inv. */
    private Long idRequisicaoFinanceiraInv;

    /** isento SN. */
    private String isentoSN;

    /** id protocolo. */
    private Long idProtocolo;

    /** id susep. */
    private Long idSusep;

    /** valor bruto. */
    private BigDecimal valorBruto;

    /** data solicitacao. */
    private Date dataSolicitacao;

    /** id taxa. */
    private Long idTaxa;

    /** percentual. */
    private BigDecimal percentual;

    /** valor taxa. */
    private BigDecimal valorTaxa;

    /**
     * Retorna o work transacao.
     * 
     * @return work transacao
     */
    public Long getWorkTransacao() {
        return workTransacao;
    }

    /**
     * Atribui valor a work transacao.
     * 
     * @param workTransacao atribui novo valor a work transacao
     */
    public void setWorkTransacao(Long workTransacao) {
        this.workTransacao = workTransacao;
    }

    /**
     * Retorna o id requisicao financeira.
     * 
     * @return id requisicao financeira
     */
    public Long getIdRequisicaoFinanceira() {
        return idRequisicaoFinanceira;
    }

    /**
     * Atribui valor a id requisicao financeira.
     * 
     * @param idRequisicaoFinanceira atribui novo valor a id requisicao financeira
     */
    public void setIdRequisicaoFinanceira(Long idRequisicaoFinanceira) {
        this.idRequisicaoFinanceira = idRequisicaoFinanceira;
    }

    /**
     * Retorna o id requisicao financeira inv.
     * 
     * @return id requisicao financeira inv
     */
    public Long getIdRequisicaoFinanceiraInv() {
        return idRequisicaoFinanceiraInv;
    }

    /**
     * Atribui valor a id requisicao financeira inv.
     * 
     * @param idRequisicaoFinanceiraInv atribui novo valor a id requisicao financeira inv
     */
    public void setIdRequisicaoFinanceiraInv(Long idRequisicaoFinanceiraInv) {
        this.idRequisicaoFinanceiraInv = idRequisicaoFinanceiraInv;
    }

    /**
     * Retorna o isento SN.
     * 
     * @return isento SN
     */
    public String getIsentoSN() {
        return isentoSN;
    }

    /**
     * Atribui valor a isento SN.
     * 
     * @param isentoSN atribui novo valor a isento SN
     */
    public void setIsentoSN(String isentoSN) {
        this.isentoSN = isentoSN;
    }

    /**
     * Retorna o id protocolo.
     * 
     * @return id protocolo
     */
    public Long getIdProtocolo() {
        return idProtocolo;
    }

    /**
     * Atribui valor a id protocolo.
     * 
     * @param idProtocolo atribui novo valor a id protocolo
     */
    public void setIdProtocolo(Long idProtocolo) {
        this.idProtocolo = idProtocolo;
    }

    /**
     * Retorna o id susep.
     * 
     * @return id susep
     */
    public Long getIdSusep() {
        return idSusep;
    }

    /**
     * Atribui valor a id susep.
     * 
     * @param idSusep atribui novo valor a id susep
     */
    public void setIdSusep(Long idSusep) {
        this.idSusep = idSusep;
    }

    /**
     * Retorna o valor bruto.
     * 
     * @return valor bruto
     */
    public BigDecimal getValorBruto() {
        return valorBruto;
    }

    /**
     * Atribui valor a valor bruto.
     * 
     * @param valorBruto atribui novo valor a valor bruto
     */
    public void setValorBruto(BigDecimal valorBruto) {
        this.valorBruto = valorBruto;
    }

    /**
     * Retorna o data solicitacao.
     * 
     * @return data solicitacao
     */
    public Date getDataSolicitacao() {
        return dataSolicitacao;
    }

    /**
     * Atribui valor a data solicitacao.
     * 
     * @param dataSolicitacao atribui novo valor a data solicitacao
     */
    public void setDataSolicitacao(Date dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }

    /**
     * Retorna o id taxa.
     * 
     * @return id taxa
     */
    public Long getIdTaxa() {
        return idTaxa;
    }

    /**
     * Atribui valor a id taxa.
     * 
     * @param idTaxa atribui novo valor a id taxa
     */
    public void setIdTaxa(Long idTaxa) {
        this.idTaxa = idTaxa;
    }

    /**
     * Retorna o percentual.
     * 
     * @return percentual
     */
    public BigDecimal getPercentual() {
        return percentual;
    }

    /**
     * Atribui valor a percentual.
     * 
     * @param percentual atribui novo valor a percentual
     */
    public void setPercentual(BigDecimal percentual) {
        this.percentual = percentual;
    }

    /**
     * Retorna o valor taxa.
     * 
     * @return valor taxa
     */
    public BigDecimal getValorTaxa() {
        return valorTaxa;
    }

    /**
     * Atribui valor a valor taxa.
     * 
     * @param valorTaxa atribui novo valor a valor taxa
     */
    public void setValorTaxa(BigDecimal valorTaxa) {
        this.valorTaxa = valorTaxa;
    }

    /**
     * {@inheritDoc}
     */
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "DadosCalculoTaxaSaidaVO [workTransacao=" + workTransacao + ", idRequisicaoFinanceira=" + idRequisicaoFinanceira + ", isentoSN=" + isentoSN + ", idProtocolo=" + idProtocolo + ", idSusep=" + idSusep + ", valorBruto=" + valorBruto
                + ", dataSolicitacao=" + dataSolicitacao + ", idTaxa=" + idTaxa + ", percentual=" + percentual + ", valorTaxa=" + valorTaxa + "]";
    }

}
