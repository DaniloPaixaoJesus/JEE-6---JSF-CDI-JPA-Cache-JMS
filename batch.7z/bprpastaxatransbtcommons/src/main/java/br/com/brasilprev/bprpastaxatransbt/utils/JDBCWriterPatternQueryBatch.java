/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprpastaxatransbt.utils;

import java.sql.PreparedStatement;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.querybatch.QueryBatch;

/**
 * Interface JDBCWriterPatternPreConceder.
 *
 * @author Danilo Paixao (P51701504)
 */
public interface JDBCWriterPatternQueryBatch {
    
    /**
     * Initialize.
     *
     * @param props do tipo Properties
     */
    public abstract void initialize(Properties props);
    
    /**
     * Retorna o strings queries.
     *
     * @return strings queries
     */
    public abstract List<QueryBatch> getStringsQueries();
    
    
    /**
     * Write record.
     *
     * @param pstmt do tipo Entry<Integer,PreparedStatement>
     * @param record do tipo Object
     * @return int
     */
    public abstract int writeRecord(Entry<QueryBatch, PreparedStatement> pstmt, Object record);  

}
