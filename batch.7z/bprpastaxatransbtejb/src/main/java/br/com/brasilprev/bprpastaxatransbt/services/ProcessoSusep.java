/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.services;

import java.util.Date;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.ServiceLocatorDev;
import br.com.brasilprev.bprprodutosdm.ejb.service.ProcessoSusepRemote;
import br.com.brasilprev.bprprodutosdm.ejb.vo.ProcessoSusepDetalheVO;

/**
 * Class ProcessoSusep.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessoSusep {

    /** logger. */
    private final LogBatch logger = new LogBatch(new Properties());

    /**
     * Buscar processo susep.
     * 
     * @param idSusep do tipo Long
     * @param dataSolicitacoa do tipo Date
     * @return ProcessoSusepDetalheVO
     */
    public ProcessoSusepDetalheVO buscarProcessoSusep(Long idSusep, Date dataSolicitacoa) {
        logger.debug("\n        Obtem: EJB Reference: " + StringBatchConstants.EJB_PRODUTOS + "\n");
        ProcessoSusepDetalheVO processoSusepDetalhe = null;
        try {
            ProcessoSusepRemote processoSusepRemote = (ProcessoSusepRemote) ServiceLocatorDev.getInstance().getEJBReference(ProcessoSusepRemote.class, StringBatchConstants.EJB_PRODUTOS_DEV);
            processoSusepDetalhe = processoSusepRemote.buscarProcessoSusep(idSusep, dataSolicitacoa, StringBatchConstants.ID_IDIOMA);
            logger.debug(processoSusepDetalhe.toString());
        } catch (Exception e) {
            TrataExcecoes.servico(e, this.getClass());
        }
        return processoSusepDetalhe;
    }
}
