/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import br.com.brasilprev.bprcarregamentodm.commons.vo.CarregamentoVO;
import br.com.brasilprev.bprcarregamentodm.commons.vo.ConsultaCarregamentoVO;
import br.com.brasilprev.bprcarregamentodm.commons.vo.ConsultaDetalheCarregamentoVO;
import br.com.brasilprev.bprcarregamentodm.ejb.service.CarregamentoServiceRemote;
import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.ServiceLocatorDev;
import br.com.brasilprev.bprpastaxatransbt.vo.step5.DadosCalculoTaxaCarregamentoVO;

/**
 * Class Carregamento.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class Carregamento {

    /** logger. */
    private final LogBatch logger = new LogBatch(new Properties());

    /**
     * Consultar carregamento.
     * 
     * @param dadosCalculoTaxaCarregamento
     *            do tipo DadosCalculoTaxaCarregamentoVO
     * @return DadosCalculoTaxaCarregamentoVO
     */
    public DadosCalculoTaxaCarregamentoVO consultarCarregamento(DadosCalculoTaxaCarregamentoVO dadosCalculoTaxaCarregamento) {
        logger.debug("\n        Obtem: EJB Reference: " + StringBatchConstants.EJB_CARREGAMENTO + "\n");

        List<CarregamentoVO> listaCarregamentoVo = new ArrayList<CarregamentoVO>();
        try {
            ConsultaCarregamentoVO consultaCarregamentoVO = new ConsultaCarregamentoVO();
            consultaCarregamentoVO.setIdContrato(dadosCalculoTaxaCarregamento.getIdContrato());
            consultaCarregamentoVO.setIdMatricula(dadosCalculoTaxaCarregamento.getIdMatricula());
            consultaCarregamentoVO.setIdProduto(dadosCalculoTaxaCarregamento.getIdProduto());
            consultaCarregamentoVO.setIdTipoTransacao(dadosCalculoTaxaCarregamento.getIdTipoTransacao());
            consultaCarregamentoVO.setTipoCarregamento(dadosCalculoTaxaCarregamento.getTipoCarregamento());

            ConsultaDetalheCarregamentoVO consultaDetalheVO = new ConsultaDetalheCarregamentoVO();
            consultaDetalheVO.setContaReserva(dadosCalculoTaxaCarregamento.getContaReserva());
            consultaDetalheVO.setDataAquisicaoPlano(dadosCalculoTaxaCarregamento.getDataAquisicaoPlano());
            consultaDetalheVO.setDataSolicitacao(dadosCalculoTaxaCarregamento.getDataSolicitacao());
            consultaDetalheVO.setIdCusteioResponsavel(dadosCalculoTaxaCarregamento.getIdCusteioResponsavel());
            consultaDetalheVO.setIdRelacionamentoMatriculaContrato(dadosCalculoTaxaCarregamento.getIdRelacionamentoMatriculaContrato());
            consultaDetalheVO.setIdSusep(dadosCalculoTaxaCarregamento.getIdSusep());
            consultaDetalheVO.setIdTipoCobertura(dadosCalculoTaxaCarregamento.getIdTipoCobertura());

            consultaDetalheVO.setIdTipoBeneficio(null);
            consultaDetalheVO.setVlrContribuicao(null);
            consultaDetalheVO.setVlrReserva(null);
            List<ConsultaDetalheCarregamentoVO> listaDetalhes = new ArrayList<ConsultaDetalheCarregamentoVO>();
            listaDetalhes.add(consultaDetalheVO);
            consultaCarregamentoVO.setListaDetalhes(listaDetalhes);

            CarregamentoServiceRemote carregamentoRemote = (CarregamentoServiceRemote) ServiceLocatorDev.getInstance().getEJBReference(CarregamentoServiceRemote.class, StringBatchConstants.EJB_CARREGAMENTO_DEV);
            listaCarregamentoVo = carregamentoRemote.consultarCarregamentoSaida(consultaCarregamentoVO);
            dadosCalculoTaxaCarregamento.setTaxa(BigDecimal.ZERO);
            if (listaCarregamentoVo.get(0).getTaxaCarregamento() != null) {
                dadosCalculoTaxaCarregamento.setTaxa(listaCarregamentoVo.get(0).getTaxaCarregamento());
            }
        } catch (Exception e) {
            TrataExcecoes.servico(e, this.getClass());
        }
        return dadosCalculoTaxaCarregamento;
    }
}
