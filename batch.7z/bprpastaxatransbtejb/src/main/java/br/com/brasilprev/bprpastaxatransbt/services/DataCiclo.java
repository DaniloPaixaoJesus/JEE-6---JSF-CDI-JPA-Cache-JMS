/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import br.com.brasilprev.bprcicloaplicacaodm.ejb.service.CicloProcessamentoRemote;
import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.ServiceLocatorDev;

/**
 * Class DataCiclo.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class DataCiclo {

    /** logger. */
    private final LogBatch logger = new LogBatch(new Properties());

    /**
     * Retorna o data processamento.
     * 
     * @return data processamento
     */
    public String getDataProcessamento() {
        logger.debug("\n        Obtem: EJB Reference: " + StringBatchConstants.EJB_CICLO_PROCESSAMENTO_SERVICE + "\n");
        String dataFormatadaRetornada = null;
        try {
            CicloProcessamentoRemote cicloProcessamento = (CicloProcessamentoRemote) ServiceLocatorDev.getInstance().getEJBReference(CicloProcessamentoRemote.class, StringBatchConstants.EJB_CICLO_PROCESSAMENTO_SERVICE_DEV);
            Date dataCiclo = cicloProcessamento.consultarDataCiclo(1L);
            DateFormat df = new SimpleDateFormat("yyyyMMdd");
            dataFormatadaRetornada = df.format(dataCiclo);
            logger.debug(dataFormatadaRetornada);
        } catch (Exception e) {
            TrataExcecoes.servico(e, this.getClass());
        }
        return dataFormatadaRetornada;
    }
}
