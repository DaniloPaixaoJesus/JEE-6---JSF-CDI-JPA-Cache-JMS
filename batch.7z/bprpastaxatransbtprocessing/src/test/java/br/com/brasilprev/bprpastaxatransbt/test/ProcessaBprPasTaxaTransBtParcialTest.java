/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import br.com.brasilprev.bprpastaxatransbt.step1.ProcessaBprPasTaxaTransBt;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * Class ProcessaBprPasTaxaTransBtParcialTest.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBtParcialTest {

    /** Constante TPOPERACAOPARCIAL. */
    //private static final Long TPOPERACAOTOTAL = 2L;
    private static final Long TPOPERACAOPARCIAL = 3L;

    private static ProcessaBprPasTaxaTransBt processa;

    @BeforeClass
    public static void setUpClass() {
        processa = new ProcessaBprPasTaxaTransBt();
        processa.initialize(new Properties());
    }


    /**
     * Testa cenario uma linha nao tem saldo parcial.
     * 
     * @return true, se a condição for verdadeira
     * @throws Exception o exception
     */
    @Test
    public void testaCenarioUmaLinhaNaoTemSaldoParcial() throws Exception {
        DadosSaldoVO dadosSaldoVO = new DadosSaldoVO();

        dadosSaldoVO.setDataSolicitada(new Date());
        dadosSaldoVO.setIdMatricula(1L);
        dadosSaldoVO.setIdRequisicao(1L);
        dadosSaldoVO.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO.setDataCota(new Date());
        dadosSaldoVO.setIdProtocolo(1L);
        dadosSaldoVO.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO.setIdAtividadePasso(1146L);
        dadosSaldoVO.setTipoTrasacao(5L);
        dadosSaldoVO.setQtdeItensRestantesMatricula(1);
        dadosSaldoVO.setQtdeLinhasMarcacao(1);
        dadosSaldoVO.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
        marcacaoDinheiro.setIdSusep(1L);
        marcacaoDinheiro.setIdInvestimento(1L);
        marcacaoDinheiro.setIdContaReserva(3L);
        marcacaoDinheiro.setIdCusteio(2L);
        marcacaoDinheiro.setQtdeCotaSolicitado(new BigDecimal("1.6902011709271746"));
        marcacaoDinheiro.setValorSolicitado(new BigDecimal("16.0000000000000003"));
        marcacaoDinheiro.setIdMarcacaoDinheiro(1026L);
        marcacaoDinheiro.setDataDinheiro(new Date());
        marcacaoDinheiro.setValorNominalDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro.setValorTotal(BigDecimal.ZERO);
        marcacaoDinheiro.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro.setEhIsentoTaxa("N");
        marcacaoDinheiro.setEhEntidadeFechada("N");

        dadosSaldoVO.setMarcacaoDinheiro(marcacaoDinheiro);


        DadosSaldoVO retorno = (DadosSaldoVO) processa.processRecord(dadosSaldoVO);
        Assert.assertTrue(!retorno.isPossuiSaldo());
    }

    /**
     * Testa cenario varias linhas nao tem saldo parcial.
     * 
     * @return true, se a condição for verdadeira
     * @throws Exception o exception
     */
    @Test
    public void testaCenarioVariasLinhasNaoTemSaldoParcial() throws Exception {
        DadosSaldoVO dadosSaldoVO = new DadosSaldoVO();

        dadosSaldoVO.setDataSolicitada(new Date());
        dadosSaldoVO.setIdMatricula(1L);
        dadosSaldoVO.setIdRequisicao(1L);
        dadosSaldoVO.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO.setDataCota(new Date());
        dadosSaldoVO.setIdProtocolo(1L);
        dadosSaldoVO.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO.setIdAtividadePasso(1146L);
        dadosSaldoVO.setTipoTrasacao(5L);
        dadosSaldoVO.setQtdeItensRestantesMatricula(3);
        dadosSaldoVO.setQtdeLinhasMarcacao(3);
        dadosSaldoVO.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
        marcacaoDinheiro.setIdSusep(1L);
        marcacaoDinheiro.setIdInvestimento(1L);
        marcacaoDinheiro.setIdContaReserva(3L);
        marcacaoDinheiro.setIdCusteio(2L);
        marcacaoDinheiro.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro.setIdMarcacaoDinheiro(1L);
        marcacaoDinheiro.setDataDinheiro(new Date());
        marcacaoDinheiro.setValorNominalDisponivel(new BigDecimal(30));
        marcacaoDinheiro.setValorTotal(new BigDecimal(30));
        marcacaoDinheiro.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro.setEhIsentoTaxa("N");
        marcacaoDinheiro.setEhEntidadeFechada("N");

        dadosSaldoVO.setMarcacaoDinheiro(marcacaoDinheiro);

        ProcessaBprPasTaxaTransBt processa = new ProcessaBprPasTaxaTransBt();
        processa.initialize(new Properties());
        processa.processRecord(dadosSaldoVO);

        DadosSaldoVO dadosSaldoVO2 = new DadosSaldoVO();

        dadosSaldoVO2.setDataSolicitada(new Date());
        dadosSaldoVO2.setIdMatricula(1L);
        dadosSaldoVO2.setIdRequisicao(1L);
        dadosSaldoVO2.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO2.setDataCota(new Date());
        dadosSaldoVO2.setIdProtocolo(1L);
        dadosSaldoVO2.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO2.setIdAtividadePasso(1146L);
        dadosSaldoVO2.setTipoTrasacao(5L);
        dadosSaldoVO2.setQtdeItensRestantesMatricula(3);
        dadosSaldoVO2.setQtdeLinhasMarcacao(3);
        dadosSaldoVO2.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO2.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO2.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro2 = new MarcacaoDinheiroVO();
        marcacaoDinheiro2.setIdSusep(1L);
        marcacaoDinheiro2.setIdInvestimento(1L);
        marcacaoDinheiro2.setIdContaReserva(3L);
        marcacaoDinheiro2.setIdCusteio(2L);
        marcacaoDinheiro2.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro2.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro2.setIdMarcacaoDinheiro(2L);
        marcacaoDinheiro2.setDataDinheiro(new Date());
        marcacaoDinheiro2.setValorNominalDisponivel(new BigDecimal(50));
        marcacaoDinheiro2.setValorTotal(new BigDecimal(50));
        marcacaoDinheiro2.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro2.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro2.setEhIsentoTaxa("N");
        marcacaoDinheiro2.setEhEntidadeFechada("N");

        dadosSaldoVO2.setMarcacaoDinheiro(marcacaoDinheiro2);
        processa.processRecord(dadosSaldoVO2);

        DadosSaldoVO dadosSaldoVO3 = new DadosSaldoVO();

        dadosSaldoVO3.setDataSolicitada(new Date());
        dadosSaldoVO3.setIdMatricula(1L);
        dadosSaldoVO3.setIdRequisicao(1L);
        dadosSaldoVO3.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO3.setDataCota(new Date());
        dadosSaldoVO3.setIdProtocolo(1L);
        dadosSaldoVO3.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO3.setIdAtividadePasso(1146L);
        dadosSaldoVO3.setTipoTrasacao(5L);
        dadosSaldoVO3.setQtdeItensRestantesMatricula(3);
        dadosSaldoVO3.setQtdeLinhasMarcacao(3);
        dadosSaldoVO3.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO3.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO3.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro3 = new MarcacaoDinheiroVO();
        marcacaoDinheiro3.setIdSusep(1L);
        marcacaoDinheiro3.setIdInvestimento(1L);
        marcacaoDinheiro3.setIdContaReserva(3L);
        marcacaoDinheiro3.setIdCusteio(2L);
        marcacaoDinheiro3.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro3.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro3.setIdMarcacaoDinheiro(2L);
        marcacaoDinheiro3.setDataDinheiro(new Date());
        marcacaoDinheiro3.setValorNominalDisponivel(new BigDecimal(50));
        marcacaoDinheiro3.setValorTotal(new BigDecimal(50));
        marcacaoDinheiro3.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro3.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro3.setEhIsentoTaxa("N");
        marcacaoDinheiro3.setEhEntidadeFechada("N");

        dadosSaldoVO3.setMarcacaoDinheiro(marcacaoDinheiro3);

        DadosSaldoVO retorno = (DadosSaldoVO) processa.processRecord(dadosSaldoVO3);

        Assert.assertTrue(!retorno.isPossuiSaldo());
    }

    /**
     * Testa cenario uma linha tem saldo parcial.
     * 
     * @return true, se a condição for verdadeira
     * @throws Exception o exception
     */
    @Test
    public void testaCenarioUmaLinhaTemSaldoParcial() throws Exception {
        DadosSaldoVO dadosSaldoVO = new DadosSaldoVO();

        dadosSaldoVO.setDataSolicitada(new Date());
        dadosSaldoVO.setIdMatricula(1L);
        dadosSaldoVO.setIdRequisicao(1L);
        dadosSaldoVO.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO.setDataCota(new Date());
        dadosSaldoVO.setIdProtocolo(1L);
        dadosSaldoVO.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO.setIdAtividadePasso(1146L);
        dadosSaldoVO.setTipoTrasacao(5L);
        dadosSaldoVO.setQtdeItensRestantesMatricula(1);
        dadosSaldoVO.setQtdeLinhasMarcacao(1);
        dadosSaldoVO.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
        marcacaoDinheiro.setIdSusep(1L);
        marcacaoDinheiro.setIdInvestimento(1L);
        marcacaoDinheiro.setIdContaReserva(3L);
        marcacaoDinheiro.setIdCusteio(2L);
        marcacaoDinheiro.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro.setIdMarcacaoDinheiro(1026L);
        marcacaoDinheiro.setDataDinheiro(new Date());
        marcacaoDinheiro.setValorNominalDisponivel(new BigDecimal(150));
        marcacaoDinheiro.setValorTotal(new BigDecimal(150));
        marcacaoDinheiro.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro.setEhIsentoTaxa("N");
        marcacaoDinheiro.setEhEntidadeFechada("N");

        dadosSaldoVO.setMarcacaoDinheiro(marcacaoDinheiro);

        ProcessaBprPasTaxaTransBt processa = new ProcessaBprPasTaxaTransBt();
        processa.initialize(new Properties());
        DadosSaldoVO retorno = (DadosSaldoVO) processa.processRecord(dadosSaldoVO);
        Assert.assertTrue(retorno.isPossuiSaldo());
    }

    /**
     * Testa cenario uma linha tem saldo diponivel maior parcial.
     * 
     * @return true, se a condição for verdadeira
     * @throws Exception o exception
     */
    @Test
    public void testaCenarioUmaLinhaTemSaldoDiponivelMaiorParcial() throws Exception {
        DadosSaldoVO dadosSaldoVO = new DadosSaldoVO();

        dadosSaldoVO.setDataSolicitada(new Date());
        dadosSaldoVO.setIdMatricula(1L);
        dadosSaldoVO.setIdRequisicao(1L);
        dadosSaldoVO.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO.setDataCota(new Date());
        dadosSaldoVO.setIdProtocolo(1L);
        dadosSaldoVO.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO.setIdAtividadePasso(1146L);
        dadosSaldoVO.setTipoTrasacao(5L);
        dadosSaldoVO.setQtdeItensRestantesMatricula(1);
        dadosSaldoVO.setQtdeLinhasMarcacao(1);
        dadosSaldoVO.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
        marcacaoDinheiro.setIdSusep(1L);
        marcacaoDinheiro.setIdInvestimento(1L);
        marcacaoDinheiro.setIdContaReserva(3L);
        marcacaoDinheiro.setIdCusteio(2L);
        marcacaoDinheiro.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro.setIdMarcacaoDinheiro(1026L);
        marcacaoDinheiro.setDataDinheiro(new Date());
        marcacaoDinheiro.setValorNominalDisponivel(new BigDecimal(200));
        marcacaoDinheiro.setValorTotal(new BigDecimal(200));
        marcacaoDinheiro.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro.setEhIsentoTaxa("N");
        marcacaoDinheiro.setEhEntidadeFechada("N");

        dadosSaldoVO.setMarcacaoDinheiro(marcacaoDinheiro);

        ProcessaBprPasTaxaTransBt processa = new ProcessaBprPasTaxaTransBt();
        processa.initialize(new Properties());
        DadosSaldoVO retorno = (DadosSaldoVO) processa.processRecord(dadosSaldoVO);
        Assert.assertTrue(retorno.isPossuiSaldo() && (retorno.getListaMarcacaoDinheiro().get(0).getValorTotal().compareTo(new BigDecimal(150)) == 0));
    }

    /**
     * Testa cenario varias linhas tem saldo parcial.
     * 
     * @return true, se a condição for verdadeira
     * @throws Exception o exception
     */
    @Test
    public void testaCenarioVariasLinhasTemSaldoMaiorParcial() throws Exception {
        DadosSaldoVO dadosSaldoVO = new DadosSaldoVO();

        dadosSaldoVO.setDataSolicitada(new Date());
        dadosSaldoVO.setIdMatricula(1L);
        dadosSaldoVO.setIdRequisicao(1L);
        dadosSaldoVO.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO.setDataCota(new Date());
        dadosSaldoVO.setIdProtocolo(1L);
        dadosSaldoVO.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO.setIdAtividadePasso(1146L);
        dadosSaldoVO.setTipoTrasacao(5L);
        dadosSaldoVO.setQtdeItensRestantesMatricula(3);
        dadosSaldoVO.setQtdeLinhasMarcacao(3);
        dadosSaldoVO.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
        marcacaoDinheiro.setIdSusep(1L);
        marcacaoDinheiro.setIdInvestimento(1L);
        marcacaoDinheiro.setIdContaReserva(3L);
        marcacaoDinheiro.setIdCusteio(2L);
        marcacaoDinheiro.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro.setIdMarcacaoDinheiro(1L);
        marcacaoDinheiro.setDataDinheiro(new Date());
        marcacaoDinheiro.setValorNominalDisponivel(new BigDecimal(30));
        marcacaoDinheiro.setValorTotal(new BigDecimal(30));
        marcacaoDinheiro.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro.setEhIsentoTaxa("N");
        marcacaoDinheiro.setEhEntidadeFechada("N");

        dadosSaldoVO.setMarcacaoDinheiro(marcacaoDinheiro);

        ProcessaBprPasTaxaTransBt processa = new ProcessaBprPasTaxaTransBt();
        processa.initialize(new Properties());
        processa.processRecord(dadosSaldoVO);

        DadosSaldoVO dadosSaldoVO2 = new DadosSaldoVO();

        dadosSaldoVO2.setDataSolicitada(new Date());
        dadosSaldoVO2.setIdMatricula(1L);
        dadosSaldoVO2.setIdRequisicao(1L);
        dadosSaldoVO2.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO2.setDataCota(new Date());
        dadosSaldoVO2.setIdProtocolo(1L);
        dadosSaldoVO2.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO2.setIdAtividadePasso(1146L);
        dadosSaldoVO2.setTipoTrasacao(5L);
        dadosSaldoVO2.setQtdeItensRestantesMatricula(3);
        dadosSaldoVO2.setQtdeLinhasMarcacao(3);
        dadosSaldoVO2.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO2.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO2.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro2 = new MarcacaoDinheiroVO();
        marcacaoDinheiro2.setIdSusep(1L);
        marcacaoDinheiro2.setIdInvestimento(1L);
        marcacaoDinheiro2.setIdContaReserva(3L);
        marcacaoDinheiro2.setIdCusteio(2L);
        marcacaoDinheiro2.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro2.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro2.setIdMarcacaoDinheiro(2L);
        marcacaoDinheiro2.setDataDinheiro(new Date());
        marcacaoDinheiro2.setValorNominalDisponivel(new BigDecimal(150));
        marcacaoDinheiro2.setValorTotal(new BigDecimal(150));
        marcacaoDinheiro2.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro2.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro2.setEhIsentoTaxa("N");
        marcacaoDinheiro2.setEhEntidadeFechada("N");

        dadosSaldoVO2.setMarcacaoDinheiro(marcacaoDinheiro2);
        processa.processRecord(dadosSaldoVO2);

        DadosSaldoVO dadosSaldoVO3 = new DadosSaldoVO();

        dadosSaldoVO3.setDataSolicitada(new Date());
        dadosSaldoVO3.setIdMatricula(1L);
        dadosSaldoVO3.setIdRequisicao(1L);
        dadosSaldoVO3.setIdRequisicaoFinanceira(1L);
        dadosSaldoVO3.setDataCota(new Date());
        dadosSaldoVO3.setIdProtocolo(1L);
        dadosSaldoVO3.setIdTipoOperacao(TPOPERACAOPARCIAL);
        dadosSaldoVO3.setIdAtividadePasso(1146L);
        dadosSaldoVO3.setTipoTrasacao(5L);
        dadosSaldoVO3.setQtdeItensRestantesMatricula(3);
        dadosSaldoVO3.setQtdeLinhasMarcacao(3);
        dadosSaldoVO3.setUtilizaDinheiroEntidadeFechada("N");
        dadosSaldoVO3.setValorCota(new BigDecimal("9.4663287869"));

        dadosSaldoVO3.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
        MarcacaoDinheiroVO marcacaoDinheiro3 = new MarcacaoDinheiroVO();
        marcacaoDinheiro3.setIdSusep(1L);
        marcacaoDinheiro3.setIdInvestimento(1L);
        marcacaoDinheiro3.setIdContaReserva(3L);
        marcacaoDinheiro3.setIdCusteio(2L);
        marcacaoDinheiro3.setQtdeCotaSolicitado(BigDecimal.ZERO);
        marcacaoDinheiro3.setValorSolicitado(new BigDecimal(150));
        marcacaoDinheiro3.setIdMarcacaoDinheiro(2L);
        marcacaoDinheiro3.setDataDinheiro(new Date());
        marcacaoDinheiro3.setValorNominalDisponivel(new BigDecimal(200));
        marcacaoDinheiro3.setValorTotal(new BigDecimal(200));
        marcacaoDinheiro3.setValorRendimento(BigDecimal.ZERO);
        marcacaoDinheiro3.setCotaDisponivel(BigDecimal.ZERO);
        marcacaoDinheiro3.setEhIsentoTaxa("N");
        marcacaoDinheiro3.setEhEntidadeFechada("N");

        dadosSaldoVO3.setMarcacaoDinheiro(marcacaoDinheiro3);

        DadosSaldoVO retorno = (DadosSaldoVO) processa.processRecord(dadosSaldoVO3);

        Assert.assertTrue(retorno.isPossuiSaldo());
    }
}
