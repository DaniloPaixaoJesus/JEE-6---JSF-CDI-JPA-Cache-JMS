package br.com.brasilprev.bprpastaxatransbt.test;

import java.math.BigDecimal;
import java.math.RoundingMode;

import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;

public class Teste {
    private static BigDecimal valorTotalArredondamento = BigDecimal.ZERO;
    private static BigDecimal valorRestoArredondamento = BigDecimal.ZERO;
    private static BigDecimal totalRestante = BigDecimal.ZERO;
    public static void main(String[] args) {
        valorTotalArredondamento = new BigDecimal("1.1099").setScale(2, RoundingMode.DOWN);
        System.out.println(valorTotalArredondamento);
        /*
         * List<BigDecimal> listaValores = new ArrayList<>();
         * BigDecimal valor1 = new BigDecimal("81.35");
         * BigDecimal valor2 = new BigDecimal("81.34");
         * BigDecimal valor3 = new BigDecimal("81.33");
         * BigDecimal valor4 = new BigDecimal("81.30");
         * BigDecimal total = new BigDecimal("325.29").setScale(2, RoundingMode.HALF_UP);
         * totalRestante = total;
         * System.out.println("Total Solicitado: " + total);
         * listaValores.add(valor1);
         * listaValores.add(valor2);
         * listaValores.add(valor3);
         * listaValores.add(valor4);
         * int qtde = listaValores.size();
         * for (BigDecimal valor : listaValores) {
         * qtde -= 1;
         * System.out.println(arrendondar(valor, qtde, total));
         * }
         * System.out.println("-----");
         * qtde = listaValores.size();
         * for (BigDecimal valor : listaValores) {
         * qtde -= 1;
         * System.out.println(arrendondarPegandoDiferencaNoUltimo(valor, qtde, total));
         * }
         */

        BigDecimal multiplicar = MathUtil.multiplicar(new BigDecimal("9.558708741"), new BigDecimal("-1.0416142809204758"));
        System.out.println(multiplicar);
        //BigDecimal totalS = BigDecimal.ZERO;
        //System.out.println(valor1);
        //System.out.println(valor2);
        //System.out.println(valor3);
        //System.out.println(valor4);
        //System.out.println();

        //BigDecimal resto = valor1.remainder(BigDecimal.ONE);
        /*
         * System.out.println("-------");
         * valor1 = valor1.setScale(2, RoundingMode.HALF_UP);
         * valor2 = valor2.setScale(2, RoundingMode.HALF_UP);
         * valor3 = valor3.setScale(2, RoundingMode.HALF_UP);
         * System.out.println(valor1);
         * System.out.println(valor2);
         * System.out.println(valor3);
         * BigDecimal totalS = valor1.add(valor2).add(valor3).add(valor4);
         * BigDecimal resto = totalS.subtract(total);
         * System.out.println(valor4.add(resto).setScale(2, RoundingMode.HALF_UP));
         */

    }

    private static BigDecimal arrendondarPegandoDiferencaNoUltimo(BigDecimal valor, int qtde, BigDecimal total) {
        if (qtde == 0) {
            BigDecimal resto = total.subtract(valorTotalArredondamento);
            valor = resto.setScale(2, RoundingMode.HALF_UP);
        } else {
            valor = valor.setScale(2, RoundingMode.HALF_DOWN);
            valorTotalArredondamento = valorTotalArredondamento.add(valor);
            totalRestante = totalRestante.subtract(valor);
        }
        return valor;
    }

    private static BigDecimal arrendondar(BigDecimal valor, int qtde, BigDecimal total) {
        if (qtde == 0) {
            valorRestoArredondamento = valorRestoArredondamento.setScale(2, RoundingMode.UP);
            if (valor.compareTo(totalRestante) > 0) {
                valor = totalRestante;
            }
            valor = valor.setScale(2, RoundingMode.UP);
            valor = valor.add(valorRestoArredondamento);
        } else {
            BigDecimal tempValor = valor;
            valor = valor.setScale(2, RoundingMode.HALF_DOWN);
            tempValor = tempValor.subtract(valor);
            valorRestoArredondamento = valorRestoArredondamento.add(tempValor);
            totalRestante = totalRestante.subtract(valor);
        }
        return valor;
    }

}
