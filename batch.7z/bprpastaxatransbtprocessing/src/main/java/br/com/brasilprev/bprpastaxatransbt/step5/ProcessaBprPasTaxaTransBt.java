/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step5;

import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.services.Carregamento;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step5.DadosCalculoTaxaCarregamentoVO;

import com.ibm.websphere.batch.BatchConstants;
import com.ibm.websphere.batch.devframework.steps.technologyadapters.BatchRecordProcessor;

// TODO: Auto-generated Javadoc
/**
 * Class ProcessaBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBt implements BatchRecordProcessor {

    /** logger. */
    private LogBatch logger;

    /** dados calculo acumulado. */
    private DadosCalculoTaxaCarregamentoVO dadosCalculoAcumulado;

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 3 - Processor - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object processRecord(Object record) throws Exception {
        logger.debug("Passo 3 - Processor - processRecord");
        DadosCalculoTaxaCarregamentoVO dadosCalculoCarregamentoVO = null;
        try {
            dadosCalculoCarregamentoVO = (DadosCalculoTaxaCarregamentoVO) record;
            if ((this.dadosCalculoAcumulado == null) || (this.dadosCalculoAcumulado.getQtdeItensRestantesMatricula() == 0)) {
                this.dadosCalculoAcumulado = new Carregamento().consultarCarregamento(dadosCalculoCarregamentoVO);
                logger.info("Passo 3 - Processor - Serviço de carregamento acionado com sucesso.");
            }
            this.dadosCalculoAcumulado.addMarcacaoDinheiro(dadosCalculoCarregamentoVO.getMarcacaoDinheiro());
        } catch (Exception e) {
            logger.error("Passo 3 - Processor - Erro na chamada do Servço de Carregamento");
            TrataExcecoes.batch(e, this.getClass());
        }
        if ((dadosCalculoAcumulado != null)) {
            dadosCalculoAcumulado.setQtdeItensRestantesMatricula(dadosCalculoAcumulado.getQtdeItensRestantesMatricula() - 1);
        }
        return this.dadosCalculoAcumulado;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int completeProcessing() {
        return BatchConstants.STEP_COMPLETE;
    }
}
