/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step3;

import java.math.RoundingMode;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step3.QueryConstantsStep3;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step3.DadosSaldoPorcentagemVO;

/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternPreConceder {

    /** logger. */
    private LogBatch logger;

    /** map sequence lancamento. */
    private final Map<DadosSaldoPorcentagemVO, Long> mapSequenceLancamento = new HashMap<DadosSaldoPorcentagemVO, Long>();

    /** map sequence requisicao atividade. */
    private final Map<DadosSaldoPorcentagemVO, Long> mapSequenceRequisicaoAtividade = new HashMap<DadosSaldoPorcentagemVO, Long>();

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkedHashMap<Integer, String> getStringsQueries() {
        LinkedHashMap<Integer, String> listaInserts = new LinkedHashMap<Integer, String>();
        listaInserts.put(NumerosInteiros.DOIS, QueryConstantsStep3.ACESSO02);
        listaInserts.put(NumerosInteiros.QUATRO, QueryConstantsStep3.ACESSO04);
        listaInserts.put(NumerosInteiros.SEIS, QueryConstantsStep3.ACESSO06);
        listaInserts.put(NumerosInteiros.SETE, QueryConstantsStep3.ACESSO07);
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeRecord(Entry<Integer, PreparedStatement> pstmt, Object record) {
        int qtdAdicionadoBatch = 0;
        try {
            DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO = (DadosSaldoPorcentagemVO) record;
            if (dadosSaldoPorcentagemVO.getQtdeItensRestantesMatricula() <= 0) {
                if ((pstmt.getKey() == NumerosInteiros.DOIS) && !mapSequenceLancamento.containsKey(dadosSaldoPorcentagemVO)) {
                    Long idLancamento = getSequenceLancamento(dadosSaldoPorcentagemVO, pstmt.getValue());
                    dadosSaldoPorcentagemVO.setValorTotalSolicitado(MathUtil.formatarDinheiro(dadosSaldoPorcentagemVO.getValorTotalSolicitado()));
                    dadosSaldoPorcentagemVO.setIdLancamento(idLancamento);
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoPorcentagemVO.getIdLancamento());
                    pstmt.getValue().setDate(NumerosInteiros.DOIS, (Date) dadosSaldoPorcentagemVO.getDataCota());
                    pstmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoPorcentagemVO.getIdProtocolo());
                    pstmt.getValue().setLong(NumerosInteiros.QUATRO, dadosSaldoPorcentagemVO.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.CINCO, dadosSaldoPorcentagemVO.getTipoOperacao());
                    pstmt.getValue().setLong(NumerosInteiros.SEIS, dadosSaldoPorcentagemVO.getTipoTrasacao());
                    pstmt.getValue().setLong(NumerosInteiros.SETE, dadosSaldoPorcentagemVO.getIdMatricula());
                    pstmt.getValue().setBigDecimal(NumerosInteiros.OITO, dadosSaldoPorcentagemVO.getValorTotalSolicitado());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.QUATRO) {
                    int qtde = dadosSaldoPorcentagemVO.getListaMarcacaoDinheiro().size();
                    for (MarcacaoDinheiroVO marcacaoDinheiroVO : dadosSaldoPorcentagemVO.getListaMarcacaoDinheiro()) {
                        qtde -= 1;
                        MathUtil.calcularResto(dadosSaldoPorcentagemVO, marcacaoDinheiroVO, qtde);
                        qtdAdicionadoBatch += insereMarcacaoDinheiro(pstmt, dadosSaldoPorcentagemVO, marcacaoDinheiroVO);
                    }
                } else if ((pstmt.getKey() == NumerosInteiros.SEIS) && dadosSaldoPorcentagemVO.getIdAtividadePasso() !=null && !mapSequenceRequisicaoAtividade.containsKey(dadosSaldoPorcentagemVO)) {
                    Long idRequisicaoAtividade = getSequenceRequisicaoAtividade(dadosSaldoPorcentagemVO, pstmt.getValue());
                    dadosSaldoPorcentagemVO.setIdRequisicaoAtividade(idRequisicaoAtividade);
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoPorcentagemVO.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, idRequisicaoAtividade);
                    pstmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoPorcentagemVO.getIdAtividadePasso());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.SETE && dadosSaldoPorcentagemVO.getIdAtividadePasso() !=null) {
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoPorcentagemVO.getIdRequisicaoFinanceira());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosSaldoPorcentagemVO.getIdRequisicaoAtividade());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                }
            }

        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

    /**
     * Insere marcacao dinheiro.
     * 
     * @param pstmt do tipo Entry<Integer,PreparedStatement>
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param marcacaoDinheiroVO do tipo MarcacaoDinheiroVO
     * @return Integer
     * @throws SQLException o SQL exception
     */
    private Integer insereMarcacaoDinheiro(Entry<Integer, PreparedStatement> pstmt, DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO, MarcacaoDinheiroVO marcacaoDinheiroVO) throws SQLException {
        pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoPorcentagemVO.getIdLancamento());
        pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosSaldoPorcentagemVO.getIdMatricula());
        pstmt.getValue().setLong(NumerosInteiros.TRES, marcacaoDinheiroVO.getIdSusep());
        pstmt.getValue().setLong(NumerosInteiros.QUATRO, marcacaoDinheiroVO.getIdInvestimento());
        pstmt.getValue().setLong(NumerosInteiros.CINCO, marcacaoDinheiroVO.getIdContaReserva());
        pstmt.getValue().setLong(NumerosInteiros.SEIS, marcacaoDinheiroVO.getIdCusteio());
        pstmt.getValue().setDate(NumerosInteiros.SETE, (Date) marcacaoDinheiroVO.getDataDinheiro());
        pstmt.getValue().setBigDecimal(NumerosInteiros.OITO, marcacaoDinheiroVO.getCotaUtilizada());
        pstmt.getValue().setBigDecimal(NumerosInteiros.NOVE, marcacaoDinheiroVO.getValorNominalDisponivel().setScale(NumerosInteiros.DOIS, RoundingMode.DOWN));
        pstmt.getValue().setBigDecimal(NumerosInteiros.DEZ, marcacaoDinheiroVO.getValorTotal());
        pstmt.getValue().setString(NumerosInteiros.ONZE, marcacaoDinheiroVO.getEhEntidadeFechada());
        pstmt.getValue().setString(NumerosInteiros.DOZE, marcacaoDinheiroVO.getEhIsentoTaxa());
        pstmt.getValue().setLong(NumerosInteiros.TREZE, marcacaoDinheiroVO.getIdMarcacaoDinheiro());
        pstmt.getValue().setLong(NumerosInteiros.QUATORZE, StringBatchConstants.IDUSUARIOAPLICACAO);
        pstmt.getValue().addBatch();
        return NumerosInteiros.UM;
    }

    /**
     * Retorna o sequence lancamento.
     * 
     * @param dadosSaldoPorcentagemVO do tipo DadosSaldoPorcentagemVO
     * @param pstmt do tipo PreparedStatement
     * @return sequence lancamento
     */
    private Long getSequenceLancamento(DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO, PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep3.ACESSOSEQUENCE01);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_LANCAMENTO");
                mapSequenceLancamento.put(dadosSaldoPorcentagemVO, retorno);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }

    /**
     * Retorna o sequence requisicao atividade.
     * 
     * @param dadosSaldoPorcentagemVO do tipo DadosSaldoPorcentagemVO
     * @param pstmt do tipo PreparedStatement
     * @return sequence requisicao atividade
     */
    public Long getSequenceRequisicaoAtividade(DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO, PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep3.ACESSOSEQUENCE05);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_RQST_ACTY");
                mapSequenceRequisicaoAtividade.put(dadosSaldoPorcentagemVO, retorno);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return retorno;
    }

}
