/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step4;

import java.sql.PreparedStatement;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step4.QueryConstantsStep4;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step4.DadosCalculoTaxaSaidaVO;

/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternPreConceder {
    /** logger. */
    private LogBatch logger;

    /**
     * {@inheritDoc}
     */
    /*
     * (non-Javadoc)
     * @see br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder#initialize(java.util.Properties)
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }

    /**
     * {@inheritDoc}
     */
    /*
     * (non-Javadoc)
     * @see br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder#getStringsQueries()
     */
    @Override
    public LinkedHashMap<Integer, String> getStringsQueries() {
        LinkedHashMap<Integer, String> listaInserts = new LinkedHashMap<Integer, String>();
        listaInserts.put(NumerosInteiros.UM, QueryConstantsStep4.ACESSO01UPDATE);
        listaInserts.put(NumerosInteiros.DOIS, QueryConstantsStep4.ACESSO02UPDATE);
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    /*
     * (non-Javadoc)
     * @see br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder#writeRecord(java.util.Map.Entry, java.lang.Object)
     */
    @Override
    public int writeRecord(Entry<Integer, PreparedStatement> pstmt, Object record) {
        int qtdAdicionadoBatch = 0;
        try {
            DadosCalculoTaxaSaidaVO dadosCalculoTaxasVO = (DadosCalculoTaxaSaidaVO) record;
            if (pstmt.getKey() == NumerosInteiros.UM) {
                pstmt.getValue().setBigDecimal(NumerosInteiros.UM, dadosCalculoTaxasVO.getValorTaxa());
                pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosCalculoTaxasVO.getWorkTransacao());
                pstmt.getValue().addBatch();
                qtdAdicionadoBatch = 1;
            } else if (pstmt.getKey() == NumerosInteiros.DOIS) {
                pstmt.getValue().setLong(NumerosInteiros.UM, dadosCalculoTaxasVO.getIdRequisicaoFinanceira());
                pstmt.getValue().addBatch();
                qtdAdicionadoBatch = 1;
            }

        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

}
