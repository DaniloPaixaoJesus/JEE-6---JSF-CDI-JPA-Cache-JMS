package br.com.brasilprev.bprpastaxatransbt.step7;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step7.QueryConstantsStep7;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step7.MatriculaSemSaldoVO;

/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternPreConceder {

    /** logger. */
    private LogBatch logger;

    /** */
    private Long idRequisicaoAtividade;

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkedHashMap<Integer, String> getStringsQueries() {
        LinkedHashMap<Integer, String> listaInserts = new LinkedHashMap<Integer, String>();
        listaInserts.put(NumerosInteiros.UM, QueryConstantsStep7.ACESSOATUALIZAACTIVITY);
        listaInserts.put(NumerosInteiros.DOIS, QueryConstantsStep7.ACESSOINSEREACTIVITYFINANCE);
        listaInserts.put(NumerosInteiros.TRES, QueryConstantsStep7.ACESSORECUSAFINANCE);
        listaInserts.put(NumerosInteiros.QUATRO, QueryConstantsStep7.ACESSOSEQUENCE01);
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeRecord(Entry<Integer, PreparedStatement> pstmt, Object record) {
        int qtdAdicionadoBatch = 0;
        try {
            MatriculaSemSaldoVO matriculaSemSaldoVO = (MatriculaSemSaldoVO) record;
                if (pstmt.getKey() == NumerosInteiros.UM) {
                    this.idRequisicaoAtividade = getSequenceRequisicaoAtividade(matriculaSemSaldoVO, pstmt.getValue());
                    pstmt.getValue().setLong(NumerosInteiros.UM, matriculaSemSaldoVO.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, this.idRequisicaoAtividade);
                    pstmt.getValue().setLong(NumerosInteiros.TRES, matriculaSemSaldoVO.getAtividadePasso());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.DOIS) {
                    pstmt.getValue().setLong(NumerosInteiros.UM, matriculaSemSaldoVO.getIdRequisicaoFinanceira());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, this.idRequisicaoAtividade);
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.TRES){
                    pstmt.getValue().setLong(NumerosInteiros.UM, matriculaSemSaldoVO.getIdRequisicaoFinanceira());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                }
        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

    /**
     * Retorna o sequence requisicao atividade.
     * 
     * @param matriculaSemSaldoVO do tipo DadosSaldoVO
     * @param pstmt do tipo PreparedStatement
     * @return sequence requisicao atividade
     */
    public Long getSequenceRequisicaoAtividade(MatriculaSemSaldoVO matriculaSemSaldoVO, PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep7.ACESSOSEQUENCE01);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_RQST_ACTY");
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }

}
