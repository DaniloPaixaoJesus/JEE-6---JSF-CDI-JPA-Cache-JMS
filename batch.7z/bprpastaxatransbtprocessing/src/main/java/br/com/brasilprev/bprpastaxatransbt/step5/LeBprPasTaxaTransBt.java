/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step5;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprcarregamentodm.commons.enums.TipoCarregamentoEnum;
import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step5.QueryConstantsStep5;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step5.DadosCalculoTaxaCarregamentoVO;

import com.ibm.websphere.batch.devframework.datastreams.patternadapter.JDBCReaderPattern;


/**
 * Class LeBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class LeBprPasTaxaTransBt implements JDBCReaderPattern {

    /** logger. */
    private LogBatch logger;

    /** data ciclo. */
    private String dataCiclo;

    /** Constante UM. */
    private static final Long UM = 1L;

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 2 - READ - initialize");

        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

        dataCiclo = props.getProperty(StringBatchConstants.DATAPROCESSAMENTO);
        logger.debug("      Data do Ciclo: " + dataCiclo);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getInitialLookupQuery() {
        logger.debug("Passo 2 - [Inicio] TesteReader.getInitialLookupQuery");
        try {
            logger.debug(QueryConstantsStep5.ACESSO04);
            return QueryConstantsStep5.ACESSO04;
        } finally {
            logger.debug("Passo 2 - [Fim] TesteReader.getInitialLookupQuery");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getRestartQuery(String restartToken) {

        logger.debug("Passo 2 - [Inicio] TesteReader.getRestartQuery" + restartToken);
        try {
            logger.debug(QueryConstantsStep5.ACESSO04);
            return QueryConstantsStep5.ACESSO04;
        } finally {
            logger.debug("Passo 2 - [Fim] TesteReader.getRestartQuery");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getRestartTokens() {
        logger.debug("Passo 2 - READ - getRestartTokens");
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object fetchRecord(ResultSet result) {
        DadosCalculoTaxaCarregamentoVO dadosCalculoTaxaCarregamentoVO = null;
        try {
            dadosCalculoTaxaCarregamentoVO = new DadosCalculoTaxaCarregamentoVO();
            MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
            dadosCalculoTaxaCarregamentoVO.setQtdeItensRestantesMatricula(result.getInt("QTD_LINHA"));
            marcacaoDinheiro.setIdMarcacaoDinheiro(result.getLong("WTRSN_MONEY"));
            dadosCalculoTaxaCarregamentoVO.setIdWork(result.getLong("WTRANSACAO"));
            dadosCalculoTaxaCarregamentoVO.setIdRequisicaoFinanceira(result.getLong("IDRequisicaoFinanceira"));
            marcacaoDinheiro.setEhIsentoTaxa(result.getString("isentoSN"));
            dadosCalculoTaxaCarregamentoVO.setIdProtocolo(result.getLong("PROTOCOLO"));
            dadosCalculoTaxaCarregamentoVO.setIdSusep(result.getLong("IDSUSEP"));
            dadosCalculoTaxaCarregamentoVO.setIdInvestimento(result.getLong("INVESTIMENTO"));
            dadosCalculoTaxaCarregamentoVO.setContaReserva(result.getLong("CONTA_RESERVA"));
            dadosCalculoTaxaCarregamentoVO.setIdCusteioResponsavel(result.getLong("CUSTEIO"));
            dadosCalculoTaxaCarregamentoVO.setIdContrato(result.getLong("idContrato"));
            dadosCalculoTaxaCarregamentoVO.setIdProduto(result.getLong("idProduto"));
            dadosCalculoTaxaCarregamentoVO.setIdTipoTransacao(result.getLong("idTipoTransacao"));
            dadosCalculoTaxaCarregamentoVO.setDataAquisicaoPlano(result.getDate("dataAquisicaoPlano"));
            dadosCalculoTaxaCarregamentoVO.setIdRelacionamentoMatriculaContrato(result.getLong("idRelacMatriculaContrato"));
            dadosCalculoTaxaCarregamentoVO.setIdTipoCobertura(UM);
            dadosCalculoTaxaCarregamentoVO.setListaMarcacao(new ArrayList<MarcacaoDinheiroVO>());
            marcacaoDinheiro.setValorNominalDisponivel(result.getBigDecimal("VL_NOMINAL"));
            dadosCalculoTaxaCarregamentoVO.setDataSolicitacao(result.getDate("dataSolicitacao"));
            Long tipoCarregamento = result.getLong("tipoCarregamento");
            TipoCarregamentoEnum carregamento = getTipoCarregamentoById(tipoCarregamento);
            dadosCalculoTaxaCarregamentoVO.setTipoCarregamento(carregamento);
            dadosCalculoTaxaCarregamentoVO.setIdMatricula(result.getLong("idMatricula"));
            dadosCalculoTaxaCarregamentoVO.setMarcacaoDinheiro(marcacaoDinheiro);
            dadosCalculoTaxaCarregamentoVO.setIdRequisicaoFinanceiraInv(result.getLong("IDREQFIN_INVESTIMENTO"));
        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }
        return dadosCalculoTaxaCarregamentoVO;
    }

    /**
     * Retorna o tipo carregamento by id.
     * 
     * @param id
     *            do tipo Long
     * @return tipo carregamento by id
     */
    private TipoCarregamentoEnum getTipoCarregamentoById(Long id) {
        if (id == 1L) {
            return TipoCarregamentoEnum.ENTRADA_PRE;
        } else {
            return TipoCarregamentoEnum.SAIDA_POS;
        }
    }

}
