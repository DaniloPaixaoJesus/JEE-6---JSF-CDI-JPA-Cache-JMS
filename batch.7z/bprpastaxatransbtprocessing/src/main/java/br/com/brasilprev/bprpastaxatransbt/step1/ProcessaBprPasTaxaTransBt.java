/*
 * ====================================================================
 * Direitos de cÃ³pia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contÃ©m informaÃ§Ãµes confidenciais e de propriedade da
 * BRASILPREV ("InformaÃ§Ãµes Confidenciais").
 * VocÃª nÃ£o deve divulgar tais informaÃ§Ãµes confidenciais e deve
 * usÃ¡-las somente em conformidade com os termos do contrato de licenÃ§a
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step1;

import java.math.BigDecimal;
import java.util.Enumeration;
import java.util.Properties;


import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

import com.ibm.websphere.batch.BatchConstants;
import com.ibm.websphere.batch.devframework.steps.technologyadapters.BatchRecordProcessor;

/**
 * Class ProcessaBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBt implements BatchRecordProcessor {
    private LogBatch logger;
    private DadosSaldoVO dadosSaldoVO;

    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 3 - Processor - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }
    /**
     * Esse metodo e responsavel por processar o registro que foi
     * recuperado no reader.
     * 
     * @param record objeto criado no reader
     */
    @Override
    public Object processRecord(Object record) throws Exception {
        logger.debug("Passo 3 - Processor - processRecord");
        DadosSaldoVO dadosSaldoAtualVO = null;
        try {
            dadosSaldoAtualVO = (DadosSaldoVO) record;
            if ((this.dadosSaldoVO == null) || (this.dadosSaldoVO.getQtdeItensRestantesMatricula() == 0)) {
                this.dadosSaldoVO = dadosSaldoAtualVO;
                dadosSaldoVO.setQtdeCotaRestante(dadosSaldoAtualVO.getMarcacaoDinheiro().getQtdeCotaSolicitado());
                dadosSaldoVO.setValorSolicitadoRestante(dadosSaldoAtualVO.getMarcacaoDinheiro().getValorSolicitado());
                dadosSaldoVO.setValorTotalSolicitado(BigDecimal.ZERO);
                dadosSaldoVO.setTemTotalSolicitado(true);
            } else if (this.dadosSaldoVO.getQtdeLinhasMarcacao() == 0) {
                dadosSaldoVO.setQtdeCotaRestante(dadosSaldoAtualVO.getMarcacaoDinheiro().getQtdeCotaSolicitado());
                dadosSaldoVO.setValorSolicitadoRestante(dadosSaldoAtualVO.getMarcacaoDinheiro().getValorSolicitado());
                dadosSaldoVO.setQtdeLinhasMarcacao(dadosSaldoAtualVO.getQtdeLinhasMarcacao());
            }

            dadosSaldoVO.setQtdeItensRestantesMatricula(dadosSaldoVO.getQtdeItensRestantesMatricula() - 1);
            dadosSaldoVO.setQtdeLinhasMarcacao(dadosSaldoVO.getQtdeLinhasMarcacao() - 1);

            if ((dadosSaldoVO.getValorSolicitadoRestante().compareTo(BigDecimal.ZERO) > 0) || (dadosSaldoVO.getQtdeCotaRestante().compareTo(BigDecimal.ZERO) > 0) || !dadosSaldoVO.isTemTotalSolicitado()) {
                dadosSaldoVO.addMarcacaoDinheiroAoCalculo(dadosSaldoAtualVO.getMarcacaoDinheiro());
            }
        } catch (Exception e) {
            dadosSaldoVO.setQtdeItensRestantesMatricula(dadosSaldoVO.getQtdeItensRestantesMatricula() - 1);
            dadosSaldoVO.setQtdeLinhasMarcacao(dadosSaldoVO.getQtdeLinhasMarcacao() - 1);
            TrataExcecoes.batch(e, this.getClass());
        }
        return this.dadosSaldoVO;
    }

    /**
     * Esse metodo e executado durante a finalizacao do job, ele retorna um
     * codigo especï¿½fico informando se o processamento esta completo ou se
     * ocorreu algum erro.
     * 
     * @return codigo valido especificado em com.ibm.websphere.batch.BatchConstants
     */
    @Override
    public int completeProcessing() {
        return BatchConstants.STEP_COMPLETE;
    }
}
