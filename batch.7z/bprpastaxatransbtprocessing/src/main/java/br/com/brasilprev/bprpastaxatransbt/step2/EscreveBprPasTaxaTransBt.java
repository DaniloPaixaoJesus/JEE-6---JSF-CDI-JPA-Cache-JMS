/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step2;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step2.QueryConstantsStep2;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step2.DadosEntradaPassivo;

/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternPreConceder {

    /** logger. */
    private LogBatch logger;


    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkedHashMap<Integer, String> getStringsQueries() {
        LinkedHashMap<Integer, String> listaInserts = new LinkedHashMap<Integer, String>();
        listaInserts.put(NumerosInteiros.UM, QueryConstantsStep2.ACESSO01);
        listaInserts.put(NumerosInteiros.DOIS, QueryConstantsStep2.ACESSO02);
        listaInserts.put(NumerosInteiros.TRES, QueryConstantsStep2.ACESSO03);
        listaInserts.put(NumerosInteiros.QUATRO, QueryConstantsStep2.ACESSO04);
        listaInserts.put(NumerosInteiros.CINCO, QueryConstantsStep2.ACESSO05);
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeRecord(Entry<Integer, PreparedStatement> pstmt, Object record) {
        int qtdAdicionadoBatch = 0;
        try {
            DadosEntradaPassivo dadosEntradaPassivo = (DadosEntradaPassivo) record;
            if (dadosEntradaPassivo.getQtdeLinhaRestante() <= 0) {
                if (pstmt.getKey() == NumerosInteiros.UM) {
                    Long idLancamento = getSequenceByQuery(pstmt.getValue(), QueryConstantsStep2.ACESSOSEQUENCE01);
                    dadosEntradaPassivo.setIdLancamento(idLancamento);
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosEntradaPassivo.getIdLancamento());
                    pstmt.getValue().setDate(NumerosInteiros.DOIS, (Date) dadosEntradaPassivo.getDataCota());
                    pstmt.getValue().setLong(NumerosInteiros.TRES, dadosEntradaPassivo.getProtocolo());
                    pstmt.getValue().setLong(NumerosInteiros.QUATRO, dadosEntradaPassivo.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.CINCO, dadosEntradaPassivo.getTipoOperacao());
                    pstmt.getValue().setLong(NumerosInteiros.SEIS, dadosEntradaPassivo.getTipoTransacao());
                    pstmt.getValue().setLong(NumerosInteiros.SETE, dadosEntradaPassivo.getIdMatricula());
                    pstmt.getValue().setBigDecimal(NumerosInteiros.OITO, dadosEntradaPassivo.getValorTotalCota());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.DOIS) {
                    for (MarcacaoDinheiroVO marcacaoDinheiroVO : dadosEntradaPassivo.getListaMarcacaoDinheiro()) {
                        pstmt.getValue().setLong(NumerosInteiros.UM, dadosEntradaPassivo.getIdLancamento());
                        pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosEntradaPassivo.getIdMatricula());
                        pstmt.getValue().setLong(NumerosInteiros.TRES, marcacaoDinheiroVO.getIdSusep());
                        pstmt.getValue().setLong(NumerosInteiros.QUATRO, marcacaoDinheiroVO.getIdInvestimento());
                        pstmt.getValue().setLong(NumerosInteiros.CINCO, marcacaoDinheiroVO.getIdContaReserva());
                        pstmt.getValue().setLong(NumerosInteiros.SEIS, marcacaoDinheiroVO.getIdCusteio());
                        pstmt.getValue().setDate(NumerosInteiros.SETE, (Date) marcacaoDinheiroVO.getDataDinheiro());
                        pstmt.getValue().setBigDecimal(NumerosInteiros.OITO, marcacaoDinheiroVO.getCotaDisponivel());
                        pstmt.getValue().setBigDecimal(NumerosInteiros.NOVE, marcacaoDinheiroVO.getValorNominalDisponivel());
                        pstmt.getValue().setBigDecimal(NumerosInteiros.DEZ, marcacaoDinheiroVO.getValorTotal());
                        pstmt.getValue().setString(NumerosInteiros.ONZE, marcacaoDinheiroVO.getEhEntidadeFechada());
                        pstmt.getValue().setString(NumerosInteiros.DOZE, marcacaoDinheiroVO.getEhIsentoTaxa());
                        pstmt.getValue().addBatch();
                        qtdAdicionadoBatch += 1;
                    }
                } else if (pstmt.getKey() == NumerosInteiros.TRES && dadosEntradaPassivo.getIdAtividadePasso() !=null) {
                    Long idRequisicaoFinanceira = getSequenceByQuery(pstmt.getValue(), QueryConstantsStep2.ACESSOSEQUENCE02);
                    dadosEntradaPassivo.setIdRequisicaoAtividade(idRequisicaoFinanceira);
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosEntradaPassivo.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosEntradaPassivo.getIdRequisicaoAtividade());
                    pstmt.getValue().setLong(NumerosInteiros.TRES, dadosEntradaPassivo.getIdAtividadePasso());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.QUATRO && dadosEntradaPassivo.getIdAtividadePasso() !=null ) {
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosEntradaPassivo.getIdRequisicaoFinanceira());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosEntradaPassivo.getIdRequisicaoAtividade());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.CINCO) {
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosEntradaPassivo.getIdRequisicaoFinanceira());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                }
            }

        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

    /**
     * Retorna o sequence by query.
     * 
     * @param pstmt do tipo PreparedStatement
     * @param query do tipo String
     * @return sequence by query
     */
    private Long getSequenceByQuery(PreparedStatement pstmt, String query) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(query);
            if (resultado.next()) {
                retorno = resultado.getLong("SEQUENCE");
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }

}
