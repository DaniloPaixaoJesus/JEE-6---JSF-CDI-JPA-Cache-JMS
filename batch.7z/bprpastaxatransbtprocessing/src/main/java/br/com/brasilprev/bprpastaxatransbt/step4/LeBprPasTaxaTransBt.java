/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step4;

import java.sql.ResultSet;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.step4.QueryConstantsStep4;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step4.DadosCalculoTaxaSaidaVO;

import com.ibm.websphere.batch.devframework.datastreams.patternadapter.JDBCReaderPattern;

/**
 * Class LeBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class LeBprPasTaxaTransBt implements JDBCReaderPattern {

    /** logger. */
    private LogBatch logger;

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 2 - READ - initialize");

        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getInitialLookupQuery() {
        logger.debug("Passo 2 - [Inicio] LeBprPasTaxaTransBt.getInitialLookupQuery");
        try {
            logger.debug(QueryConstantsStep4.ACESSO00SELECT);
            return QueryConstantsStep4.ACESSO00SELECT;
        } finally {
            logger.debug("Passo 2 - [Fim] LeBprPasTaxaTransBt.getInitialLookupQuery");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getRestartQuery(String restartToken) {

        logger.debug("Passo 2 - [Inicio] LeBprPasTaxaTransBt.getRestartQuery" + restartToken);
        try {
            logger.debug(QueryConstantsStep4.ACESSO00SELECT);
            return QueryConstantsStep4.ACESSO00SELECT;
        } finally {
            logger.debug("Passo 2 - [Fim] LeBprPasTaxaTransBt.getRestartQuery");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getRestartTokens() {
        logger.debug("Passo 2 - READ - LeBprPasTaxaTransBt.getRestartTokens");
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object fetchRecord(ResultSet result) {
        DadosCalculoTaxaSaidaVO dadosCalculoTaxasVO = null;
        try {
            dadosCalculoTaxasVO = new DadosCalculoTaxaSaidaVO();
            dadosCalculoTaxasVO = new DadosCalculoTaxaSaidaVO();
            dadosCalculoTaxasVO.setWorkTransacao(result.getLong("WTRANSACAO"));
            dadosCalculoTaxasVO.setIdRequisicaoFinanceira(result.getLong("IDREQUISICAOFINANCEIRA"));
            dadosCalculoTaxasVO.setIsentoSN(result.getString("ISENTOSN"));
            dadosCalculoTaxasVO.setIdProtocolo(result.getLong("PROTOCOLO"));
            dadosCalculoTaxasVO.setIdSusep(result.getLong("IDSUSEP"));
            dadosCalculoTaxasVO.setValorBruto(result.getBigDecimal("VL_BRUTO"));
            dadosCalculoTaxasVO.setDataSolicitacao(result.getDate("DATASOLICITACAO"));
            dadosCalculoTaxasVO.setIdRequisicaoFinanceiraInv(result.getLong("IDREQFIN_INVESTIMENTO"));
        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }
        return dadosCalculoTaxasVO;
    }

}
