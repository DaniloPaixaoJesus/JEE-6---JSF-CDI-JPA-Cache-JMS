/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step3;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step3.QueryConstantsStep3;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step3.DadosSaldoPorcentagemVO;

import com.ibm.websphere.batch.devframework.datastreams.patternadapter.JDBCReaderPattern;

/**
 * Class LeBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class LeBprPasTaxaTransBt implements JDBCReaderPattern {

    private LogBatch logger;
    private String dataCiclo;

    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 2 - READ - initialize");

        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

        dataCiclo = props.getProperty(StringBatchConstants.DATAPROCESSAMENTO);
        logger.debug("      Data do Ciclo: " + dataCiclo);
    }

    /**
     * Esse metodo retorna a SQL query que sera utilizada na recuperacao
     * dos dados que serao processados
     * 
     * @return SQL query que sera utilizada.
     */
    @Override
    public String getInitialLookupQuery() {
        logger.debug("Passo 2 - [Inicio] TesteReader.getInitialLookupQuery");
        try {
            logger.debug(QueryConstantsStep3.ACESSO00.replace("?", dataCiclo));
            return QueryConstantsStep3.ACESSO00.replace("?", dataCiclo);
        } finally {
            logger.debug("Passo 2 - [Fim] TesteReader.getInitialLookupQuery");
        }
    }

    /**
     * Esse metodo e chamado durate o reinicio do job, deve ser utilizado
     * para criar a SQL query para recuperar os dados que nao foram processados.
     * 
     * @param restartToken chave da ultima linha processada
     * @return SQL query de rein�cio
     */
    @Override
    public String getRestartQuery(String restartToken) {

        logger.debug("Passo 2 - [Inicio] TesteReader.getRestartQuery" + restartToken);
        try {
            logger.debug(QueryConstantsStep3.ACESSO00.replace("?", dataCiclo));
            return QueryConstantsStep3.ACESSO00.replace("?", dataCiclo);
        } finally {
            logger.debug("Passo 2 - [Fim] TesteReader.getRestartQuery");
        }
    }

    /**
     * Esse metodo e chamado imediatamento antes de executar o checkpoint.
     * 
     * @return token para reinicio do batch.
     */
    @Override
    public String getRestartTokens() {
        logger.debug("Passo 2 - READ - getRestartTokens");
        return null;
    }

    /**
     * Esse metodo recupera os valores das colunas da SQL query atraves do
     * objeto resultSet. Tipicamente e criado um objeto intermediario (VO)
     * para trafegar na execucao do job.
     * 
     * @param resultSet objeto o resultado de uma linha retornada na SQL query
     * @return objeto
     */
    @Override
    public Object fetchRecord(ResultSet result) {
        DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO = null;
        try {
            dadosSaldoPorcentagemVO = new DadosSaldoPorcentagemVO();
            dadosSaldoPorcentagemVO.setDataSolicitada(result.getDate("DATASOLICITACAO"));
            dadosSaldoPorcentagemVO.setIdMatricula(result.getLong("IDMATRICULA"));
            dadosSaldoPorcentagemVO.setIdRequisicao(result.getLong("IDREQUISICAO"));
            dadosSaldoPorcentagemVO.setIdRequisicaoFinanceira(result.getLong("IDREQUISICAOFINACEIRA"));

            dadosSaldoPorcentagemVO.setIdProtocolo(result.getLong("PROTOCOLO"));


            dadosSaldoPorcentagemVO.setIdAtividadePasso(result.getLong("ATIVIDADE_PASSO"));
            dadosSaldoPorcentagemVO.setTipoTrasacao(result.getLong("TP_TRANSACAO"));
            dadosSaldoPorcentagemVO.setQtdeItensRestantesMatricula(result.getInt("QTD_LINHA"));
            dadosSaldoPorcentagemVO.setQtdeLinhasMarcacao(result.getInt("QTD_LINHA_MARCACAO"));
            dadosSaldoPorcentagemVO.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
            dadosSaldoPorcentagemVO.setUtilizaDinheiroEntidadeFechada(result.getString("USADINHEIRO_ENTFECHADA"));
            dadosSaldoPorcentagemVO.setValorCota(result.getBigDecimal("VL_COTA"));
            dadosSaldoPorcentagemVO.setPorcentagem(result.getBigDecimal("PORCENTAGEM"));
            dadosSaldoPorcentagemVO.setDataCota(result.getDate("DATA_COTA"));
            dadosSaldoPorcentagemVO.setTipoOperacao(result.getLong("TP_OPERACAO"));

            MarcacaoDinheiroVO marcacaoDinheiro = new MarcacaoDinheiroVO();
            marcacaoDinheiro.setIdSusep(result.getLong("IDSUSEP"));
            marcacaoDinheiro.setIdInvestimento(result.getLong("INVESTIMENTO"));
            marcacaoDinheiro.setIdContaReserva(result.getLong("CONTA_RESERVA"));
            marcacaoDinheiro.setIdCusteio(result.getLong("CUSTEIO"));
            marcacaoDinheiro.setQtdeCotaSolicitado(result.getBigDecimal("QTDCOTA"));
            marcacaoDinheiro.setValorSolicitado(result.getBigDecimal("VALORSOLICITADO"));
            marcacaoDinheiro.setIdMarcacaoDinheiro(result.getLong("IDTRANSACAO"));
            marcacaoDinheiro.setDataDinheiro(result.getDate("DATADINHEIRO"));
            marcacaoDinheiro.setValorNominalDisponivel(result.getBigDecimal("NOMINALDISP"));
            marcacaoDinheiro.setValorTotal(result.getBigDecimal("VALOR_TOTAL"));
            marcacaoDinheiro.setValorRendimento(result.getBigDecimal("VALOR_RENDIMENTO"));
            marcacaoDinheiro.setCotaDisponivel(result.getBigDecimal("COTASDISP"));
            marcacaoDinheiro.setEhIsentoTaxa(result.getString("ISENTOTAXA"));
            marcacaoDinheiro.setEhEntidadeFechada(result.getString("ENTIDADEFECHADA"));
            dadosSaldoPorcentagemVO.setMarcacaoDinheiro(marcacaoDinheiro);

        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }
        return dadosSaldoPorcentagemVO;
    }

}
