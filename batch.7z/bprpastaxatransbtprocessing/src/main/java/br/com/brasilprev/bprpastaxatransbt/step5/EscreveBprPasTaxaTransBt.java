/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step5;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.step5.QueryConstantsStep5;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step5.DadosCalculoTaxaCarregamentoVO;

// TODO: Auto-generated Javadoc
/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternPreConceder {

    /** logger. */
    private LogBatch logger;

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkedHashMap<Integer, String> getStringsQueries() {
        LinkedHashMap<Integer, String> listaInserts = new LinkedHashMap<Integer, String>();
        listaInserts.put(NumerosInteiros.CINCO, QueryConstantsStep5.ACESSO05);
        listaInserts.put(NumerosInteiros.SETE, QueryConstantsStep5.ACESSO07);
        listaInserts.put(NumerosInteiros.OITO, QueryConstantsStep5.ACESSO08);
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeRecord(Entry<Integer, PreparedStatement> pstmt, Object record) {
        int qtdAdicionadoBatch = 0;
        try {
            DadosCalculoTaxaCarregamentoVO dadosCalculoCarregamentoVO = (DadosCalculoTaxaCarregamentoVO) record;
            if (dadosCalculoCarregamentoVO.getQtdeItensRestantesMatricula() <= 0) {
                if (pstmt.getKey() == NumerosInteiros.CINCO) {
                    for (MarcacaoDinheiroVO marcacaoDinheiro : dadosCalculoCarregamentoVO.getListaMarcacao()) {
                        BigDecimal valorCarregamento = marcacaoDinheiro.getValorCarregamento();
                        pstmt.getValue().setBigDecimal(NumerosInteiros.UM, valorCarregamento);
                        pstmt.getValue().setLong(NumerosInteiros.DOIS, marcacaoDinheiro.getIdMarcacaoDinheiro());
                        pstmt.getValue().addBatch();
                        qtdAdicionadoBatch += 1;
                    }
                }

                if ((pstmt.getKey() == NumerosInteiros.SETE) && (dadosCalculoCarregamentoVO.getTaxa() != null) && (dadosCalculoCarregamentoVO.getTaxa().compareTo(BigDecimal.ZERO) > 0)) {
                    Long idLancamento = getSequenceLancamento(pstmt.getValue());
                    for (MarcacaoDinheiroVO marcacaoDinheiro : dadosCalculoCarregamentoVO.getListaMarcacao()) {

                        BigDecimal valorCarregamento = marcacaoDinheiro.getValorCarregamento();

                        pstmt.getValue().setLong(NumerosInteiros.UM, idLancamento);
                        pstmt.getValue().setLong(NumerosInteiros.DOIS, marcacaoDinheiro.getIdMarcacaoDinheiro());
                        pstmt.getValue().setLong(NumerosInteiros.TRES, dadosCalculoCarregamentoVO.getIdCusteioResponsavel());
                        pstmt.getValue().setBigDecimal(NumerosInteiros.QUATRO, BigDecimal.ZERO);
                        pstmt.getValue().setBigDecimal(NumerosInteiros.CINCO, valorCarregamento);
                        pstmt.getValue().addBatch();
                        qtdAdicionadoBatch += 1;

                    }
                }

                if ((pstmt.getKey() == NumerosInteiros.OITO)) {
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosCalculoCarregamentoVO.getIdRequisicaoFinanceira());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                }
            }

        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

    /**
     * Retorna o sequence lancamento.
     * 
     * @param pstmt do tipo PreparedStatement
     * @return sequence lancamento
     */
    private Long getSequenceLancamento(PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;

        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep5.ACESSO06);
            if (resultado.next()) {
                retorno = resultado.getLong("idLancCarregamento");
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return retorno;
    }
}
