/**
 * Copyright(c) by BRASILPREV
 * All rights reserved.
 * This software is confidential and proprietary information of
 * BRASILPREV ("Confidential Information").
 * You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement
 * you entered with BRASILPREV.
 */
package br.com.brasilprev.bprpastaxatransbt.step7;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step7.QueryConstantsStep7;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step7.MatriculaSemSaldoVO;

import com.ibm.websphere.batch.devframework.datastreams.patternadapter.JDBCReaderPattern;

/**
 * Classe responsavel por ler os dados no banco de dados utilizando
 * JDBC
 * 
 * @author BRASILPREV
 * @version 1.0.0
 * @see https://www.ibm.com/support/knowledgecenter/en/SSCKBL_8.5.5///
 *      com.ibm.websphere.base.doc/ae/rgrid_btchpttrnjd.html
 */
public class LeBprPasTaxaTransBt implements JDBCReaderPattern {
    private LogBatch logger;
    private String dataCiclo;

    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 2 - READ - initialize");

        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

        dataCiclo = props.getProperty(StringBatchConstants.DATAPROCESSAMENTO);
        logger.debug("      Data do Ciclo: " + dataCiclo);
    }

    /**
     * Esse metodo retorna a SQL query que sera utilizada na recuperacao
     * dos dados que serao processados
     * 
     * @return SQL query que sera utilizada.
     */
    @Override
    public String getInitialLookupQuery() {
        logger.debug("Passo 2 - [Inicio] TesteReader.getInitialLookupQuery");
        try {
            logger.debug(QueryConstantsStep7.ACESSO00.replace("?", dataCiclo));
            return QueryConstantsStep7.ACESSO00.replace("?", dataCiclo);
        } finally {
            logger.debug("Passo 2 - [Fim] TesteReader.getInitialLookupQuery");
        }
    }

    /**
     * Esse metodo e chamado durate o reinicio do job, deve ser utilizado
     * para criar a SQL query para recuperar os dados que nao foram processados.
     * 
     * @param restartToken chave da ultima linha processada
     * @return SQL query de rein�cio
     */
    @Override
    public String getRestartQuery(String restartToken) {

        logger.debug("Passo 2 - [Inicio] TesteReader.getRestartQuery" + restartToken);
        try {
            logger.debug(QueryConstantsStep7.ACESSO00.replace("?", dataCiclo));
            return QueryConstantsStep7.ACESSO00.replace("?", dataCiclo);
        } finally {
            logger.debug("Passo 2 - [Fim] TesteReader.getRestartQuery");
        }
    }

    /**
     * Esse metodo e chamado imediatamento antes de executar o checkpoint.
     * 
     * @return token para reinicio do batch.
     */
    @Override
    public String getRestartTokens() {
        logger.debug("Passo 2 - READ - getRestartTokens");
        return null;
    }

    /**
     * Esse metodo recupera os valores das colunas da SQL query atraves do
     * objeto resultSet. Tipicamente e criado um objeto intermediario (VO)
     * para trafegar na execucao do job.
     * 
     * @param resultSet objeto o resultado de uma linha retornada na SQL query
     * @return objeto
     */
    @Override
    public Object fetchRecord(ResultSet result) {
        MatriculaSemSaldoVO matriculaSemSaldoVO = new MatriculaSemSaldoVO();
        try {
            matriculaSemSaldoVO.setAtividadePasso(result.getLong("ATIVIDADE_PASSO"));
            matriculaSemSaldoVO.setIdRequisicao(result.getLong("RQST_ID"));
            matriculaSemSaldoVO.setIdRequisicaoFinanceira(result.getLong("IDREQUISICAOFINACEIRA"));
        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }
        return matriculaSemSaldoVO;
    }

}
