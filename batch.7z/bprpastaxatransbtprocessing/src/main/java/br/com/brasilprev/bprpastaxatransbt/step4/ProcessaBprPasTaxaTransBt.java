/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step4;

import java.math.BigDecimal;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.services.ProcessoSusep;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step4.DadosCalculoTaxaSaidaVO;
import br.com.brasilprev.bprprodutosdm.ejb.vo.ProcessoSusepDetalheVO;
import br.com.brasilprev.bprprodutosdm.ejb.vo.ProcessoSusepSobrevivenciaTipoTaxaVO;

import com.ibm.websphere.batch.BatchConstants;
import com.ibm.websphere.batch.devframework.steps.technologyadapters.BatchRecordProcessor;

/**
 * Class ProcessaBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBt implements BatchRecordProcessor {
    private LogBatch logger;
    DadosCalculoTaxaSaidaVO dadosCalculoAnterior = null;

    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 3 - Processor - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }

    /**
     * Esse metodo e responsavel por processar o registro que foi recuperado no reader.
     * 
     * @param record objeto criado no reader
     */
    @Override
    public Object processRecord(Object record) throws Exception {
        logger.debug("Passo 3 - Processor - processRecord ");
        DadosCalculoTaxaSaidaVO dadosCalculoTaxasVO = null;
        try {
            dadosCalculoTaxasVO = (DadosCalculoTaxaSaidaVO) record;
            if ((dadosCalculoAnterior != null) && dadosCalculoTaxasVO.getIdProtocolo().equals(dadosCalculoAnterior.getIdProtocolo()) && dadosCalculoTaxasVO.getIdSusep().equals(dadosCalculoAnterior.getIdSusep())
                    && dadosCalculoTaxasVO.getIsentoSN().equals("N")) {
                dadosCalculoTaxasVO.setIdTaxa(dadosCalculoAnterior.getIdTaxa());
                dadosCalculoTaxasVO.setPercentual(dadosCalculoAnterior.getPercentual());
            } else {
                ProcessoSusepDetalheVO processo = new ProcessoSusep().buscarProcessoSusep(dadosCalculoTaxasVO.getIdSusep(), dadosCalculoTaxasVO.getDataSolicitacao());
                if ((processo != null) && (processo.getListaProcessoSusepSobrevivenciaTipoTaxa() != null)) {
                    for (ProcessoSusepSobrevivenciaTipoTaxaVO retornoProcesso : processo.getListaProcessoSusepSobrevivenciaTipoTaxa()) {
                        if (retornoProcesso.getTipoTaxa().getId().equals(1L)) {
                            dadosCalculoTaxasVO.setIdTaxa(retornoProcesso.getId());
                            dadosCalculoTaxasVO.setPercentual(retornoProcesso.getPercentualTaxa());
                            break;
                        }
                    }
                }
            }

            dadosCalculoAnterior = dadosCalculoTaxasVO;
            BigDecimal valorTaxa = BigDecimal.ZERO;
            if (dadosCalculoTaxasVO.getPercentual() != null) {
                valorTaxa = dadosCalculoTaxasVO.getValorBruto().multiply(dadosCalculoTaxasVO.getPercentual());
            }
            dadosCalculoTaxasVO.setValorTaxa(valorTaxa);
        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }

        return dadosCalculoTaxasVO;
    }

    /**
     * Esse metodo e executado durante a finalizacao do job, ele retorna um codigo espec�fico informando se o processamento esta completo ou se
     * ocorreu algum erro.
     * 
     * @return codigo valido especificado em com.ibm.websphere.batch.BatchConstants
     */
    @Override
    public int completeProcessing() {
        return BatchConstants.STEP_COMPLETE;
    }
}
