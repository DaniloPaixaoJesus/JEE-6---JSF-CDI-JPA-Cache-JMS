/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step2;

import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step2.DadosEntradaPassivo;

import com.ibm.websphere.batch.BatchConstants;
import com.ibm.websphere.batch.devframework.steps.technologyadapters.BatchRecordProcessor;

/**
 * Class ProcessaBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBt implements BatchRecordProcessor {
    private LogBatch logger;
    DadosEntradaPassivo dadosEntradaPassivoAnterior = null;

    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 3 - Processor - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }

    /**
     * Esse metodo e responsavel por processar o registro que foi recuperado no reader.
     * 
     * @param record objeto criado no reader
     */
    @Override
    public Object processRecord(Object record) throws Exception {
        logger.debug("Passo 3 - Processor - processRecord ");
        DadosEntradaPassivo dadosEntradaPassivo = null;
        try {
            dadosEntradaPassivo = (DadosEntradaPassivo) record;
            if ((dadosEntradaPassivoAnterior == null) || (dadosEntradaPassivoAnterior.getQtdeLinhaRestante() <= 0)) {
                dadosEntradaPassivoAnterior = dadosEntradaPassivo;
            }
            dadosEntradaPassivoAnterior.addListaMarcacaoDinheiro(dadosEntradaPassivo.getMarcacaoDinheiro());
            dadosEntradaPassivoAnterior.setQtdeLinhaRestante(dadosEntradaPassivoAnterior.getQtdeLinhaRestante() - 1);
        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }
        return dadosEntradaPassivoAnterior;
    }

    /**
     * Esse metodo e executado durante a finalizacao do job, ele retorna um codigo especifico informando se o processamento esta completo ou se
     * ocorreu algum erro.
     * 
     * @return codigo valido especificado em com.ibm.websphere.batch.BatchConstants
     */
    @Override
    public int completeProcessing() {
        return BatchConstants.STEP_COMPLETE;
    }
}
