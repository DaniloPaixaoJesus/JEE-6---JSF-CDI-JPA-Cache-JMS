/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step7;

import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

import com.ibm.websphere.batch.BatchConstants;
import com.ibm.websphere.batch.devframework.steps.technologyadapters.BatchRecordProcessor;

/**
 * Class ProcessaBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBt implements BatchRecordProcessor {
    private LogBatch logger;

    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 3 - Processor - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }
    
    /**
     * Esse metodo e responsavel por processar o registro que foi
     * recuperado no reader.
     * 
     * @param record objeto criado no reader
     */
    @Override
    public Object processRecord(Object record) throws Exception {
        return record;
    }

    /**
     * Esse metodo e executado durante a finalizacao do job, ele retorna um
     * codigo espec�fico informando se o processamento esta completo ou se
     * ocorreu algum erro.
     * 
     * @return codigo valido especificado em com.ibm.websphere.batch.BatchConstants
     */
    @Override
    public int completeProcessing() {
        return BatchConstants.STEP_COMPLETE;
    }
}
