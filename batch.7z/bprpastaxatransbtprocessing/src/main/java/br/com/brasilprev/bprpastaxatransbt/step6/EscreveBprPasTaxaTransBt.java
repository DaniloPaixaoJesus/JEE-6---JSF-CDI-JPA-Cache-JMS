package br.com.brasilprev.bprpastaxatransbt.step6;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.NumerosInteiros;
import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step6.QueryConstantsStep6;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternPreConceder;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.MathUtil;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternPreConceder {

    /** logger. */
    private LogBatch logger;

    /** map sequence lancamento. */
    private final Map<DadosSaldoVO, Long> mapSequenceLancamento = new HashMap<DadosSaldoVO, Long>();

    /** map sequence requisicao atividade. */
    private final Map<DadosSaldoVO, Long> mapSequenceRequisicaoAtividade = new HashMap<DadosSaldoVO, Long>();

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkedHashMap<Integer, String> getStringsQueries() {
        LinkedHashMap<Integer, String> listaInserts = new LinkedHashMap<Integer, String>();
        listaInserts.put(NumerosInteiros.DOIS, QueryConstantsStep6.ACESSO02);
        listaInserts.put(NumerosInteiros.QUATRO, QueryConstantsStep6.ACESSO04);
        listaInserts.put(NumerosInteiros.SEIS, QueryConstantsStep6.ACESSO06);
        listaInserts.put(NumerosInteiros.SETE, QueryConstantsStep6.ACESSO07);
        listaInserts.put(NumerosInteiros.OITO, QueryConstantsStep6.ACESSO08);
        listaInserts.put(NumerosInteiros.NOVE, QueryConstantsStep6.ACESSO09);
        listaInserts.put(NumerosInteiros.DEZ, QueryConstantsStep6.ACESSO10);
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeRecord(Entry<Integer, PreparedStatement> pstmt, Object record) {
        int qtdAdicionadoBatch = 0;
        try {
            DadosSaldoVO dadosSaldoVO = (DadosSaldoVO) record;
            if (dadosSaldoVO.getQtdeItensRestantesMatricula() <= 0) {
                if (dadosSaldoVO.isPossuiSaldo() && (pstmt.getKey() == NumerosInteiros.DOIS) && !mapSequenceLancamento.containsKey(dadosSaldoVO)) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 2");
                    Long idLancamento = getSequenceLancamento(dadosSaldoVO, pstmt.getValue());
                    dadosSaldoVO.setValorTotalSolicitado(MathUtil.formatarDinheiro(dadosSaldoVO.getValorTotalSolicitado()));
                    dadosSaldoVO.setIdLancamento(idLancamento);
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdLancamento());
                    pstmt.getValue().setDate(NumerosInteiros.DOIS, (Date) dadosSaldoVO.getDataCota());
                    pstmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoVO.getIdProtocolo());
                    pstmt.getValue().setLong(NumerosInteiros.QUATRO, dadosSaldoVO.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.CINCO, dadosSaldoVO.getIdTipoOperacao());
                    pstmt.getValue().setLong(NumerosInteiros.SEIS, dadosSaldoVO.getTipoTrasacao());
                    pstmt.getValue().setLong(NumerosInteiros.SETE, dadosSaldoVO.getIdMatricula());
                    pstmt.getValue().setBigDecimal(NumerosInteiros.OITO, dadosSaldoVO.getValorTotalSolicitado());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (dadosSaldoVO.isPossuiSaldo() && (pstmt.getKey() == NumerosInteiros.QUATRO)) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 4");
                    int qtde = dadosSaldoVO.getListaMarcacaoDinheiro().size();
                    dadosSaldoVO.setValorTotalSolicitado(BigDecimal.ZERO);
                    for (MarcacaoDinheiroVO marcacaoDinheiroVO : dadosSaldoVO.getListaMarcacaoDinheiro()) {
                        Long idLancamentoMoney = this.getSequenceLancamentoMoney(pstmt.getValue());
                        qtde -= 1;
                        MathUtil.calcularResto(dadosSaldoVO, marcacaoDinheiroVO, qtde);
                        qtdAdicionadoBatch += insereMarcacaoDinheiro(pstmt, dadosSaldoVO, marcacaoDinheiroVO, idLancamentoMoney);
                    }
                } else if ((pstmt.getKey() == NumerosInteiros.SEIS) && dadosSaldoVO.getIdAtividadePasso() !=null &&!mapSequenceRequisicaoAtividade.containsKey(dadosSaldoVO)) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 6");
                    Long idRequisicaoAtividade = getSequenceRequisicaoAtividade(dadosSaldoVO, pstmt.getValue());
                    dadosSaldoVO.setIdRequisicaoAtividade(idRequisicaoAtividade);
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdRequisicao());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, idRequisicaoAtividade);
                    pstmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoVO.getIdAtividadePasso());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (pstmt.getKey() == NumerosInteiros.SETE && dadosSaldoVO.getIdAtividadePasso() !=null) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 7");
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdRequisicaoFinanceira());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosSaldoVO.getIdRequisicaoAtividade());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (!dadosSaldoVO.isPossuiSaldo() && (pstmt.getKey() == NumerosInteiros.OITO && dadosSaldoVO.getIdAtividadePasso() !=null)) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 8");
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdRequisicaoAtividade());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (!dadosSaldoVO.isPossuiSaldo() && (pstmt.getKey() == NumerosInteiros.NOVE)) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 9");
                    pstmt.getValue().setLong(NumerosInteiros.UM, dadosSaldoVO.getIdRequisicaoFinanceira());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                } else if (dadosSaldoVO.isPossuiSaldo() && (pstmt.getKey() == NumerosInteiros.DEZ)) {
                    logger.debug("Escreve -> WriteRecord -> Entrou Query 10");
                    pstmt.getValue().setBigDecimal(NumerosInteiros.UM, dadosSaldoVO.getValorTotalSolicitado());
                    pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosSaldoVO.getIdLancamento());
                    pstmt.getValue().addBatch();
                    qtdAdicionadoBatch = 1;
                }
            }
        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

    /**
     * Insere marcacao dinheiro.
     * 
     * @param pstmt do tipo Entry<Integer,PreparedStatement>
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param marcacaoDinheiroVO do tipo MarcacaoDinheiroVO
     * @param idLancamentoMoney do tipo Long
     * @return Integer
     * @throws SQLException o SQL exception
     */
    private Integer insereMarcacaoDinheiro(Entry<Integer, PreparedStatement> pstmt, DadosSaldoVO dadosSaldoVO, MarcacaoDinheiroVO marcacaoDinheiroVO, Long idLancamentoMoney) throws SQLException {
        pstmt.getValue().setLong(NumerosInteiros.UM, idLancamentoMoney);
        pstmt.getValue().setLong(NumerosInteiros.DOIS, dadosSaldoVO.getIdLancamento());
        pstmt.getValue().setLong(NumerosInteiros.TRES, dadosSaldoVO.getIdMatricula());
        pstmt.getValue().setLong(NumerosInteiros.QUATRO, marcacaoDinheiroVO.getIdSusep());
        pstmt.getValue().setLong(NumerosInteiros.CINCO, marcacaoDinheiroVO.getIdInvestimento());
        pstmt.getValue().setLong(NumerosInteiros.SEIS, marcacaoDinheiroVO.getIdContaReserva());
        pstmt.getValue().setLong(NumerosInteiros.SETE, marcacaoDinheiroVO.getIdCusteio());
        pstmt.getValue().setDate(NumerosInteiros.OITO, (Date) marcacaoDinheiroVO.getDataDinheiro());
        pstmt.getValue().setBigDecimal(NumerosInteiros.NOVE, marcacaoDinheiroVO.getCotaUtilizada());
        pstmt.getValue().setBigDecimal(NumerosInteiros.DEZ, marcacaoDinheiroVO.getValorNominalDisponivel().setScale(NumerosInteiros.DOIS, RoundingMode.DOWN));
        pstmt.getValue().setBigDecimal(NumerosInteiros.ONZE, marcacaoDinheiroVO.getValorTotal());
        pstmt.getValue().setString(NumerosInteiros.DOZE, marcacaoDinheiroVO.getEhEntidadeFechada());
        pstmt.getValue().setString(NumerosInteiros.TREZE, marcacaoDinheiroVO.getEhIsentoTaxa());
        pstmt.getValue().setLong(NumerosInteiros.QUATORZE, marcacaoDinheiroVO.getIdMarcacaoDinheiro());
        pstmt.getValue().setLong(NumerosInteiros.QUINZE, StringBatchConstants.IDUSUARIOAPLICACAO);
        pstmt.getValue().addBatch();
        return NumerosInteiros.UM;
    }

    /**
     * Retorna o sequence lancamento.
     * 
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param pstmt do tipo PreparedStatement
     * @return sequence lancamento
     */
    private Long getSequenceLancamento(DadosSaldoVO dadosSaldoVO, PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep6.ACESSOSEQUENCE01);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_LANCAMENTO");
                mapSequenceLancamento.put(dadosSaldoVO, retorno);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return retorno;
    }

    /**
     * Retorna o sequence lancamento money.
     * 
     * @param pstmt do tipo PreparedStatement
     * @return sequence lancamento money
     */
    private Long getSequenceLancamentoMoney(PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep6.ACESSOSEQUENCE03);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_LANC_MONEY");
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }

    /**
     * Retorna o sequence requisicao atividade.
     * 
     * @param dadosSaldoVO do tipo DadosSaldoVO
     * @param pstmt do tipo PreparedStatement
     * @return sequence requisicao atividade
     */
    public Long getSequenceRequisicaoAtividade(DadosSaldoVO dadosSaldoVO, PreparedStatement pstmt) {
        Long retorno = null;
        ResultSet resultado = null;
        try (Statement createStatement = pstmt.getConnection().createStatement()) {
            resultado = createStatement.executeQuery(QueryConstantsStep6.ACESSOSEQUENCE05);
            if (resultado.next()) {
                retorno = resultado.getLong("ID_RQST_ACTY");
                mapSequenceRequisicaoAtividade.put(dadosSaldoVO, retorno);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } finally {
            if (resultado != null) {
                try {
                    resultado.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return retorno;
    }

}
