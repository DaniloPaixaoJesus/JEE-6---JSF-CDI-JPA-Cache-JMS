/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step5.spi;

import java.util.Properties;

import com.ibm.wsspi.batch.parallel.Parameterizer;
import com.ibm.wsspi.batch.parallel.Parameters;

// TODO: Auto-generated Javadoc
/**
 * Class BprPasTaxaTransBtParameterizer.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class BprPasTaxaTransBtParameterizer extends Parameterizer {
    /**
     * Metodo que parametriza a submissao do job, essa parametrizacao
     * especifica:
     * <ol>
     * <li>N�mero de subjob que serao executados</li>
     * <li>Propriedades para cada subjob</li>
     * </ol>
     * Esse metodo e chamado pelo ParallelJobManager quando o iniciar o
     * processamento do job.
     * 
     * @param logicalJobName
     *            Nome logico do job
     * @param logicalTXID
     *            Identificador unico da instancia do subjob
     * @param props
     *            Propriedades de entrada do job (configurado no xJCL)
     * @return Objeto de parametros para execucao do job. Ele inclui a
     *         quantidads de subjobs e propriedades para cada subjob
     */
    @Override
    public Parameters parameterize(final String logicalJobName, final String logicalTXID, final Properties props) {
        final Parameters parms = new Parameters();

        final Integer threads = 1;

        Properties newprops[] = new Properties[threads];

        for (int i = 0; i < threads; i++) {
            newprops[i] = new Properties();
        }
        parms.setSubJobProperties(newprops);
        parms.setSubJobCount(threads);

        return parms;
    }

}
