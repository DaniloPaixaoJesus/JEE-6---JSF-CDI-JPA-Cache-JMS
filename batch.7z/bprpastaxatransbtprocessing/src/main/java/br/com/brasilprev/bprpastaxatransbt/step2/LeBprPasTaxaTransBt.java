/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step2;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.constants.StringBatchConstants;
import br.com.brasilprev.bprpastaxatransbt.constants.step2.QueryConstantsStep2;
import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.MarcacaoDinheiroVO;
import br.com.brasilprev.bprpastaxatransbt.vo.step2.DadosEntradaPassivo;

import com.ibm.websphere.batch.devframework.datastreams.patternadapter.JDBCReaderPattern;

/**
 * Classe responsavel por ler os dados no banco de dados utilizando JDBC
 * 
 * @author BRASILPREV
 * @version 1.0.0
 * @see https://www.ibm.com/support/knowledgecenter/en/SSCKBL_8.5.5/// com.ibm.websphere.base.doc/ae/rgrid_btchpttrnjd.html
 */
public class LeBprPasTaxaTransBt implements JDBCReaderPattern {
    private LogBatch logger;
    private String dataCiclo;
    /**
     * Esse metodo e invocado na fase de inicializacao do job
     * 
     * @param props propriedades configuradas no xJCL
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 2 - READ - initialize");

        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

        dataCiclo = props.getProperty(StringBatchConstants.DATAPROCESSAMENTO);
        logger.debug("      Data do Ciclo: " + dataCiclo);

    }

    /**
     * Esse metodo retorna a SQL query que sera utilizada na recuperacao dos dados que serao processados
     * 
     * @return SQL query que sera utilizada.
     */
    @Override
    public String getInitialLookupQuery() {
        logger.debug("Passo 2 - [Inicio] LeBprPasTaxaTransBt.getInitialLookupQuery");
        try {
            logger.debug(QueryConstantsStep2.ACESSO00SELECT.replace("?", dataCiclo));
            return QueryConstantsStep2.ACESSO00SELECT.replace("?", dataCiclo);
        } finally {
            logger.debug("Passo 2 - [Fim] LeBprPasTaxaTransBt.getInitialLookupQuery");
        }
    }

    /**
     * Esse metodo e chamado durate o reinicio do job, deve ser utilizado para criar a SQL query para recuperar os dados que nao foram processados.
     * 
     * @param restartToken chave da ultima linha processada
     * @return SQL query de rein�cio
     */
    @Override
    public String getRestartQuery(String restartToken) {

        logger.debug("Passo 2 - [Inicio] LeBprPasTaxaTransBt.getRestartQuery" + restartToken);
        try {
            logger.debug(QueryConstantsStep2.ACESSO00SELECT.replace("?", dataCiclo));
            return QueryConstantsStep2.ACESSO00SELECT.replace("?", dataCiclo);
        } finally {
            logger.debug("Passo 2 - [Fim] LeBprPasTaxaTransBt.getRestartQuery");
        }
    }

    /**
     * Esse metodo e chamado imediatamento antes de executar o checkpoint.
     * 
     * @return token para reinicio do batch.
     */
    @Override
    public String getRestartTokens() {
        logger.debug("Passo 2 - READ - LeBprPasTaxaTransBt.getRestartTokens");
        return null;
    }

    /**
     * Esse metodo recupera os valores das colunas da SQL query atraves do objeto resultSet. Tipicamente e criado um objeto intermediario (VO) para
     * trafegar na execucao do job.
     * 
     * @param resultSet objeto o resultado de uma linha retornada na SQL query
     * @return objeto
     */
    @Override
    public Object fetchRecord(ResultSet result) {
        DadosEntradaPassivo dadosEntradaPassivo = null;
        try {
            dadosEntradaPassivo = new DadosEntradaPassivo();
            dadosEntradaPassivo.setDataSolicitacao(result.getDate("DATASOLICITACAO"));
            dadosEntradaPassivo.setIdAtividadePasso(result.getLong("ATIVIDADE_PASSO"));
            dadosEntradaPassivo.setIdMatricula(result.getLong("IDMATRICULA"));
            dadosEntradaPassivo.setIdRequisicao(result.getLong("IDREQUISICAO"));
            dadosEntradaPassivo.setIdRequisicaoFinanceira(result.getLong("IDREQUISICAOFINACEIRA"));
            dadosEntradaPassivo.setProtocolo(result.getLong("PROTOCOLO"));
            dadosEntradaPassivo.setQtdeLinha(result.getInt("QTD_LINHA"));
            dadosEntradaPassivo.setQtdeLinhaRestante(result.getInt("QTD_LINHA"));
            dadosEntradaPassivo.setTipoOperacao(result.getLong("TP_OPERACAO"));
            dadosEntradaPassivo.setTipoTransacao(result.getLong("TP_TRANSACAO"));
            dadosEntradaPassivo.setListaMarcacaoDinheiro(new ArrayList<MarcacaoDinheiroVO>());
            dadosEntradaPassivo.setDataCota(result.getDate("DATA_COTA"));
            dadosEntradaPassivo.setValorTotalCota(BigDecimal.ZERO);

            MarcacaoDinheiroVO marcacaoDinheiroVO = new MarcacaoDinheiroVO();
            marcacaoDinheiroVO.setCotaDisponivel(result.getBigDecimal("COTASDISP"));

            marcacaoDinheiroVO.setCotaUtilizada(BigDecimal.ZERO);
            marcacaoDinheiroVO.setDataDinheiro(result.getDate("DATADINHEIRO"));
            marcacaoDinheiroVO.setEhEntidadeFechada(result.getString("ENTIDADEFECHADA"));
            marcacaoDinheiroVO.setEhIsentoTaxa(result.getString("ISENTOTAXA"));
            marcacaoDinheiroVO.setIdContaReserva(result.getLong("CONTA_RESERVA"));
            marcacaoDinheiroVO.setIdCusteio(result.getLong("CUSTEIO"));
            marcacaoDinheiroVO.setIdInvestimento(result.getLong("INVESTIMENTO"));
            marcacaoDinheiroVO.setIdMarcacaoDinheiro(null);
            marcacaoDinheiroVO.setIdSusep(result.getLong("IDSUSEP"));
            marcacaoDinheiroVO.setQtdeCotaSolicitado(BigDecimal.ZERO);
            marcacaoDinheiroVO.setValorCarregamento(BigDecimal.ZERO);
            marcacaoDinheiroVO.setValorNominalDisponivel(result.getBigDecimal("NOMINALDISP"));
            marcacaoDinheiroVO.setValorRendimento(result.getBigDecimal("VALOR_RENDIMENTO"));
            marcacaoDinheiroVO.setPercentualCarregamento(BigDecimal.ZERO);
            marcacaoDinheiroVO.setValorSolicitado(BigDecimal.ZERO);
            marcacaoDinheiroVO.setValorTotal(result.getBigDecimal("VALOR_TOTAL"));
            marcacaoDinheiroVO.setValorCota(result.getBigDecimal("VL_COTA"));
            marcacaoDinheiroVO.setFlagUsaDinheiroEntidadeFechada(result.getString("USADINHEIRO_ENTFECHADA"));

            dadosEntradaPassivo.setMarcacaoDinheiro(marcacaoDinheiroVO);

        } catch (Exception e) {
            TrataExcecoes.batch(e, this.getClass());
        }
        return dadosEntradaPassivo;
    }

}
