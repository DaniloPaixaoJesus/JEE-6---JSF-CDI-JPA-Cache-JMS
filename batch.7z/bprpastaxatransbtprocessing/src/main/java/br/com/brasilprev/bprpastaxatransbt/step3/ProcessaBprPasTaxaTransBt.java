/*
 * ====================================================================
 * Direitos de cópia pela BRASILPREV
 * Todos os direitos reservados.
 * Este sistema contém informações confidenciais e de propriedade da
 * BRASILPREV ("Informações Confidenciais").
 * Você não deve divulgar tais informações confidenciais e deve
 * usá-las somente em conformidade com os termos do contrato de licença
 * definidos pela BRASILPREV.
 * ====================================================================
 */
package br.com.brasilprev.bprpastaxatransbt.step3;

import java.math.BigDecimal;
import java.util.Enumeration;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step3.DadosSaldoPorcentagemVO;

import com.ibm.websphere.batch.BatchConstants;
import com.ibm.websphere.batch.devframework.steps.technologyadapters.BatchRecordProcessor;

/**
 * Class ProcessaBprPasTaxaTransBt.
 * 
 * @author Diego Rodrigues do Nascimento (P51701802)
 */
public class ProcessaBprPasTaxaTransBt implements BatchRecordProcessor {

    /** logger. */
    private LogBatch logger;

    /** dados saldo porcentagem VO. */
    private DadosSaldoPorcentagemVO dadosSaldoPorcentagemVO;

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 3 - Processor - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object processRecord(Object record) throws Exception {
        logger.debug("Passo 3 - Processor - processRecord");
        DadosSaldoPorcentagemVO dadosSaldoAtualVO = null;
        try {
            dadosSaldoAtualVO = (DadosSaldoPorcentagemVO) record;
            if ((this.dadosSaldoPorcentagemVO == null) || (this.dadosSaldoPorcentagemVO.getQtdeItensRestantesMatricula() == 0)) {
                this.dadosSaldoPorcentagemVO = dadosSaldoAtualVO;
                dadosSaldoPorcentagemVO.setValorTotalSolicitado(BigDecimal.ZERO);
            } else if (this.dadosSaldoPorcentagemVO.getQtdeLinhasMarcacao() == 0) {
                dadosSaldoPorcentagemVO.setQtdeLinhasMarcacao(dadosSaldoAtualVO.getQtdeLinhasMarcacao());
            }
            dadosSaldoPorcentagemVO.setQtdeItensRestantesMatricula(dadosSaldoPorcentagemVO.getQtdeItensRestantesMatricula() - 1);
            dadosSaldoPorcentagemVO.setQtdeLinhasMarcacao(dadosSaldoPorcentagemVO.getQtdeLinhasMarcacao() - 1);
            dadosSaldoPorcentagemVO.addMarcacaoDinheiroAoCalculo(dadosSaldoAtualVO.getMarcacaoDinheiro());
        } catch (Exception e) {
            dadosSaldoPorcentagemVO.setQtdeItensRestantesMatricula(dadosSaldoPorcentagemVO.getQtdeItensRestantesMatricula() - 1);
            dadosSaldoPorcentagemVO.setQtdeLinhasMarcacao(dadosSaldoPorcentagemVO.getQtdeLinhasMarcacao() - 1);
            TrataExcecoes.batch(e, this.getClass());
        }
        return this.dadosSaldoPorcentagemVO;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int completeProcessing() {
        return BatchConstants.STEP_COMPLETE;
    }
}
