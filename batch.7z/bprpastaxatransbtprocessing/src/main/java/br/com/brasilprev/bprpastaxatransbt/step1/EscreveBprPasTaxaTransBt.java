package br.com.brasilprev.bprpastaxatransbt.step1;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import br.com.brasilprev.bprpastaxatransbt.exceptions.TrataExcecoes;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query10;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query2;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query4;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query6;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query7;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query8;
import br.com.brasilprev.bprpastaxatransbt.querybatch.Query9;
import br.com.brasilprev.bprpastaxatransbt.querybatch.QueryBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.JDBCWriterPatternQueryBatch;
import br.com.brasilprev.bprpastaxatransbt.utils.LogBatch;
import br.com.brasilprev.bprpastaxatransbt.vo.step1.DadosSaldoVO;

/**
 * Class EscreveBprPasTaxaTransBt.
 * 
 * @author Danilo Paixao (P51701504)
 */
public class EscreveBprPasTaxaTransBt implements JDBCWriterPatternQueryBatch {

    /** logger. */
    private LogBatch logger;

    /** map sequence lancamento. */
    private final Map<DadosSaldoVO, Long> mapSequenceLancamento = new HashMap<DadosSaldoVO, Long>();
    
    /** map sequence requisicao atividade. */
    private final Map<DadosSaldoVO, Long> mapSequenceRequisicaoAtividade = new HashMap<DadosSaldoVO, Long>();


    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize(Properties props) {
        logger = new LogBatch(props);
        logger.debug("Passo 4: Writer - initialize");
        final Enumeration<Object> valores = props.keys();
        while (valores.hasMoreElements()) {
            final String key = (String) valores.nextElement();
            logger.debug("      Propriedades: " + key + " - " + props.getProperty(key));
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<QueryBatch> getStringsQueries() {
        List<QueryBatch> listaInserts = new ArrayList<QueryBatch>();
        listaInserts.add(new Query2(mapSequenceLancamento));
        listaInserts.add(new Query4());
        listaInserts.add(new Query6(mapSequenceRequisicaoAtividade));        
        listaInserts.add(new Query7());
        listaInserts.add(new Query8());
        listaInserts.add(new Query9());
        listaInserts.add(new Query10());
        
        return listaInserts;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int writeRecord(Entry<QueryBatch, PreparedStatement> pstmt, Object record) {
        
        int qtdAdicionadoBatch = 0;
        
        try {            
            DadosSaldoVO dadosSaldoVO = (DadosSaldoVO) record;
        
            if (dadosSaldoVO.getQtdeItensRestantesMatricula() <= 0) {
                QueryBatch queryBatch = pstmt.getKey();
                qtdAdicionadoBatch = queryBatch.addBatch(pstmt, record);
            }
            
        } catch (Exception e) {
            qtdAdicionadoBatch = 0;
            TrataExcecoes.batch(e, this.getClass());
        }
        return qtdAdicionadoBatch;
    }

}
