package br.com.brasilprev.bprcomponentes.web.validator;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.joda.time.LocalDateTime;

/**
 * @author Diego Duarte (p51400517)
 */
/**
 * The Class PeriodoValidator.
 * Para utilizar o validator o componente com a data fim deve possuir o atributo com nome "dataInicio", 
 * 		para definir o id do campo com data inicio que sera utilizado para comparar com o campo data final, considerando que
 *  	podem haver varios campos utilizando o validator.
 *  	Tambem deve ser definido o atributo "dataInicioLabel" no campo data final, para informar o rotulo do campo com data inicial que ser� comparado com o de data final, 
 *  	caso n�o seja definido ser� mostrada a mensagem como o nome padr�o de Data In�cio.
 */
public class PeriodoValidator implements Validator {

   /**
    * @author Diego Duarte (p51400517)
    * 
    * validate: validador de datas;
    * 
    * @param context
    * @param component
    * @param value
    *
    * @return void
    * 
    */
	
	public static final String MSG_ERRO_PERIODO = "%s n�o pode ser maior que a data fim.";
	
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        if (value == null) {
            return;
        }

        String startDateValue = (String) component.getAttributes().get("dataInicio");
        if (startDateValue == null) {
            return;
        }
        
        Object startDatefieldLabel = component.getAttributes().get("dataInicioLabel");
        
        startDatefieldLabel = startDatefieldLabel != null ? startDatefieldLabel.toString() : "Data in�cio";
        
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
        
        Date dataInicio = null;
        for (String key : ec.getRequestParameterMap().keySet()) {
        	if (key.endsWith(startDateValue + "_input")) {
        		String valorDataInicioString = ec.getRequestParameterMap().get(key);
        		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        		try {
        			String dataInicialObritatoria = (String) component.getAttributes().get("dataInicialObritatoria");
        			if (dataInicialObritatoria != null && dataInicialObritatoria.toLowerCase().equals("true")) {
        				if (valorDataInicioString == null || valorDataInicioString.isEmpty()) {
        					((UIInput)component).setValid(false);
        		            FacesMessage yourFailure = new FacesMessage(FacesMessage.SEVERITY_FATAL, "O campo " + startDatefieldLabel + " � obrigat�rio", null);
        		            context.addMessage(component.getClientId(context),  yourFailure);
        		            break;
        				}
        				dataInicio = sdf.parse(valorDataInicioString);
        				break;
        			}
        			if (valorDataInicioString != null && !valorDataInicioString.isEmpty()) {
        				dataInicio = sdf.parse(valorDataInicioString);
        			}
        			break;
				} catch (Exception e) {
					((UIInput)component).setValid(false);
		            FacesMessage yourFailure = new FacesMessage(FacesMessage.SEVERITY_FATAL, "Erro ao converter o campo " + startDatefieldLabel + "!", null);
		            context.addMessage(component.getClientId(context),  yourFailure);
		            e.printStackTrace();
		            return;
				}
        	}
        }
        
        Date endDate = (Date) value;
        String msgErro = String.format(MSG_ERRO_PERIODO, startDatefieldLabel);
        if (dataInicio != null && dataInicio.after(endDate)) {
            ((UIInput)component).setValid(false);
            FacesMessage yourFailure = new FacesMessage(FacesMessage.SEVERITY_FATAL, msgErro, null);
            context.addMessage(component.getClientId(context),  yourFailure);
            return;
        }
    }

}
