/*
 * Direitos de copia pela BRASILPREV
 *
 * Todos os direitos reservados.
 *
 * Este sistema contem informacoes confidenciais e de propriedade da BRASILPREV 
 * ("Informacoes Confidenciais").
 * Voce nao deve divulgar tais informacoes confidenciais e deve usa-las somente em conformidade 
 * com os termos do contrato de licenca definidos pela BRASILPREV.
 */
package br.com.brasilprev.bprcomponentes.web.resolver;

import java.net.URL;

import javax.faces.view.facelets.ResourceResolver;

/**
 * 
 * Classe criada para resolver os recursos da shared library, pois o Websphere
 * nao resolve os recursos da mesma, somente quando o jar esta dentro da pasta
 * lib da aplicacao.
 * 
 * @author Fabio Lyrio
 * @since 29/09/2016
 * @version 1.0.0
 * 
 */
public class FaceletsResourceResolver extends ResourceResolver {

    /** Constante RESOURCES_FOLDER. */
    private static final String RESOURCES_FOLDER = "/META-INF/resources";

    /** Atributo parent. */
    private final ResourceResolver parent;

    /** Atributo base path. */
    private final String basePath;

    /**
     * Instancia um novo objeto de FaceletsResourceResolver.
     *
     * @param parent parent
     */
    public FaceletsResourceResolver(final ResourceResolver parent) {
        this.parent = parent;
        basePath = RESOURCES_FOLDER;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public URL resolveUrl(final String path) {
        URL url = parent.resolveUrl(path);
        if (url == null) {
            url = getClass().getResource(basePath + path);
        }
        return url;
    }
}