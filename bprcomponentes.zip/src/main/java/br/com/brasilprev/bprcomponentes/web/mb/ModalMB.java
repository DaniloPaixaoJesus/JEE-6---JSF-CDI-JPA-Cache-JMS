/*
 * Direitos de copia pela BRASILPREV
 *
 * Todos os direitos reservados.
 *
 * Este sistema contem informacoes confidenciais e de propriedade da BRASILPREV 
 * ("Informacoes Confidenciais").
 * Voce nao deve divulgar tais informacoes confidenciais e deve usa-las somente em conformidade 
 * com os termos do contrato de licenca definidos pela BRASILPREV.
 */
package br.com.brasilprev.bprcomponentes.web.mb;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import br.com.brasilprev.bprcomponentes.services.ReservaService;
import br.com.brasilprev.bprreserva.exception.BusinessException;

/**
 * 
 * Classe responsável pelas operação do componente modal
 * 
 * @author Fabio Lyrio (p151401002)
 * @since 29/09/2016
 * @version 1.0.0
 * 
 */
@ManagedBean(name = "modalMB")
@RequestScoped
public class ModalMB implements Serializable {

    /** Serial version UID */
    private static final long serialVersionUID = 1L;

    private ReservaService service = new ReservaService();
    private List<String> listarResultadosModal;
    private transient Object selection;

    /**
     * Método que obtém uma relação de datas
     * @return List<String>
     */
    public List<String> getListarResultadosModal() {
        if (listarResultadosModal == null || listarResultadosModal.isEmpty()) {
            try {
                listarResultadosModal = service.obterDiasUteisUltimosSeisMeses();
            } catch (BusinessException e) {
                e.printStackTrace();
            }
        }
        return listarResultadosModal;
    }

    public void setListarResultadosModal(List<String> listarResultadosModal) {
        this.listarResultadosModal = listarResultadosModal;
    }

    public Object getSelection() {
        return selection;
    }

    public void setSelection(Object selection) {
        this.selection = selection;
    }

}
