package br.com.brasilprev.bprcomponentes.services;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.brasilprev.bprcomponentes.constantes.EJBConstantes;
import br.com.brasilprev.bprcomponentes.exception.ComponentesException;
import br.com.brasilprev.bprejblib.utils.ServiceLocator;
import br.com.brasilprev.bprfinanceirodm.ejb.service.BancoRemote;
import br.com.brasilprev.bprfinanceirodm.ejb.vo.BancoVO;

/**
 * 
 * Classe Service responsável pelas operações do projeto bprfinanceiro
 * 
 * @author Fabio Lyrio (p151401002)
 * @since 29/09/2016
 * @version 1.0.0
 * 
 */
public class FinanceiroService implements Serializable {

    /** serialVersionUID */
    private static final long serialVersionUID = 1L;
    
    private BancoRemote ejb;

    /**
     * 
     * Método que obtém uma relação de bancos
     * 
     * @return Map<Long, BancoVO>
     * 
     */
    public Map<String, BancoVO> getBancos() throws ComponentesException {
        List<BancoVO> listarBancos = getEjb().listarAtivos();
        if (listarBancos != null) {
            Map<String, BancoVO> mapBancos = new HashMap<>();
            for (BancoVO banco : listarBancos) {
                mapBancos.put(banco.getNumero(), banco);
            }
            return mapBancos;
        }
        return null;
    }
    
    private BancoRemote getEjb() {
        if(ejb == null) {
            ServiceLocator service = ServiceLocator.getInstance();
            Object obj = service.getEJBReference(BancoRemote.class, EJBConstantes.BANCO_REMOTE);
            ejb = (BancoRemote) obj;
        }
        return ejb;
    }
}