/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.web.mb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.SelectEvent;

import br.com.brasilprev.bprcomponentes.exception.ComponentesException;
import br.com.brasilprev.bprcomponentes.services.FinanceiroService;
import br.com.brasilprev.bprfinanceirodm.ejb.vo.BancoVO;

/**
 * Class AutoCompleteMB.
 */
@ManagedBean(name = "componenteAutoCompleteMB")
@ViewScoped
public class AutoCompleteMB implements Serializable {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** resultados. */
    private List<BancoVO> resultados;
    
    /** banco VO. */
    private BancoVO bancoVO;
    
    /** banco VO valor enviado. */
    private BancoVO bancoVOValorEnviado;
    
    /** numero banco. */
    private String numeroBanco;
    
    /** valor enviado. */
    private String valorEnviado;
    
    /** value preenchido. */
    private String valuePreenchido;

    /** service. */
    private FinanceiroService service = new FinanceiroService();

    /**
     * Start.
     */
    @PostConstruct
    public void start() {
        resetList();
    }

    /**
     * Inits the.
     *
     * @throws ComponentesException o componentes exception
     */
    private void init() throws ComponentesException {
        Map<String, BancoVO> mapBancos = getService().getBancos();
        if(mapBancos != null) {
            resultados = new ArrayList<>(mapBancos.values());
        } else {
            throw new ComponentesException("Não foi possível listar os bancos");
        }
    }

    /**
     * Reset list.
     */
    private void resetList() {
        resultados = null;
        setBancoVO(null);
        setBancoVOValorEnviado(null);
    }

    /**
     * Inits the resultados.
     *
     * @throws ComponentesException o componentes exception
     */
    private void initResultados() throws ComponentesException {
        if(resultados == null) {
            init();
        }
    }
    
    /**
     * Método responsável por Buscar banco.
     *
     * @param query do tipo String
     * @return List
     * @throws ComponentesException o componentes exception
     */
    public List<BancoVO> buscarBanco(String query) throws ComponentesException {
        initResultados();
        List<BancoVO> results = new ArrayList<>();
        if (StringUtils.isBlank(query)) {
            results = resultados;
        } else {
            for (BancoVO banco : resultados) {
                if (banco.getNumero().startsWith(query) || banco.getNome().contains(query.toUpperCase())) {
                    results.add(banco);
                }
            }
        }
        return results;
    }

    /**
     * Método responsável por Buscar banco enviado.
     *
     * @param query do tipo String
     * @return List
     * @throws ComponentesException o componentes exception
     */
    public List<BancoVO> buscarBancoEnviado(String query) throws ComponentesException {
        List<BancoVO> results = new ArrayList<>();
        if (getValorEnviado() != null && !getValorEnviado().isEmpty()) {
            results = buscarBanco(query);
            for (BancoVO vo : results) {
                if (vo.getNumero().equals(getValorEnviado())) {
                    setBancoVOValorEnviado(vo);
                    break;
                }
            }
        }
        return results;
    }

    /**
     * Método responsável por Adicionar send value.
     *
     * @return List
     * @throws ComponentesException o componentes exception
     */
    public List<BancoVO> adicionarSendValue() throws ComponentesException {
        initResultados();
        if (getValorEnviado() != null && !getValorEnviado().isEmpty()) {
            setBancoVOValorEnviado(null);
            init();
            for (BancoVO banco : resultados) {
                if (banco.getNumero().equals(getValorEnviado())) {
                    setBancoVOValorEnviado(banco);
                    break;
                }
            }
        }
        return resultados;
    }

    /**
     * On item select.
     *
     * @param event do tipo AjaxBehaviorEvent
     * @throws ComponentesException o componentes exception
     */
    public void onItemSelect(AjaxBehaviorEvent event) throws ComponentesException {
        bancoVO = (BancoVO)((SelectEvent)event).getObject();
        setBancoVOValorEnviado(bancoVO);
    }

    /**
     * Retorna o value preenchido.
     *
     * @return value preenchido
     */
    public String getValuePreenchido() {
        return valuePreenchido;
    }

    /**
     * Atribui valor a value preenchido.
     *
     * @param valuePreenchido atribui novo valor a value preenchido
     */
    public void setValuePreenchido(String valuePreenchido) {
        this.valuePreenchido = valuePreenchido;
        setValorEnviado(valuePreenchido);
    }

    /**
     * Retorna o banco VO.
     *
     * @return banco VO
     */
    public BancoVO getBancoVO() {
       return bancoVO;
    }

    /**
     * Atribui valor a banco VO.
     *
     * @param bancoVO atribui novo valor a banco VO
     */
    public void setBancoVO(BancoVO bancoVO) {
        this.bancoVO = bancoVO;
    }

    /**
     * Retorna o banco VO valor enviado.
     *
     * @return banco VO valor enviado
     */
    public BancoVO getBancoVOValorEnviado() {
        return bancoVOValorEnviado;
    }

    /**
     * Atribui valor a banco VO valor enviado.
     *
     * @param bancoVOValorEnviado atribui novo valor a banco VO valor enviado
     */
    public void setBancoVOValorEnviado(BancoVO bancoVOValorEnviado) {
        this.bancoVOValorEnviado = bancoVOValorEnviado;
    }

    /**
     * Retorna o numero banco.
     *
     * @return numero banco
     */
    public String getNumeroBanco() {
        return numeroBanco;
    }

    /**
     * Atribui valor a numero banco.
     *
     * @param numeroBanco atribui novo valor a numero banco
     */
    public void setNumeroBanco(String numeroBanco) {
        this.numeroBanco = numeroBanco;
    }

    /**
     * Retorna o valor enviado.
     *
     * @return valor enviado
     */
    public String getValorEnviado() {
        return valorEnviado;
    }

    /**
     * Atribui valor a valor enviado.
     *
     * @param valorEnviado atribui novo valor a valor enviado
     */
    public void setValorEnviado(String valorEnviado) {
        this.valorEnviado = valorEnviado;
    }
    
    /**
     * Método responsável por Obter label.
     *
     * @param banco do tipo BancoVO
     * @return String
     */
    public String obterLabel(BancoVO banco) {
        if(banco != null) {
            return banco.getNumero() + " - " + banco.getNome();
        } 
        return "";
    }

    /**
     * Retorna o service.
     *
     * @return service
     */
    public FinanceiroService getService() {
        return service;
    }
}