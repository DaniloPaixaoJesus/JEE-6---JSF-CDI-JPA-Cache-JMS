/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.web.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 * Class StringVaziaValidator.
 */
public class StringVaziaValidator implements Validator {

    /**
     * 
     * Recebe um Object e efetua a validação dele
     * 
     * @param context FacesContext
     * @param component UIComponent
     * @param value Object
     * 
     * @throws ValidatorException
     * 
     */
    
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        if(value != null && value.toString().length() == 0) {
            ((UIInput)component).setValid(false);

            FacesMessage yourFailure = new FacesMessage(FacesMessage.SEVERITY_FATAL, "Campo vazio.", null);
            context.addMessage(component.getClientId(context),  yourFailure);
        }
    }
}
