/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.web.converter;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.NumberFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import br.com.brasilprev.bprcomponentes.constantes.Inteiro;

/**
 * Class QuantidadeCotaConverter.
 */
public class QuantidadeCotaConverter implements Converter {
    
    /** Constante NF. */
    private static final NumberFormat NF = NumberFormat.getNumberInstance();
    static {
        NF.setMaximumFractionDigits(Inteiro.DEZESSEIS);
    }

    /**
     * 
     * Recebe uma String e efetua o parse para o valor esperado
     * 
     * @param arg0 FacesContext
     * @param arg1 UIComponent
     * @param value String
     * 
     * @throws ConverterException
     * 
     * @return object
     * 
     */
    public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) throws ConverterException {
        if (value != null && value.trim().length() > Inteiro.ZERO) {
            try {
                return new BigDecimal(value.replaceAll("[.]", "").replaceAll(",", "."), MathContext.DECIMAL128);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }

    /**
     * 
     * Recebe um Objeto e efetua o parse para uma String
     * 
     * @param arg0 FacesContext
     * @param arg1 UIComponent
     * @param object Object
     * 
     * @throws ConverterException
     * 
     * @return String
     * 
     */
    public String getAsString(FacesContext arg0, UIComponent arg1, Object object) throws ConverterException {
        if (object != null && object.toString().trim().length() > 0 ) {
            try {
                return NF.format(object);
            } catch (IllegalArgumentException e) {
                return null;
            }
        }
        return null;
    }
}