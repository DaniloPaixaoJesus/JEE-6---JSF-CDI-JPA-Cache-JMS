/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.web.validator;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.convert.ConverterException;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import br.com.brasilprev.bprutils.exception.ParametroInvalidoException;
import br.com.brasilprev.bprutils.validacao.CNPJValidador;

/**
 * Class CnpjValidator.
 */
public class CnpjValidator implements Validator {

    /**
     * 
     * Recebe um Object e efetua a validação dele
     * 
     * @param context FacesContext
     * @param component UIComponent
     * @param value Object
     * 
     * @throws ValidatorException
     * 
     */
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        if(value != null) {
            CNPJValidador cnpj = new CNPJValidador();
            try {
                cnpj.validaDeclaracao(value.toString());
            } catch(ParametroInvalidoException e) {
                List<String> erros = e.getMensagens();

                ((UIInput)component).setValid(false);
                FacesMessage yourFailure = new FacesMessage(FacesMessage.SEVERITY_FATAL, erros.get(0), null);
                context.addMessage(component.getClientId(context),  yourFailure);
            }
        }
    }
}
