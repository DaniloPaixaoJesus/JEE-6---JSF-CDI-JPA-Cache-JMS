/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.web.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import br.com.brasilprev.bprcomponentes.constantes.Inteiro;
import br.com.brasilprev.bprcomponentes.utils.StringUtil;

/**
 * Class CpfConverter.
 */
public class CpfConverter implements Converter {
    
    /**
     * 
     * Recebe uma String e efetua o parse para o valor esperado
     * 
     * @param arg0 FacesContext
     * @param arg1 UIComponent
     * @param value String
     * 
     * @throws ConverterException
     * 
     * @return object
     * 
     */
    public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) throws ConverterException {
        if (value != null && value.trim().length() > Inteiro.ZERO) {
            return value.replaceAll("[-.]", "");
        }
        return null;
    }

    /**
     * 
     * Recebe um Objeto e efetua o parse para uma String
     * 
     * @param arg0 FacesContext
     * @param arg1 UIComponent
     * @param object Object
     * 
     * @throws ConverterException
     * 
     * @return String
     * 
     */
    public String getAsString(FacesContext arg0, UIComponent arg1, Object object) throws ConverterException {
        if (object != null && object.toString().trim().length() > Inteiro.ZERO ) {
            String temp = object.toString();
            return StringUtil.formataMilhar(temp.substring(Inteiro.ZERO, Inteiro.NOVE)) + "-" + temp.substring(Inteiro.NOVE);
        }
        return null;
    }
}