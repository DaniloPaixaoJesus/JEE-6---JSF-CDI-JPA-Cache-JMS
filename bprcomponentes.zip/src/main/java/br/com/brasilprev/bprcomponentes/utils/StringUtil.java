/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.utils;

import br.com.brasilprev.bprcomponentes.constantes.Inteiro;

/**
 * Class StringUtil.
 */
public class StringUtil {
    
    /**
     * Cria uma nova instância de string util.
     */
    private StringUtil(){}
    
    /**
     * Formata milhar.
     *
     * @param numero do tipo String
     * @return String
     */
    public static String formataMilhar(String numero) {
        if(numero.length() > Inteiro.TRES) {
            return formataMilhar(numero.substring(Inteiro.ZERO, numero.length() - Inteiro.TRES)) + '.' + numero.substring(numero.length() - Inteiro.TRES);
        } else {
            return numero;
        }
    }

}
