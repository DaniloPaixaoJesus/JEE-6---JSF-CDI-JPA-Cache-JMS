package br.com.brasilprev.bprcomponentes.services;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.brasilprev.bprcomponentes.constantes.EJBConstantes;
import br.com.brasilprev.bprejblib.utils.ServiceLocator;
import br.com.brasilprev.bprreserva.exception.BusinessException;
import br.com.brasilprev.bprreserva.service.FeriadoDataRemote;

/**
 * Classe Service responsável pelas operação do projeto bprreserva
 * 
 * @author Fabio Lyrio (p151401002)
 * @since 29/09/2016
 * @version 1.0.0
 */
public class ReservaService implements Serializable {

    /** serialVersionUID */
    private static final long serialVersionUID = 1L;
    
    private static final Integer SEIS = 6;
    
    private FeriadoDataRemote ejb;

    /**
     * Método que obtém uma relação de datas
     * @return List<String>
     */
    public List<String> obterDiasUteisUltimosSeisMeses() throws BusinessException {

        try {

            List<String> listarResultadosModal = new ArrayList<>();
            SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");

            GregorianCalendar gc = new GregorianCalendar();
            gc.add(Calendar.MONTH, -SEIS);

            List<Date> datas = getEjb().montarDiasUteis(gc.getTime(), new GregorianCalendar().getTime());

            for (Date date : datas) {
                listarResultadosModal.add(dataFormatada.format(date));
            }

            return listarResultadosModal;
        } catch (Exception e) {
            throw new BusinessException(e.getMessage(), this.getClass());
        }
    }
    
    private FeriadoDataRemote getEjb() {
        if(ejb == null) {
            ServiceLocator locator = ServiceLocator.getInstance();
            Object obj = locator.getEJBReference(FeriadoDataRemote.class, EJBConstantes.FERIADO_DATA_REMOTE);
            ejb= (FeriadoDataRemote)obj;
        }
        return ejb;
    }
}