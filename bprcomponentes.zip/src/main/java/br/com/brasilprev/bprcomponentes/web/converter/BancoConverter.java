/*
 * Direitos de copia pela BRASILPREV
 *
 * Todos os direitos reservados.
 *
 * Este sistema contem informacoes confidenciais e de propriedade da BRASILPREV 
 * ("Informacoes Confidenciais").
 * Voce nao deve divulgar tais informacoes confidenciais e deve usa-las somente em conformidade 
 * com os termos do contrato de licenca definidos pela BRASILPREV.
 */
package br.com.brasilprev.bprcomponentes.web.converter;

import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.commons.lang3.math.NumberUtils;

import br.com.brasilprev.bprcomponentes.exception.ComponentesException;
import br.com.brasilprev.bprcomponentes.services.FinanceiroService;
import br.com.brasilprev.bprfinanceirodm.ejb.vo.BancoVO;

/**
 * 
 * Classe converter das relações e objetos BancoVO
 * 
 * @author Fabio Lyrio (p151401002)
 * @since 29/09/2016
 * @version 1.0.0
 * 
 */
public class BancoConverter implements Converter {

    private FinanceiroService service = new FinanceiroService();

    /**
     * 
     * Retorna a seleção como Object
     * 
     * @param fc FacesContext
     * @param uic UIComponent
     * @param value String
     * @return Object
     * 
     */
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if (value != null && value.trim().length() > NumberUtils.LONG_ZERO) {
            Map<String, BancoVO> mapBancos;
            try {
                mapBancos = service.getBancos();
                return mapBancos.get(convertBanco(value));
            } catch (ComponentesException e) {
                e.printStackTrace();
            }

            return null;
        } else {
            return null;
        }
    }

    /**
     * 
     * Retorna a seleção como String
     * 
     * @param fc FacesContext
     * @param uic UIComponent
     * @param object Object
     * @return String
     * 
     */
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if (object != null && object.toString().length() > 0) {
            return String.valueOf(((BancoVO) object).getNumero());
        } else {
            return null;
        }
    }

    /**
     * 
     * Método privado que conveter o valor do banco
     * 
     * @param banco String
     * @return String
     * 
     */
    private String convertBanco(String banco) {
        String retorno = null;
        if (banco != null && !banco.trim().isEmpty()) {
            return banco.trim().replaceAll("[^0123456789]", "");
        }
        return retorno;
    }
}