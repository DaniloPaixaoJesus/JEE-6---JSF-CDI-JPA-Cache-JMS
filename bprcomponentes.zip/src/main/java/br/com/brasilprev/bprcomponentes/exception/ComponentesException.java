package br.com.brasilprev.bprcomponentes.exception;

/**
 * 
 * ComponentesException
 * 
 * @author P51400504
 * @since 05/01/2017
 *
 */
public class ComponentesException extends Exception {

    /** serialVersionUID **/
    private static final long serialVersionUID = -5783112584663087379L;
    
    /**
     * 
     * Constructor
     * 
     * @param e
     * 
     */
    public ComponentesException(Throwable e) {
        super(e);
    }
    
    /**
     * 
     * Constructor
     * 
     * @param message
     * 
     */
    public ComponentesException(String message) {
        super(message);
    }
    
    /**
     * 
     * Constructor
     * 
     * @param message
     * @param e
     * 
     */
    public ComponentesException(String message, Throwable e) {
        super(message, e);
    }
}