/*
* ====================================================================
* Direitos de cópia pela BRASILPREV
* 
* Todos os direitos reservados.
* 
* Este sistema contém informações confidenciais e de propriedade da
* BRASILPREV ("Informações Confidenciais").
* Você não deve divulgar tais informações confidenciais e deve
* usá-las somente em conformidade com os termos do contrato de licença
* definidos pela BRASILPREV.
* ==================================================================== 
*/
package br.com.brasilprev.bprcomponentes.constantes;

/**
 * Class EJBConstantes.
 */
public class EJBConstantes {
    
    /**
     * Cria uma nova instância de EJB constantes.
     */
    private EJBConstantes(){}

    /** Constante FERIADO_DATA_REMOTE. */
    public static final String FERIADO_DATA_REMOTE = "ejb/bprreserva/FeriadoDataRemote";

    /** Constante SERVICOS_BANCARIOS_REMOTE. */
    public static final String SERVICOS_BANCARIOS_REMOTE = "ejb/bprfinanceiro/ServicosBancariosRemote";
    
    public static final String BANCO_REMOTE = "java:global/bprfinanceirodm/bprfinanceirodmejb/BancoServiceBean!br.com.brasilprev.bprfinanceirodm.ejb.service.BancoRemote";


}
