$(document).ready(function(){
    PrimeFaces.widget.AutoComplete.prototype.alignPanel = function() {
        var fixedPosition = this.panel.css('position') == 'fixed',
        win = $(window),
    positionOffset = fixedPosition ? '-' + win.scrollLeft() + ' -' + win.scrollTop() : null,
                panelWidth = null;

        if(this.cfg.multiple) {
            panelWidth = this.multiItemContainer.innerWidth() - (this.input.position().left - this.multiItemContainer.position().left);
        }
        else {
            panelWidth = this.input.innerWidth();
        }

        this.panel.css({
            left:'',
            top:'',
            width: panelWidth
        })
        .position({
            my: 'left top'
                ,at: 'left bottom'
                    ,of: this.input
                    ,collision: 'none',
                    offset : positionOffset
        });
    }
});

function resizeAutocomplete(nome, sizeInput){
    if(sizeInput != undefined){
        if(sizeInput != null || sizeInput != ""){
            $('[id*="' + nome + '"]').css('width', sizeInput+'em');
        }
    }
}